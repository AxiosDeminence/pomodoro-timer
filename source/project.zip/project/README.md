# Horrible Timer - Source Code

## Installation

1. Run `npm install` to install the necessary packages before starting on anything else!
function cov_22cumzevu3() {
  var path = "D:\\\u5B66\u4E60\\21WI\\CSE110\\cse110-w21-group13\\source\\src\\scripts\\script.js";
  var hash = "a273b8fc7e287f7f1452e47d1b8028bd03970175";
  var global = new Function("return this")();
  var gcv = "__coverage__";
  var coverageData = {
    path: "D:\\\u5B66\u4E60\\21WI\\CSE110\\cse110-w21-group13\\source\\src\\scripts\\script.js",
    statementMap: {
      "0": {
        start: {
          line: 3,
          column: 0
        },
        end: {
          line: 41,
          column: 3
        }
      },
      "1": {
        start: {
          line: 10,
          column: 4
        },
        end: {
          line: 23,
          column: 5
        }
      },
      "2": {
        start: {
          line: 11,
          column: 8
        },
        end: {
          line: 11,
          column: 19
        }
      },
      "3": {
        start: {
          line: 12,
          column: 8
        },
        end: {
          line: 12,
          column: 15
        }
      },
      "4": {
        start: {
          line: 13,
          column: 8
        },
        end: {
          line: 13,
          column: 24
        }
      },
      "5": {
        start: {
          line: 14,
          column: 8
        },
        end: {
          line: 14,
          column: 20
        }
      },
      "6": {
        start: {
          line: 15,
          column: 8
        },
        end: {
          line: 15,
          column: 26
        }
      },
      "7": {
        start: {
          line: 16,
          column: 8
        },
        end: {
          line: 16,
          column: 61
        }
      },
      "8": {
        start: {
          line: 17,
          column: 8
        },
        end: {
          line: 17,
          column: 44
        }
      },
      "9": {
        start: {
          line: 18,
          column: 8
        },
        end: {
          line: 18,
          column: 45
        }
      },
      "10": {
        start: {
          line: 19,
          column: 8
        },
        end: {
          line: 19,
          column: 52
        }
      },
      "11": {
        start: {
          line: 20,
          column: 8
        },
        end: {
          line: 20,
          column: 45
        }
      },
      "12": {
        start: {
          line: 22,
          column: 8
        },
        end: {
          line: 22,
          column: 58
        }
      },
      "13": {
        start: {
          line: 25,
          column: 4
        },
        end: {
          line: 40,
          column: 5
        }
      },
      "14": {
        start: {
          line: 25,
          column: 17
        },
        end: {
          line: 25,
          column: 18
        }
      },
      "15": {
        start: {
          line: 26,
          column: 21
        },
        end: {
          line: 26,
          column: 56
        }
      },
      "16": {
        start: {
          line: 27,
          column: 25
        },
        end: {
          line: 27,
          column: 62
        }
      },
      "17": {
        start: {
          line: 28,
          column: 19
        },
        end: {
          line: 28,
          column: 64
        }
      },
      "18": {
        start: {
          line: 29,
          column: 22
        },
        end: {
          line: 29,
          column: 61
        }
      },
      "19": {
        start: {
          line: 30,
          column: 8
        },
        end: {
          line: 30,
          column: 45
        }
      },
      "20": {
        start: {
          line: 31,
          column: 8
        },
        end: {
          line: 31,
          column: 55
        }
      },
      "21": {
        start: {
          line: 32,
          column: 8
        },
        end: {
          line: 32,
          column: 49
        }
      },
      "22": {
        start: {
          line: 33,
          column: 8
        },
        end: {
          line: 33,
          column: 55
        }
      },
      "23": {
        start: {
          line: 34,
          column: 8
        },
        end: {
          line: 39,
          column: 9
        }
      },
      "24": {
        start: {
          line: 35,
          column: 12
        },
        end: {
          line: 35,
          column: 45
        }
      },
      "25": {
        start: {
          line: 36,
          column: 12
        },
        end: {
          line: 36,
          column: 39
        }
      },
      "26": {
        start: {
          line: 38,
          column: 12
        },
        end: {
          line: 38,
          column: 33
        }
      }
    },
    fnMap: {
      "0": {
        name: "(anonymous_0)",
        decl: {
          start: {
            line: 3,
            column: 44
          },
          end: {
            line: 3,
            column: 45
          }
        },
        loc: {
          start: {
            line: 3,
            column: 50
          },
          end: {
            line: 41,
            column: 1
          }
        },
        line: 3
      }
    },
    branchMap: {
      "0": {
        loc: {
          start: {
            line: 10,
            column: 4
          },
          end: {
            line: 23,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 10,
            column: 4
          },
          end: {
            line: 23,
            column: 5
          }
        }, {
          start: {
            line: 10,
            column: 4
          },
          end: {
            line: 23,
            column: 5
          }
        }],
        line: 10
      },
      "1": {
        loc: {
          start: {
            line: 10,
            column: 8
          },
          end: {
            line: 10,
            column: 85
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 10,
            column: 8
          },
          end: {
            line: 10,
            column: 46
          }
        }, {
          start: {
            line: 10,
            column: 50
          },
          end: {
            line: 10,
            column: 85
          }
        }],
        line: 10
      },
      "2": {
        loc: {
          start: {
            line: 34,
            column: 8
          },
          end: {
            line: 39,
            column: 9
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 34,
            column: 8
          },
          end: {
            line: 39,
            column: 9
          }
        }, {
          start: {
            line: 34,
            column: 8
          },
          end: {
            line: 39,
            column: 9
          }
        }],
        line: 34
      }
    },
    s: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0,
      "11": 0,
      "12": 0,
      "13": 0,
      "14": 0,
      "15": 0,
      "16": 0,
      "17": 0,
      "18": 0,
      "19": 0,
      "20": 0,
      "21": 0,
      "22": 0,
      "23": 0,
      "24": 0,
      "25": 0,
      "26": 0
    },
    f: {
      "0": 0
    },
    b: {
      "0": [0, 0],
      "1": [0, 0],
      "2": [0, 0]
    },
    _coverageSchema: "1a1c01bbd47fc00a2c39e90264f33305004495a9",
    hash: "a273b8fc7e287f7f1452e47d1b8028bd03970175"
  };
  var coverage = global[gcv] || (global[gcv] = {});

  if (!coverage[path] || coverage[path].hash !== hash) {
    coverage[path] = coverageData;
  }

  var actualCoverage = coverage[path];
  {
    // @ts-ignore
    cov_22cumzevu3 = function () {
      return actualCoverage;
    };
  }
  return actualCoverage;
}

cov_22cumzevu3();
cov_22cumzevu3().s[0]++;
// require('../components/TaskItem');
// const TaskItem = require('../components/TaskItem');
window.addEventListener('DOMContentLoaded', () => {
  cov_22cumzevu3().f[0]++;
  let tasks; // holds list nodes in local storage

  let id; // id counter for task items

  let theme; // UI theme

  let volume; // default volume -> initialized to 50

  let state; // state -> initialized to 'default'

  cov_22cumzevu3().s[1]++;

  if ((cov_22cumzevu3().b[1][0]++, localStorage.getItem('tasks') === null) || (cov_22cumzevu3().b[1][1]++, localStorage.getItem('id') === null)) {
    cov_22cumzevu3().b[0][0]++;
    cov_22cumzevu3().s[2]++;
    tasks = [];
    cov_22cumzevu3().s[3]++;
    id = 0;
    cov_22cumzevu3().s[4]++;
    theme = 'light';
    cov_22cumzevu3().s[5]++;
    volume = 50;
    cov_22cumzevu3().s[6]++;
    state = 'default';
    cov_22cumzevu3().s[7]++;
    localStorage.setItem('tasks', JSON.stringify(tasks));
    cov_22cumzevu3().s[8]++;
    localStorage.setItem('id', `${id}`);
    cov_22cumzevu3().s[9]++;
    localStorage.setItem('theme', theme);
    cov_22cumzevu3().s[10]++;
    localStorage.setItem('volume', `${volume}`);
    cov_22cumzevu3().s[11]++;
    localStorage.setItem('state', state);
  } else {
    cov_22cumzevu3().b[0][1]++;
    cov_22cumzevu3().s[12]++;
    tasks = JSON.parse(localStorage.getItem('tasks'));
  } // create task items if exists in local storage


  cov_22cumzevu3().s[13]++;

  for (let i = (cov_22cumzevu3().s[14]++, 0); i < tasks.length; i += 1) {
    const task = (cov_22cumzevu3().s[15]++, document.createElement('task-item'));
    const focusDiv = (cov_22cumzevu3().s[16]++, document.getElementById('focus-task'));
    const ul = (cov_22cumzevu3().s[17]++, document.getElementById('task-list-elements'));
    const title = (cov_22cumzevu3().s[18]++, document.getElementById('select-focus'));
    cov_22cumzevu3().s[19]++;
    task.setAttribute('id', tasks[i].id);
    cov_22cumzevu3().s[20]++;
    task.setAttribute('checked', tasks[i].checked);
    cov_22cumzevu3().s[21]++;
    task.setAttribute('text', tasks[i].text);
    cov_22cumzevu3().s[22]++;
    task.setAttribute('focused', tasks[i].focused);
    cov_22cumzevu3().s[23]++;

    if (tasks[i].focused === true) {
      cov_22cumzevu3().b[2][0]++;
      cov_22cumzevu3().s[24]++;
      title.innerHTML = 'Focusing on:';
      cov_22cumzevu3().s[25]++;
      focusDiv.appendChild(task);
    } else {
      cov_22cumzevu3().b[2][1]++;
      cov_22cumzevu3().s[26]++;
      ul.appendChild(task);
    }
  }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNjcmlwdC5qcyJdLCJuYW1lcyI6WyJ3aW5kb3ciLCJhZGRFdmVudExpc3RlbmVyIiwidGFza3MiLCJpZCIsInRoZW1lIiwidm9sdW1lIiwic3RhdGUiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwic2V0SXRlbSIsIkpTT04iLCJzdHJpbmdpZnkiLCJwYXJzZSIsImkiLCJsZW5ndGgiLCJ0YXNrIiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50IiwiZm9jdXNEaXYiLCJnZXRFbGVtZW50QnlJZCIsInVsIiwidGl0bGUiLCJzZXRBdHRyaWJ1dGUiLCJjaGVja2VkIiwidGV4dCIsImZvY3VzZWQiLCJpbm5lckhUTUwiLCJhcHBlbmRDaGlsZCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWVZOzs7Ozs7Ozs7O0FBZlo7QUFDQTtBQUNBQSxNQUFNLENBQUNDLGdCQUFQLENBQXdCLGtCQUF4QixFQUE0QyxNQUFNO0FBQUE7QUFDOUMsTUFBSUMsS0FBSixDQUQ4QyxDQUNuQzs7QUFDWCxNQUFJQyxFQUFKLENBRjhDLENBRXRDOztBQUNSLE1BQUlDLEtBQUosQ0FIOEMsQ0FHbkM7O0FBQ1gsTUFBSUMsTUFBSixDQUo4QyxDQUlsQzs7QUFDWixNQUFJQyxLQUFKLENBTDhDLENBS25DOztBQUxtQzs7QUFPOUMsTUFBSSw2QkFBQUMsWUFBWSxDQUFDQyxPQUFiLENBQXFCLE9BQXJCLE1BQWtDLElBQWxDLGtDQUEwQ0QsWUFBWSxDQUFDQyxPQUFiLENBQXFCLElBQXJCLE1BQStCLElBQXpFLENBQUosRUFBbUY7QUFBQTtBQUFBO0FBQy9FTixJQUFBQSxLQUFLLEdBQUcsRUFBUjtBQUQrRTtBQUUvRUMsSUFBQUEsRUFBRSxHQUFHLENBQUw7QUFGK0U7QUFHL0VDLElBQUFBLEtBQUssR0FBRyxPQUFSO0FBSCtFO0FBSS9FQyxJQUFBQSxNQUFNLEdBQUcsRUFBVDtBQUorRTtBQUsvRUMsSUFBQUEsS0FBSyxHQUFHLFNBQVI7QUFMK0U7QUFNL0VDLElBQUFBLFlBQVksQ0FBQ0UsT0FBYixDQUFxQixPQUFyQixFQUE4QkMsSUFBSSxDQUFDQyxTQUFMLENBQWVULEtBQWYsQ0FBOUI7QUFOK0U7QUFPL0VLLElBQUFBLFlBQVksQ0FBQ0UsT0FBYixDQUFxQixJQUFyQixFQUE0QixHQUFFTixFQUFHLEVBQWpDO0FBUCtFO0FBUS9FSSxJQUFBQSxZQUFZLENBQUNFLE9BQWIsQ0FBcUIsT0FBckIsRUFBOEJMLEtBQTlCO0FBUitFO0FBUy9FRyxJQUFBQSxZQUFZLENBQUNFLE9BQWIsQ0FBcUIsUUFBckIsRUFBZ0MsR0FBRUosTUFBTyxFQUF6QztBQVQrRTtBQVUvRUUsSUFBQUEsWUFBWSxDQUFDRSxPQUFiLENBQXFCLE9BQXJCLEVBQThCSCxLQUE5QjtBQUNILEdBWEQsTUFXTztBQUFBO0FBQUE7QUFDSEosSUFBQUEsS0FBSyxHQUFHUSxJQUFJLENBQUNFLEtBQUwsQ0FBV0wsWUFBWSxDQUFDQyxPQUFiLENBQXFCLE9BQXJCLENBQVgsQ0FBUjtBQUNILEdBcEI2QyxDQXFCOUM7OztBQXJCOEM7O0FBc0I5QyxPQUFLLElBQUlLLENBQUMsOEJBQUcsQ0FBSCxDQUFWLEVBQWdCQSxDQUFDLEdBQUdYLEtBQUssQ0FBQ1ksTUFBMUIsRUFBa0NELENBQUMsSUFBSSxDQUF2QyxFQUEwQztBQUN0QyxVQUFNRSxJQUFJLDhCQUFHQyxRQUFRLENBQUNDLGFBQVQsQ0FBdUIsV0FBdkIsQ0FBSCxDQUFWO0FBQ0EsVUFBTUMsUUFBUSw4QkFBR0YsUUFBUSxDQUFDRyxjQUFULENBQXdCLFlBQXhCLENBQUgsQ0FBZDtBQUNBLFVBQU1DLEVBQUUsOEJBQUdKLFFBQVEsQ0FBQ0csY0FBVCxDQUF3QixvQkFBeEIsQ0FBSCxDQUFSO0FBQ0EsVUFBTUUsS0FBSyw4QkFBR0wsUUFBUSxDQUFDRyxjQUFULENBQXdCLGNBQXhCLENBQUgsQ0FBWDtBQUpzQztBQUt0Q0osSUFBQUEsSUFBSSxDQUFDTyxZQUFMLENBQWtCLElBQWxCLEVBQXdCcEIsS0FBSyxDQUFDVyxDQUFELENBQUwsQ0FBU1YsRUFBakM7QUFMc0M7QUFNdENZLElBQUFBLElBQUksQ0FBQ08sWUFBTCxDQUFrQixTQUFsQixFQUE2QnBCLEtBQUssQ0FBQ1csQ0FBRCxDQUFMLENBQVNVLE9BQXRDO0FBTnNDO0FBT3RDUixJQUFBQSxJQUFJLENBQUNPLFlBQUwsQ0FBa0IsTUFBbEIsRUFBMEJwQixLQUFLLENBQUNXLENBQUQsQ0FBTCxDQUFTVyxJQUFuQztBQVBzQztBQVF0Q1QsSUFBQUEsSUFBSSxDQUFDTyxZQUFMLENBQWtCLFNBQWxCLEVBQTZCcEIsS0FBSyxDQUFDVyxDQUFELENBQUwsQ0FBU1ksT0FBdEM7QUFSc0M7O0FBU3RDLFFBQUl2QixLQUFLLENBQUNXLENBQUQsQ0FBTCxDQUFTWSxPQUFULEtBQXFCLElBQXpCLEVBQStCO0FBQUE7QUFBQTtBQUMzQkosTUFBQUEsS0FBSyxDQUFDSyxTQUFOLEdBQWtCLGNBQWxCO0FBRDJCO0FBRTNCUixNQUFBQSxRQUFRLENBQUNTLFdBQVQsQ0FBcUJaLElBQXJCO0FBQ0gsS0FIRCxNQUdPO0FBQUE7QUFBQTtBQUNISyxNQUFBQSxFQUFFLENBQUNPLFdBQUgsQ0FBZVosSUFBZjtBQUNIO0FBQ0o7QUFDSixDQXRDRCIsInNvdXJjZXNDb250ZW50IjpbIi8vIHJlcXVpcmUoJy4uL2NvbXBvbmVudHMvVGFza0l0ZW0nKTtcclxuLy8gY29uc3QgVGFza0l0ZW0gPSByZXF1aXJlKCcuLi9jb21wb25lbnRzL1Rhc2tJdGVtJyk7XHJcbndpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdET01Db250ZW50TG9hZGVkJywgKCkgPT4ge1xyXG4gICAgbGV0IHRhc2tzOyAvLyBob2xkcyBsaXN0IG5vZGVzIGluIGxvY2FsIHN0b3JhZ2VcclxuICAgIGxldCBpZDsgLy8gaWQgY291bnRlciBmb3IgdGFzayBpdGVtc1xyXG4gICAgbGV0IHRoZW1lOyAvLyBVSSB0aGVtZVxyXG4gICAgbGV0IHZvbHVtZTsgLy8gZGVmYXVsdCB2b2x1bWUgLT4gaW5pdGlhbGl6ZWQgdG8gNTBcclxuICAgIGxldCBzdGF0ZTsgLy8gc3RhdGUgLT4gaW5pdGlhbGl6ZWQgdG8gJ2RlZmF1bHQnXHJcblxyXG4gICAgaWYgKGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd0YXNrcycpID09PSBudWxsIHx8IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdpZCcpID09PSBudWxsKSB7XHJcbiAgICAgICAgdGFza3MgPSBbXTtcclxuICAgICAgICBpZCA9IDA7XHJcbiAgICAgICAgdGhlbWUgPSAnbGlnaHQnO1xyXG4gICAgICAgIHZvbHVtZSA9IDUwO1xyXG4gICAgICAgIHN0YXRlID0gJ2RlZmF1bHQnO1xyXG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCd0YXNrcycsIEpTT04uc3RyaW5naWZ5KHRhc2tzKSk7XHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2lkJywgYCR7aWR9YCk7XHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3RoZW1lJywgdGhlbWUpO1xyXG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCd2b2x1bWUnLCBgJHt2b2x1bWV9YCk7XHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3N0YXRlJywgc3RhdGUpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICB0YXNrcyA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3Rhc2tzJykpO1xyXG4gICAgfVxyXG4gICAgLy8gY3JlYXRlIHRhc2sgaXRlbXMgaWYgZXhpc3RzIGluIGxvY2FsIHN0b3JhZ2VcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGFza3MubGVuZ3RoOyBpICs9IDEpIHtcclxuICAgICAgICBjb25zdCB0YXNrID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgndGFzay1pdGVtJyk7XHJcbiAgICAgICAgY29uc3QgZm9jdXNEaXYgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZm9jdXMtdGFzaycpO1xyXG4gICAgICAgIGNvbnN0IHVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Rhc2stbGlzdC1lbGVtZW50cycpO1xyXG4gICAgICAgIGNvbnN0IHRpdGxlID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3NlbGVjdC1mb2N1cycpO1xyXG4gICAgICAgIHRhc2suc2V0QXR0cmlidXRlKCdpZCcsIHRhc2tzW2ldLmlkKTtcclxuICAgICAgICB0YXNrLnNldEF0dHJpYnV0ZSgnY2hlY2tlZCcsIHRhc2tzW2ldLmNoZWNrZWQpO1xyXG4gICAgICAgIHRhc2suc2V0QXR0cmlidXRlKCd0ZXh0JywgdGFza3NbaV0udGV4dCk7XHJcbiAgICAgICAgdGFzay5zZXRBdHRyaWJ1dGUoJ2ZvY3VzZWQnLCB0YXNrc1tpXS5mb2N1c2VkKTtcclxuICAgICAgICBpZiAodGFza3NbaV0uZm9jdXNlZCA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgICB0aXRsZS5pbm5lckhUTUwgPSAnRm9jdXNpbmcgb246JztcclxuICAgICAgICAgICAgZm9jdXNEaXYuYXBwZW5kQ2hpbGQodGFzayk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdWwuYXBwZW5kQ2hpbGQodGFzayk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59KTtcclxuIl19
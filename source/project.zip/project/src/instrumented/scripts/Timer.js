function cov_1ea36y1nz0() {
  var path = "D:\\\u5B66\u4E60\\21WI\\CSE110\\cse110-w21-group13\\source\\src\\scripts\\Timer.js";
  var hash = "4c58a77a9c827c30aee49351594460dafe5c0731";
  var global = new Function("return this")();
  var gcv = "__coverage__";
  var coverageData = {
    path: "D:\\\u5B66\u4E60\\21WI\\CSE110\\cse110-w21-group13\\source\\src\\scripts\\Timer.js",
    statementMap: {
      "0": {
        start: {
          line: 1,
          column: 20
        },
        end: {
          line: 1,
          column: 56
        }
      },
      "1": {
        start: {
          line: 2,
          column: 29
        },
        end: {
          line: 2,
          column: 78
        }
      },
      "2": {
        start: {
          line: 3,
          column: 17
        },
        end: {
          line: 3,
          column: 50
        }
      },
      "3": {
        start: {
          line: 4,
          column: 19
        },
        end: {
          line: 4,
          column: 49
        }
      },
      "4": {
        start: {
          line: 5,
          column: 15
        },
        end: {
          line: 5,
          column: 19
        }
      },
      "5": {
        start: {
          line: 7,
          column: 18
        },
        end: {
          line: 7,
          column: 24
        }
      },
      "6": {
        start: {
          line: 8,
          column: 19
        },
        end: {
          line: 8,
          column: 20
        }
      },
      "7": {
        start: {
          line: 10,
          column: 18
        },
        end: {
          line: 10,
          column: 47
        }
      },
      "8": {
        start: {
          line: 13,
          column: 0
        },
        end: {
          line: 17,
          column: 1
        }
      },
      "9": {
        start: {
          line: 14,
          column: 4
        },
        end: {
          line: 14,
          column: 46
        }
      },
      "10": {
        start: {
          line: 15,
          column: 4
        },
        end: {
          line: 15,
          column: 52
        }
      },
      "11": {
        start: {
          line: 16,
          column: 4
        },
        end: {
          line: 16,
          column: 52
        }
      },
      "12": {
        start: {
          line: 18,
          column: 15
        },
        end: {
          line: 18,
          column: 50
        }
      },
      "13": {
        start: {
          line: 19,
          column: 16
        },
        end: {
          line: 19,
          column: 58
        }
      },
      "14": {
        start: {
          line: 20,
          column: 20
        },
        end: {
          line: 20,
          column: 61
        }
      },
      "15": {
        start: {
          line: 22,
          column: 0
        },
        end: {
          line: 22,
          column: 50
        }
      },
      "16": {
        start: {
          line: 25,
          column: 23
        },
        end: {
          line: 25,
          column: 58
        }
      },
      "17": {
        start: {
          line: 26,
          column: 24
        },
        end: {
          line: 26,
          column: 60
        }
      },
      "18": {
        start: {
          line: 28,
          column: 4
        },
        end: {
          line: 51,
          column: 5
        }
      },
      "19": {
        start: {
          line: 29,
          column: 8
        },
        end: {
          line: 29,
          column: 63
        }
      },
      "20": {
        start: {
          line: 30,
          column: 8
        },
        end: {
          line: 33,
          column: 9
        }
      },
      "21": {
        start: {
          line: 31,
          column: 12
        },
        end: {
          line: 31,
          column: 50
        }
      },
      "22": {
        start: {
          line: 32,
          column: 12
        },
        end: {
          line: 32,
          column: 51
        }
      },
      "23": {
        start: {
          line: 34,
          column: 8
        },
        end: {
          line: 34,
          column: 30
        }
      },
      "24": {
        start: {
          line: 35,
          column: 8
        },
        end: {
          line: 35,
          column: 25
        }
      },
      "25": {
        start: {
          line: 36,
          column: 11
        },
        end: {
          line: 51,
          column: 5
        }
      },
      "26": {
        start: {
          line: 37,
          column: 8
        },
        end: {
          line: 37,
          column: 59
        }
      },
      "27": {
        start: {
          line: 38,
          column: 8
        },
        end: {
          line: 41,
          column: 9
        }
      },
      "28": {
        start: {
          line: 39,
          column: 12
        },
        end: {
          line: 39,
          column: 50
        }
      },
      "29": {
        start: {
          line: 40,
          column: 12
        },
        end: {
          line: 40,
          column: 51
        }
      },
      "30": {
        start: {
          line: 42,
          column: 8
        },
        end: {
          line: 42,
          column: 30
        }
      },
      "31": {
        start: {
          line: 43,
          column: 8
        },
        end: {
          line: 43,
          column: 26
        }
      },
      "32": {
        start: {
          line: 45,
          column: 8
        },
        end: {
          line: 45,
          column: 58
        }
      },
      "33": {
        start: {
          line: 46,
          column: 8
        },
        end: {
          line: 49,
          column: 9
        }
      },
      "34": {
        start: {
          line: 47,
          column: 12
        },
        end: {
          line: 47,
          column: 50
        }
      },
      "35": {
        start: {
          line: 48,
          column: 12
        },
        end: {
          line: 48,
          column: 51
        }
      },
      "36": {
        start: {
          line: 50,
          column: 8
        },
        end: {
          line: 50,
          column: 29
        }
      },
      "37": {
        start: {
          line: 55,
          column: 20
        },
        end: {
          line: 55,
          column: 50
        }
      },
      "38": {
        start: {
          line: 57,
          column: 4
        },
        end: {
          line: 60,
          column: 5
        }
      },
      "39": {
        start: {
          line: 58,
          column: 8
        },
        end: {
          line: 58,
          column: 21
        }
      },
      "40": {
        start: {
          line: 59,
          column: 8
        },
        end: {
          line: 59,
          column: 51
        }
      },
      "41": {
        start: {
          line: 62,
          column: 4
        },
        end: {
          line: 66,
          column: 5
        }
      },
      "42": {
        start: {
          line: 63,
          column: 8
        },
        end: {
          line: 63,
          column: 80
        }
      },
      "43": {
        start: {
          line: 65,
          column: 8
        },
        end: {
          line: 65,
          column: 26
        }
      },
      "44": {
        start: {
          line: 68,
          column: 18
        },
        end: {
          line: 68,
          column: 70
        }
      },
      "45": {
        start: {
          line: 69,
          column: 18
        },
        end: {
          line: 69,
          column: 67
        }
      },
      "46": {
        start: {
          line: 71,
          column: 4
        },
        end: {
          line: 76,
          column: 5
        }
      },
      "47": {
        start: {
          line: 72,
          column: 8
        },
        end: {
          line: 72,
          column: 21
        }
      },
      "48": {
        start: {
          line: 74,
          column: 8
        },
        end: {
          line: 74,
          column: 21
        }
      },
      "49": {
        start: {
          line: 75,
          column: 8
        },
        end: {
          line: 75,
          column: 21
        }
      },
      "50": {
        start: {
          line: 78,
          column: 4
        },
        end: {
          line: 80,
          column: 5
        }
      },
      "51": {
        start: {
          line: 79,
          column: 8
        },
        end: {
          line: 79,
          column: 40
        }
      },
      "52": {
        start: {
          line: 82,
          column: 4
        },
        end: {
          line: 82,
          column: 61
        }
      },
      "53": {
        start: {
          line: 86,
          column: 4
        },
        end: {
          line: 89,
          column: 5
        }
      },
      "54": {
        start: {
          line: 87,
          column: 8
        },
        end: {
          line: 87,
          column: 15
        }
      },
      "55": {
        start: {
          line: 88,
          column: 8
        },
        end: {
          line: 88,
          column: 46
        }
      },
      "56": {
        start: {
          line: 93,
          column: 4
        },
        end: {
          line: 93,
          column: 35
        }
      },
      "57": {
        start: {
          line: 94,
          column: 4
        },
        end: {
          line: 94,
          column: 47
        }
      },
      "58": {
        start: {
          line: 98,
          column: 4
        },
        end: {
          line: 98,
          column: 51
        }
      },
      "59": {
        start: {
          line: 99,
          column: 4
        },
        end: {
          line: 99,
          column: 59
        }
      },
      "60": {
        start: {
          line: 100,
          column: 4
        },
        end: {
          line: 100,
          column: 62
        }
      },
      "61": {
        start: {
          line: 101,
          column: 4
        },
        end: {
          line: 101,
          column: 25
        }
      },
      "62": {
        start: {
          line: 102,
          column: 4
        },
        end: {
          line: 102,
          column: 26
        }
      },
      "63": {
        start: {
          line: 103,
          column: 4
        },
        end: {
          line: 103,
          column: 40
        }
      },
      "64": {
        start: {
          line: 104,
          column: 4
        },
        end: {
          line: 104,
          column: 21
        }
      },
      "65": {
        start: {
          line: 105,
          column: 4
        },
        end: {
          line: 105,
          column: 36
        }
      },
      "66": {
        start: {
          line: 109,
          column: 4
        },
        end: {
          line: 109,
          column: 74
        }
      },
      "67": {
        start: {
          line: 110,
          column: 4
        },
        end: {
          line: 110,
          column: 20
        }
      },
      "68": {
        start: {
          line: 111,
          column: 4
        },
        end: {
          line: 115,
          column: 5
        }
      },
      "69": {
        start: {
          line: 112,
          column: 8
        },
        end: {
          line: 112,
          column: 16
        }
      },
      "70": {
        start: {
          line: 114,
          column: 8
        },
        end: {
          line: 114,
          column: 15
        }
      },
      "71": {
        start: {
          line: 117,
          column: 0
        },
        end: {
          line: 117,
          column: 58
        }
      },
      "72": {
        start: {
          line: 119,
          column: 0
        },
        end: {
          line: 175,
          column: 3
        }
      },
      "73": {
        start: {
          line: 120,
          column: 19
        },
        end: {
          line: 120,
          column: 113
        }
      },
      "74": {
        start: {
          line: 121,
          column: 19
        },
        end: {
          line: 121,
          column: 125
        }
      },
      "75": {
        start: {
          line: 122,
          column: 19
        },
        end: {
          line: 122,
          column: 119
        }
      },
      "76": {
        start: {
          line: 123,
          column: 20
        },
        end: {
          line: 123,
          column: 110
        }
      },
      "77": {
        start: {
          line: 124,
          column: 4
        },
        end: {
          line: 174,
          column: 5
        }
      },
      "78": {
        start: {
          line: 125,
          column: 8
        },
        end: {
          line: 165,
          column: 9
        }
      },
      "79": {
        start: {
          line: 127,
          column: 12
        },
        end: {
          line: 127,
          column: 82
        }
      },
      "80": {
        start: {
          line: 128,
          column: 12
        },
        end: {
          line: 128,
          column: 28
        }
      },
      "81": {
        start: {
          line: 129,
          column: 12
        },
        end: {
          line: 129,
          column: 60
        }
      },
      "82": {
        start: {
          line: 130,
          column: 12
        },
        end: {
          line: 130,
          column: 18
        }
      },
      "83": {
        start: {
          line: 132,
          column: 12
        },
        end: {
          line: 132,
          column: 32
        }
      },
      "84": {
        start: {
          line: 133,
          column: 12
        },
        end: {
          line: 133,
          column: 18
        }
      },
      "85": {
        start: {
          line: 135,
          column: 12
        },
        end: {
          line: 135,
          column: 60
        }
      },
      "86": {
        start: {
          line: 136,
          column: 12
        },
        end: {
          line: 136,
          column: 18
        }
      },
      "87": {
        start: {
          line: 138,
          column: 12
        },
        end: {
          line: 138,
          column: 59
        }
      },
      "88": {
        start: {
          line: 139,
          column: 12
        },
        end: {
          line: 139,
          column: 18
        }
      },
      "89": {
        start: {
          line: 141,
          column: 12
        },
        end: {
          line: 141,
          column: 62
        }
      },
      "90": {
        start: {
          line: 142,
          column: 12
        },
        end: {
          line: 142,
          column: 18
        }
      },
      "91": {
        start: {
          line: 144,
          column: 12
        },
        end: {
          line: 150,
          column: 13
        }
      },
      "92": {
        start: {
          line: 145,
          column: 16
        },
        end: {
          line: 145,
          column: 112
        }
      },
      "93": {
        start: {
          line: 146,
          column: 19
        },
        end: {
          line: 150,
          column: 13
        }
      },
      "94": {
        start: {
          line: 147,
          column: 16
        },
        end: {
          line: 147,
          column: 109
        }
      },
      "95": {
        start: {
          line: 148,
          column: 19
        },
        end: {
          line: 150,
          column: 13
        }
      },
      "96": {
        start: {
          line: 149,
          column: 16
        },
        end: {
          line: 149,
          column: 108
        }
      },
      "97": {
        start: {
          line: 151,
          column: 12
        },
        end: {
          line: 151,
          column: 18
        }
      },
      "98": {
        start: {
          line: 153,
          column: 26
        },
        end: {
          line: 153,
          column: 55
        }
      },
      "99": {
        start: {
          line: 154,
          column: 12
        },
        end: {
          line: 154,
          column: 87
        }
      },
      "100": {
        start: {
          line: 154,
          column: 37
        },
        end: {
          line: 154,
          column: 87
        }
      },
      "101": {
        start: {
          line: 155,
          column: 12
        },
        end: {
          line: 155,
          column: 18
        }
      },
      "102": {
        start: {
          line: 157,
          column: 12
        },
        end: {
          line: 161,
          column: 13
        }
      },
      "103": {
        start: {
          line: 158,
          column: 16
        },
        end: {
          line: 158,
          column: 122
        }
      },
      "104": {
        start: {
          line: 159,
          column: 19
        },
        end: {
          line: 161,
          column: 13
        }
      },
      "105": {
        start: {
          line: 160,
          column: 16
        },
        end: {
          line: 160,
          column: 116
        }
      },
      "106": {
        start: {
          line: 162,
          column: 12
        },
        end: {
          line: 162,
          column: 18
        }
      },
      "107": {
        start: {
          line: 164,
          column: 12
        },
        end: {
          line: 164,
          column: 18
        }
      },
      "108": {
        start: {
          line: 166,
          column: 11
        },
        end: {
          line: 174,
          column: 5
        }
      },
      "109": {
        start: {
          line: 167,
          column: 8
        },
        end: {
          line: 172,
          column: 9
        }
      },
      "110": {
        start: {
          line: 168,
          column: 12
        },
        end: {
          line: 168,
          column: 106
        }
      },
      "111": {
        start: {
          line: 169,
          column: 15
        },
        end: {
          line: 172,
          column: 9
        }
      },
      "112": {
        start: {
          line: 170,
          column: 12
        },
        end: {
          line: 170,
          column: 104
        }
      }
    },
    fnMap: {
      "0": {
        name: "switchMode",
        decl: {
          start: {
            line: 24,
            column: 9
          },
          end: {
            line: 24,
            column: 19
          }
        },
        loc: {
          start: {
            line: 24,
            column: 22
          },
          end: {
            line: 52,
            column: 1
          }
        },
        line: 24
      },
      "1": {
        name: "timerFunction",
        decl: {
          start: {
            line: 54,
            column: 15
          },
          end: {
            line: 54,
            column: 28
          }
        },
        loc: {
          start: {
            line: 54,
            column: 31
          },
          end: {
            line: 83,
            column: 1
          }
        },
        line: 54
      },
      "2": {
        name: "stopChecker",
        decl: {
          start: {
            line: 85,
            column: 15
          },
          end: {
            line: 85,
            column: 26
          }
        },
        loc: {
          start: {
            line: 85,
            column: 29
          },
          end: {
            line: 90,
            column: 1
          }
        },
        line: 85
      },
      "3": {
        name: "start",
        decl: {
          start: {
            line: 92,
            column: 15
          },
          end: {
            line: 92,
            column: 20
          }
        },
        loc: {
          start: {
            line: 92,
            column: 23
          },
          end: {
            line: 95,
            column: 1
          }
        },
        line: 92
      },
      "4": {
        name: "stop",
        decl: {
          start: {
            line: 97,
            column: 15
          },
          end: {
            line: 97,
            column: 19
          }
        },
        loc: {
          start: {
            line: 97,
            column: 22
          },
          end: {
            line: 106,
            column: 1
          }
        },
        line: 97
      },
      "5": {
        name: "startAndStopButton",
        decl: {
          start: {
            line: 108,
            column: 15
          },
          end: {
            line: 108,
            column: 33
          }
        },
        loc: {
          start: {
            line: 108,
            column: 36
          },
          end: {
            line: 116,
            column: 1
          }
        },
        line: 108
      },
      "6": {
        name: "(anonymous_6)",
        decl: {
          start: {
            line: 119,
            column: 33
          },
          end: {
            line: 119,
            column: 34
          }
        },
        loc: {
          start: {
            line: 119,
            column: 44
          },
          end: {
            line: 175,
            column: 1
          }
        },
        line: 119
      }
    },
    branchMap: {
      "0": {
        loc: {
          start: {
            line: 13,
            column: 0
          },
          end: {
            line: 17,
            column: 1
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 13,
            column: 0
          },
          end: {
            line: 17,
            column: 1
          }
        }, {
          start: {
            line: 13,
            column: 0
          },
          end: {
            line: 17,
            column: 1
          }
        }],
        line: 13
      },
      "1": {
        loc: {
          start: {
            line: 28,
            column: 4
          },
          end: {
            line: 51,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 28,
            column: 4
          },
          end: {
            line: 51,
            column: 5
          }
        }, {
          start: {
            line: 28,
            column: 4
          },
          end: {
            line: 51,
            column: 5
          }
        }],
        line: 28
      },
      "2": {
        loc: {
          start: {
            line: 28,
            column: 8
          },
          end: {
            line: 28,
            column: 51
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 28,
            column: 8
          },
          end: {
            line: 28,
            column: 30
          }
        }, {
          start: {
            line: 28,
            column: 34
          },
          end: {
            line: 28,
            column: 51
          }
        }],
        line: 28
      },
      "3": {
        loc: {
          start: {
            line: 30,
            column: 8
          },
          end: {
            line: 33,
            column: 9
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 30,
            column: 8
          },
          end: {
            line: 33,
            column: 9
          }
        }, {
          start: {
            line: 30,
            column: 8
          },
          end: {
            line: 33,
            column: 9
          }
        }],
        line: 30
      },
      "4": {
        loc: {
          start: {
            line: 36,
            column: 11
          },
          end: {
            line: 51,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 36,
            column: 11
          },
          end: {
            line: 51,
            column: 5
          }
        }, {
          start: {
            line: 36,
            column: 11
          },
          end: {
            line: 51,
            column: 5
          }
        }],
        line: 36
      },
      "5": {
        loc: {
          start: {
            line: 38,
            column: 8
          },
          end: {
            line: 41,
            column: 9
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 38,
            column: 8
          },
          end: {
            line: 41,
            column: 9
          }
        }, {
          start: {
            line: 38,
            column: 8
          },
          end: {
            line: 41,
            column: 9
          }
        }],
        line: 38
      },
      "6": {
        loc: {
          start: {
            line: 46,
            column: 8
          },
          end: {
            line: 49,
            column: 9
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 46,
            column: 8
          },
          end: {
            line: 49,
            column: 9
          }
        }, {
          start: {
            line: 46,
            column: 8
          },
          end: {
            line: 49,
            column: 9
          }
        }],
        line: 46
      },
      "7": {
        loc: {
          start: {
            line: 57,
            column: 4
          },
          end: {
            line: 60,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 57,
            column: 4
          },
          end: {
            line: 60,
            column: 5
          }
        }, {
          start: {
            line: 57,
            column: 4
          },
          end: {
            line: 60,
            column: 5
          }
        }],
        line: 57
      },
      "8": {
        loc: {
          start: {
            line: 62,
            column: 4
          },
          end: {
            line: 66,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 62,
            column: 4
          },
          end: {
            line: 66,
            column: 5
          }
        }, {
          start: {
            line: 62,
            column: 4
          },
          end: {
            line: 66,
            column: 5
          }
        }],
        line: 62
      },
      "9": {
        loc: {
          start: {
            line: 71,
            column: 4
          },
          end: {
            line: 76,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 71,
            column: 4
          },
          end: {
            line: 76,
            column: 5
          }
        }, {
          start: {
            line: 71,
            column: 4
          },
          end: {
            line: 76,
            column: 5
          }
        }],
        line: 71
      },
      "10": {
        loc: {
          start: {
            line: 78,
            column: 4
          },
          end: {
            line: 80,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 78,
            column: 4
          },
          end: {
            line: 80,
            column: 5
          }
        }, {
          start: {
            line: 78,
            column: 4
          },
          end: {
            line: 80,
            column: 5
          }
        }],
        line: 78
      },
      "11": {
        loc: {
          start: {
            line: 86,
            column: 4
          },
          end: {
            line: 89,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 86,
            column: 4
          },
          end: {
            line: 89,
            column: 5
          }
        }, {
          start: {
            line: 86,
            column: 4
          },
          end: {
            line: 89,
            column: 5
          }
        }],
        line: 86
      },
      "12": {
        loc: {
          start: {
            line: 111,
            column: 4
          },
          end: {
            line: 115,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 111,
            column: 4
          },
          end: {
            line: 115,
            column: 5
          }
        }, {
          start: {
            line: 111,
            column: 4
          },
          end: {
            line: 115,
            column: 5
          }
        }],
        line: 111
      },
      "13": {
        loc: {
          start: {
            line: 124,
            column: 4
          },
          end: {
            line: 174,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 124,
            column: 4
          },
          end: {
            line: 174,
            column: 5
          }
        }, {
          start: {
            line: 124,
            column: 4
          },
          end: {
            line: 174,
            column: 5
          }
        }],
        line: 124
      },
      "14": {
        loc: {
          start: {
            line: 124,
            column: 8
          },
          end: {
            line: 124,
            column: 36
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 124,
            column: 8
          },
          end: {
            line: 124,
            column: 15
          }
        }, {
          start: {
            line: 124,
            column: 19
          },
          end: {
            line: 124,
            column: 36
          }
        }],
        line: 124
      },
      "15": {
        loc: {
          start: {
            line: 125,
            column: 8
          },
          end: {
            line: 165,
            column: 9
          }
        },
        type: "switch",
        locations: [{
          start: {
            line: 126,
            column: 8
          },
          end: {
            line: 130,
            column: 18
          }
        }, {
          start: {
            line: 131,
            column: 8
          },
          end: {
            line: 133,
            column: 18
          }
        }, {
          start: {
            line: 134,
            column: 8
          },
          end: {
            line: 136,
            column: 18
          }
        }, {
          start: {
            line: 137,
            column: 8
          },
          end: {
            line: 139,
            column: 18
          }
        }, {
          start: {
            line: 140,
            column: 8
          },
          end: {
            line: 142,
            column: 18
          }
        }, {
          start: {
            line: 143,
            column: 8
          },
          end: {
            line: 151,
            column: 18
          }
        }, {
          start: {
            line: 152,
            column: 8
          },
          end: {
            line: 155,
            column: 18
          }
        }, {
          start: {
            line: 156,
            column: 8
          },
          end: {
            line: 162,
            column: 18
          }
        }, {
          start: {
            line: 163,
            column: 8
          },
          end: {
            line: 164,
            column: 18
          }
        }],
        line: 125
      },
      "16": {
        loc: {
          start: {
            line: 144,
            column: 12
          },
          end: {
            line: 150,
            column: 13
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 144,
            column: 12
          },
          end: {
            line: 150,
            column: 13
          }
        }, {
          start: {
            line: 144,
            column: 12
          },
          end: {
            line: 150,
            column: 13
          }
        }],
        line: 144
      },
      "17": {
        loc: {
          start: {
            line: 146,
            column: 19
          },
          end: {
            line: 150,
            column: 13
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 146,
            column: 19
          },
          end: {
            line: 150,
            column: 13
          }
        }, {
          start: {
            line: 146,
            column: 19
          },
          end: {
            line: 150,
            column: 13
          }
        }],
        line: 146
      },
      "18": {
        loc: {
          start: {
            line: 148,
            column: 19
          },
          end: {
            line: 150,
            column: 13
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 148,
            column: 19
          },
          end: {
            line: 150,
            column: 13
          }
        }, {
          start: {
            line: 148,
            column: 19
          },
          end: {
            line: 150,
            column: 13
          }
        }],
        line: 148
      },
      "19": {
        loc: {
          start: {
            line: 154,
            column: 12
          },
          end: {
            line: 154,
            column: 87
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 154,
            column: 12
          },
          end: {
            line: 154,
            column: 87
          }
        }, {
          start: {
            line: 154,
            column: 12
          },
          end: {
            line: 154,
            column: 87
          }
        }],
        line: 154
      },
      "20": {
        loc: {
          start: {
            line: 157,
            column: 12
          },
          end: {
            line: 161,
            column: 13
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 157,
            column: 12
          },
          end: {
            line: 161,
            column: 13
          }
        }, {
          start: {
            line: 157,
            column: 12
          },
          end: {
            line: 161,
            column: 13
          }
        }],
        line: 157
      },
      "21": {
        loc: {
          start: {
            line: 159,
            column: 19
          },
          end: {
            line: 161,
            column: 13
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 159,
            column: 19
          },
          end: {
            line: 161,
            column: 13
          }
        }, {
          start: {
            line: 159,
            column: 19
          },
          end: {
            line: 161,
            column: 13
          }
        }],
        line: 159
      },
      "22": {
        loc: {
          start: {
            line: 166,
            column: 11
          },
          end: {
            line: 174,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 166,
            column: 11
          },
          end: {
            line: 174,
            column: 5
          }
        }, {
          start: {
            line: 166,
            column: 11
          },
          end: {
            line: 174,
            column: 5
          }
        }],
        line: 166
      },
      "23": {
        loc: {
          start: {
            line: 167,
            column: 8
          },
          end: {
            line: 172,
            column: 9
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 167,
            column: 8
          },
          end: {
            line: 172,
            column: 9
          }
        }, {
          start: {
            line: 167,
            column: 8
          },
          end: {
            line: 172,
            column: 9
          }
        }],
        line: 167
      },
      "24": {
        loc: {
          start: {
            line: 169,
            column: 15
          },
          end: {
            line: 172,
            column: 9
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 169,
            column: 15
          },
          end: {
            line: 172,
            column: 9
          }
        }, {
          start: {
            line: 169,
            column: 15
          },
          end: {
            line: 172,
            column: 9
          }
        }],
        line: 169
      }
    },
    s: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0,
      "11": 0,
      "12": 0,
      "13": 0,
      "14": 0,
      "15": 0,
      "16": 0,
      "17": 0,
      "18": 0,
      "19": 0,
      "20": 0,
      "21": 0,
      "22": 0,
      "23": 0,
      "24": 0,
      "25": 0,
      "26": 0,
      "27": 0,
      "28": 0,
      "29": 0,
      "30": 0,
      "31": 0,
      "32": 0,
      "33": 0,
      "34": 0,
      "35": 0,
      "36": 0,
      "37": 0,
      "38": 0,
      "39": 0,
      "40": 0,
      "41": 0,
      "42": 0,
      "43": 0,
      "44": 0,
      "45": 0,
      "46": 0,
      "47": 0,
      "48": 0,
      "49": 0,
      "50": 0,
      "51": 0,
      "52": 0,
      "53": 0,
      "54": 0,
      "55": 0,
      "56": 0,
      "57": 0,
      "58": 0,
      "59": 0,
      "60": 0,
      "61": 0,
      "62": 0,
      "63": 0,
      "64": 0,
      "65": 0,
      "66": 0,
      "67": 0,
      "68": 0,
      "69": 0,
      "70": 0,
      "71": 0,
      "72": 0,
      "73": 0,
      "74": 0,
      "75": 0,
      "76": 0,
      "77": 0,
      "78": 0,
      "79": 0,
      "80": 0,
      "81": 0,
      "82": 0,
      "83": 0,
      "84": 0,
      "85": 0,
      "86": 0,
      "87": 0,
      "88": 0,
      "89": 0,
      "90": 0,
      "91": 0,
      "92": 0,
      "93": 0,
      "94": 0,
      "95": 0,
      "96": 0,
      "97": 0,
      "98": 0,
      "99": 0,
      "100": 0,
      "101": 0,
      "102": 0,
      "103": 0,
      "104": 0,
      "105": 0,
      "106": 0,
      "107": 0,
      "108": 0,
      "109": 0,
      "110": 0,
      "111": 0,
      "112": 0
    },
    f: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0
    },
    b: {
      "0": [0, 0],
      "1": [0, 0],
      "2": [0, 0],
      "3": [0, 0],
      "4": [0, 0],
      "5": [0, 0],
      "6": [0, 0],
      "7": [0, 0],
      "8": [0, 0],
      "9": [0, 0],
      "10": [0, 0],
      "11": [0, 0],
      "12": [0, 0],
      "13": [0, 0],
      "14": [0, 0],
      "15": [0, 0, 0, 0, 0, 0, 0, 0, 0],
      "16": [0, 0],
      "17": [0, 0],
      "18": [0, 0],
      "19": [0, 0],
      "20": [0, 0],
      "21": [0, 0],
      "22": [0, 0],
      "23": [0, 0],
      "24": [0, 0]
    },
    _coverageSchema: "1a1c01bbd47fc00a2c39e90264f33305004495a9",
    hash: "4c58a77a9c827c30aee49351594460dafe5c0731"
  };
  var coverage = global[gcv] || (global[gcv] = {});

  if (!coverage[path] || coverage[path].hash !== hash) {
    coverage[path] = coverageData;
  }

  var actualCoverage = coverage[path];
  {
    // @ts-ignore
    cov_1ea36y1nz0 = function () {
      return actualCoverage;
    };
  }
  return actualCoverage;
}

cov_1ea36y1nz0();
const startButton = (cov_1ea36y1nz0().s[0]++, document.getElementById('start-btn'));
const timerDisplayDuration = (cov_1ea36y1nz0().s[1]++, document.getElementById('timer_display_duration'));
const btnSound = (cov_1ea36y1nz0().s[2]++, new Audio('./icons/btnClick.mp3'));
const alarmSound = (cov_1ea36y1nz0().s[3]++, new Audio('./icons/alarm.mp3'));
const SECOND = (cov_1ea36y1nz0().s[4]++, 1000);
let timer;
let timerStatus = (cov_1ea36y1nz0().s[5]++, 'pomo');
let breakCounter = (cov_1ea36y1nz0().s[6]++, 0);
const stopCheck = (cov_1ea36y1nz0().s[7]++, setInterval(stopChecker, 500)); // assign default session lengths to local storage

cov_1ea36y1nz0().s[8]++;

if (localStorage.getItem('pomo-length') === null) {
  cov_1ea36y1nz0().b[0][0]++;
  cov_1ea36y1nz0().s[9]++;
  localStorage.setItem('pomo-length', '25');
  cov_1ea36y1nz0().s[10]++;
  localStorage.setItem('short-break-length', '5');
  cov_1ea36y1nz0().s[11]++;
  localStorage.setItem('long-break-length', '15');
} else {
  cov_1ea36y1nz0().b[0][1]++;
}

let pomoTime = (cov_1ea36y1nz0().s[12]++, localStorage.getItem('pomo-length'));
let breakTime = (cov_1ea36y1nz0().s[13]++, localStorage.getItem('short-break-length'));
let longBreakTime = (cov_1ea36y1nz0().s[14]++, localStorage.getItem('long-break-length'));
cov_1ea36y1nz0().s[15]++;
timerDisplayDuration.innerHTML = `${pomoTime}:00`;

function switchMode() {
  cov_1ea36y1nz0().f[0]++;
  const pomoButton = (cov_1ea36y1nz0().s[16]++, document.getElementById('pomo-btn'));
  const breakButton = (cov_1ea36y1nz0().s[17]++, document.getElementById('break-btn'));
  cov_1ea36y1nz0().s[18]++;

  if ((cov_1ea36y1nz0().b[2][0]++, timerStatus === 'pomo') && (cov_1ea36y1nz0().b[2][1]++, breakCounter >= 3)) {
    cov_1ea36y1nz0().b[1][0]++;
    cov_1ea36y1nz0().s[19]++;
    timerDisplayDuration.innerHTML = `${longBreakTime}:00`;
    cov_1ea36y1nz0().s[20]++;

    if (pomoButton.getAttribute('class') !== 'toggle') {
      cov_1ea36y1nz0().b[3][0]++;
      cov_1ea36y1nz0().s[21]++;
      pomoButton.classList.toggle('toggle');
      cov_1ea36y1nz0().s[22]++;
      breakButton.classList.toggle('toggle');
    } else {
      cov_1ea36y1nz0().b[3][1]++;
    }

    cov_1ea36y1nz0().s[23]++;
    timerStatus = 'break';
    cov_1ea36y1nz0().s[24]++;
    breakCounter = 0;
  } else {
    cov_1ea36y1nz0().b[1][1]++;
    cov_1ea36y1nz0().s[25]++;

    if (timerStatus === 'pomo') {
      cov_1ea36y1nz0().b[4][0]++;
      cov_1ea36y1nz0().s[26]++;
      timerDisplayDuration.innerHTML = `${breakTime}:00`;
      cov_1ea36y1nz0().s[27]++;

      if (pomoButton.getAttribute('class') !== 'toggle') {
        cov_1ea36y1nz0().b[5][0]++;
        cov_1ea36y1nz0().s[28]++;
        pomoButton.classList.toggle('toggle');
        cov_1ea36y1nz0().s[29]++;
        breakButton.classList.toggle('toggle');
      } else {
        cov_1ea36y1nz0().b[5][1]++;
      }

      cov_1ea36y1nz0().s[30]++;
      timerStatus = 'break';
      cov_1ea36y1nz0().s[31]++;
      breakCounter += 1;
    } else {
      cov_1ea36y1nz0().b[4][1]++;
      cov_1ea36y1nz0().s[32]++;
      timerDisplayDuration.innerHTML = `${pomoTime}:00`;
      cov_1ea36y1nz0().s[33]++;

      if (pomoButton.getAttribute('class') === 'toggle') {
        cov_1ea36y1nz0().b[6][0]++;
        cov_1ea36y1nz0().s[34]++;
        pomoButton.classList.toggle('toggle');
        cov_1ea36y1nz0().s[35]++;
        breakButton.classList.toggle('toggle');
      } else {
        cov_1ea36y1nz0().b[6][1]++;
      }

      cov_1ea36y1nz0().s[36]++;
      timerStatus = 'pomo';
    }
  }
}

async function timerFunction() {
  cov_1ea36y1nz0().f[1]++;
  let timerText = (cov_1ea36y1nz0().s[37]++, timerDisplayDuration.innerHTML);
  cov_1ea36y1nz0().s[38]++;

  if (timerText === '0:00') {
    cov_1ea36y1nz0().b[7][0]++;
    cov_1ea36y1nz0().s[39]++;
    switchMode();
    cov_1ea36y1nz0().s[40]++;
    timerText = timerDisplayDuration.innerHTML;
  } else {
    cov_1ea36y1nz0().b[7][1]++;
  }

  cov_1ea36y1nz0().s[41]++;

  if (timerText === '0:01') {
    cov_1ea36y1nz0().b[8][0]++;
    cov_1ea36y1nz0().s[42]++;
    alarmSound.volume = 0.01 * parseInt(localStorage.getItem('volume'), 10); // console.log(alarmSound.volume);

    cov_1ea36y1nz0().s[43]++;
    alarmSound.play();
  } else {
    cov_1ea36y1nz0().b[8][1]++;
  }

  let minutes = (cov_1ea36y1nz0().s[44]++, Number(timerText.substring(0, timerText.length - 3)));
  let seconds = (cov_1ea36y1nz0().s[45]++, Number(timerText.substring(timerText.length - 2)));
  cov_1ea36y1nz0().s[46]++;

  if (!(seconds === 0)) {
    cov_1ea36y1nz0().b[9][0]++;
    cov_1ea36y1nz0().s[47]++;
    seconds -= 1;
  } else {
    cov_1ea36y1nz0().b[9][1]++;
    cov_1ea36y1nz0().s[48]++;
    seconds = 59;
    cov_1ea36y1nz0().s[49]++;
    minutes -= 1;
  }

  cov_1ea36y1nz0().s[50]++;

  if (seconds < 10) {
    cov_1ea36y1nz0().b[10][0]++;
    cov_1ea36y1nz0().s[51]++;
    seconds = `0${String(seconds)}`;
  } else {
    cov_1ea36y1nz0().b[10][1]++;
  }

  cov_1ea36y1nz0().s[52]++;
  timerDisplayDuration.innerHTML = `${minutes}:${seconds}`;
}

async function stopChecker() {
  cov_1ea36y1nz0().f[2]++;
  cov_1ea36y1nz0().s[53]++;

  if (localStorage.getItem('stop') == 'true') {
    cov_1ea36y1nz0().b[11][0]++;
    cov_1ea36y1nz0().s[54]++;
    stop();
    cov_1ea36y1nz0().s[55]++;
    localStorage.setItem('stop', 'false');
  } else {
    cov_1ea36y1nz0().b[11][1]++;
  }
}

async function start() {
  cov_1ea36y1nz0().f[3]++;
  cov_1ea36y1nz0().s[56]++;
  startButton.innerHTML = 'Stop';
  cov_1ea36y1nz0().s[57]++;
  timer = setInterval(timerFunction, SECOND);
}

async function stop() {
  cov_1ea36y1nz0().f[4]++;
  cov_1ea36y1nz0().s[58]++;
  pomoTime = localStorage.getItem('pomo-length');
  cov_1ea36y1nz0().s[59]++;
  breakTime = localStorage.getItem('short-break-length');
  cov_1ea36y1nz0().s[60]++;
  longBreakTime = localStorage.getItem('long-break-length');
  cov_1ea36y1nz0().s[61]++;
  clearInterval(timer);
  cov_1ea36y1nz0().s[62]++;
  timerStatus = 'break';
  cov_1ea36y1nz0().s[63]++;
  setTimeout(switchMode, SECOND / 10);
  cov_1ea36y1nz0().s[64]++;
  breakCounter = 0;
  cov_1ea36y1nz0().s[65]++;
  startButton.innerHTML = 'Start';
}

async function startAndStopButton() {
  cov_1ea36y1nz0().f[5]++;
  cov_1ea36y1nz0().s[66]++;
  btnSound.volume = 0.01 * parseInt(localStorage.getItem('volume'), 10);
  cov_1ea36y1nz0().s[67]++;
  btnSound.play();
  cov_1ea36y1nz0().s[68]++;

  if (startButton.innerHTML === 'Start') {
    cov_1ea36y1nz0().b[12][0]++;
    cov_1ea36y1nz0().s[69]++;
    start();
  } else {
    cov_1ea36y1nz0().b[12][1]++;
    cov_1ea36y1nz0().s[70]++;
    stop();
  }
}

cov_1ea36y1nz0().s[71]++;
startButton.addEventListener('click', startAndStopButton); // keyboard event stuff

cov_1ea36y1nz0().s[72]++;
window.addEventListener('keyup', event => {
  cov_1ea36y1nz0().f[6]++;
  const addDis = (cov_1ea36y1nz0().s[73]++, document.querySelector('task-popup').shadowRoot.getElementById('add-task-popup').style.display);
  const setDis = (cov_1ea36y1nz0().s[74]++, document.querySelector('settings-popup').shadowRoot.getElementById('settings-confirm-popup').style.display);
  const resDis = (cov_1ea36y1nz0().s[75]++, document.querySelector('reset-popup').shadowRoot.getElementById('reset-confirm-popup').style.display);
  const helpDis = (cov_1ea36y1nz0().s[76]++, document.querySelector('help-popup').shadowRoot.getElementById('help-popup').style.display);
  cov_1ea36y1nz0().s[77]++;

  if ((cov_1ea36y1nz0().b[14][0]++, !addDis) || (cov_1ea36y1nz0().b[14][1]++, addDis === 'none')) {
    cov_1ea36y1nz0().b[13][0]++;
    cov_1ea36y1nz0().s[78]++;

    switch (event.code) {
      case 'KeyF':
        cov_1ea36y1nz0().b[15][0]++;
        cov_1ea36y1nz0().s[79]++;
        btnSound.volume = 0.01 * parseInt(localStorage.getItem('volume'), 10);
        cov_1ea36y1nz0().s[80]++;
        btnSound.play();
        cov_1ea36y1nz0().s[81]++;
        document.getElementById('focus-button').click();
        cov_1ea36y1nz0().s[82]++;
        break;

      case 'KeyS':
        cov_1ea36y1nz0().b[15][1]++;
        cov_1ea36y1nz0().s[83]++;
        startButton.click();
        cov_1ea36y1nz0().s[84]++;
        break;

      case 'KeyR':
        cov_1ea36y1nz0().b[15][2]++;
        cov_1ea36y1nz0().s[85]++;
        document.getElementById('reset-button').click();
        cov_1ea36y1nz0().s[86]++;
        break;

      case 'KeyH':
        cov_1ea36y1nz0().b[15][3]++;
        cov_1ea36y1nz0().s[87]++;
        document.getElementById('help-button').click();
        cov_1ea36y1nz0().s[88]++;
        break;

      case 'Semicolon':
        cov_1ea36y1nz0().b[15][4]++;
        cov_1ea36y1nz0().s[89]++;
        document.getElementById('setting-button').click();
        cov_1ea36y1nz0().s[90]++;
        break;

      case 'Escape':
        cov_1ea36y1nz0().b[15][5]++;
        cov_1ea36y1nz0().s[91]++;

        if (setDis === 'block') {
          cov_1ea36y1nz0().b[16][0]++;
          cov_1ea36y1nz0().s[92]++;
          document.querySelector('body > settings-popup').shadowRoot.querySelector('#close-icon').click();
        } else {
          cov_1ea36y1nz0().b[16][1]++;
          cov_1ea36y1nz0().s[93]++;

          if (resDis === 'block') {
            cov_1ea36y1nz0().b[17][0]++;
            cov_1ea36y1nz0().s[94]++;
            document.querySelector('body > reset-popup').shadowRoot.querySelector('#close-icon').click();
          } else {
            cov_1ea36y1nz0().b[17][1]++;
            cov_1ea36y1nz0().s[95]++;

            if (helpDis === 'block') {
              cov_1ea36y1nz0().b[18][0]++;
              cov_1ea36y1nz0().s[96]++;
              document.querySelector('body > help-popup').shadowRoot.querySelector('#close-icon').click();
            } else {
              cov_1ea36y1nz0().b[18][1]++;
            }
          }
        }

        cov_1ea36y1nz0().s[97]++;
        break;

      case 'KeyA':
        cov_1ea36y1nz0().b[15][6]++;
        const state = (cov_1ea36y1nz0().s[98]++, localStorage.getItem('state'));
        cov_1ea36y1nz0().s[99]++;

        if (state === 'default') {
          cov_1ea36y1nz0().b[19][0]++;
          cov_1ea36y1nz0().s[100]++;
          document.getElementById('task-popup-btn').click();
        } else {
          cov_1ea36y1nz0().b[19][1]++;
        }

        cov_1ea36y1nz0().s[101]++;
        break;

      case 'Enter':
        cov_1ea36y1nz0().b[15][7]++;
        cov_1ea36y1nz0().s[102]++;

        if (setDis === 'block') {
          cov_1ea36y1nz0().b[20][0]++;
          cov_1ea36y1nz0().s[103]++;
          document.querySelector('body > settings-popup').shadowRoot.querySelector('#confirm-settings-btn').click();
        } else {
          cov_1ea36y1nz0().b[20][1]++;
          cov_1ea36y1nz0().s[104]++;

          if (resDis === 'block') {
            cov_1ea36y1nz0().b[21][0]++;
            cov_1ea36y1nz0().s[105]++;
            document.querySelector('body > reset-popup').shadowRoot.querySelector('#confirm-reset-btn').click();
          } else {
            cov_1ea36y1nz0().b[21][1]++;
          }
        }

        cov_1ea36y1nz0().s[106]++;
        break;

      default:
        cov_1ea36y1nz0().b[15][8]++;
        cov_1ea36y1nz0().s[107]++;
        break;
    }
  } else {
    cov_1ea36y1nz0().b[13][1]++;
    cov_1ea36y1nz0().s[108]++;

    if (addDis === 'block') {
      cov_1ea36y1nz0().b[22][0]++;
      cov_1ea36y1nz0().s[109]++;

      if (event.code === 'Enter') {
        cov_1ea36y1nz0().b[23][0]++;
        cov_1ea36y1nz0().s[110]++;
        document.querySelector('body > task-popup').shadowRoot.querySelector('#add-task-btn').click();
      } else {
        cov_1ea36y1nz0().b[23][1]++;
        cov_1ea36y1nz0().s[111]++;

        if (event.code === 'Escape') {
          cov_1ea36y1nz0().b[24][0]++;
          cov_1ea36y1nz0().s[112]++;
          document.querySelector('body > task-popup').shadowRoot.querySelector('#close-icon').click();
        } else {
          cov_1ea36y1nz0().b[24][1]++;
        }
      }
    } else {
      cov_1ea36y1nz0().b[22][1]++;
    }
  }
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlRpbWVyLmpzIl0sIm5hbWVzIjpbInN0YXJ0QnV0dG9uIiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInRpbWVyRGlzcGxheUR1cmF0aW9uIiwiYnRuU291bmQiLCJBdWRpbyIsImFsYXJtU291bmQiLCJTRUNPTkQiLCJ0aW1lciIsInRpbWVyU3RhdHVzIiwiYnJlYWtDb3VudGVyIiwic3RvcENoZWNrIiwic2V0SW50ZXJ2YWwiLCJzdG9wQ2hlY2tlciIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJzZXRJdGVtIiwicG9tb1RpbWUiLCJicmVha1RpbWUiLCJsb25nQnJlYWtUaW1lIiwiaW5uZXJIVE1MIiwic3dpdGNoTW9kZSIsInBvbW9CdXR0b24iLCJicmVha0J1dHRvbiIsImdldEF0dHJpYnV0ZSIsImNsYXNzTGlzdCIsInRvZ2dsZSIsInRpbWVyRnVuY3Rpb24iLCJ0aW1lclRleHQiLCJ2b2x1bWUiLCJwYXJzZUludCIsInBsYXkiLCJtaW51dGVzIiwiTnVtYmVyIiwic3Vic3RyaW5nIiwibGVuZ3RoIiwic2Vjb25kcyIsIlN0cmluZyIsInN0b3AiLCJzdGFydCIsImNsZWFySW50ZXJ2YWwiLCJzZXRUaW1lb3V0Iiwic3RhcnRBbmRTdG9wQnV0dG9uIiwiYWRkRXZlbnRMaXN0ZW5lciIsIndpbmRvdyIsImV2ZW50IiwiYWRkRGlzIiwicXVlcnlTZWxlY3RvciIsInNoYWRvd1Jvb3QiLCJzdHlsZSIsImRpc3BsYXkiLCJzZXREaXMiLCJyZXNEaXMiLCJoZWxwRGlzIiwiY29kZSIsImNsaWNrIiwic3RhdGUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWVZOzs7Ozs7Ozs7QUFmWixNQUFNQSxXQUFXLDZCQUFHQyxRQUFRLENBQUNDLGNBQVQsQ0FBd0IsV0FBeEIsQ0FBSCxDQUFqQjtBQUNBLE1BQU1DLG9CQUFvQiw2QkFBR0YsUUFBUSxDQUFDQyxjQUFULENBQXdCLHdCQUF4QixDQUFILENBQTFCO0FBQ0EsTUFBTUUsUUFBUSw2QkFBRyxJQUFJQyxLQUFKLENBQVUsc0JBQVYsQ0FBSCxDQUFkO0FBQ0EsTUFBTUMsVUFBVSw2QkFBRyxJQUFJRCxLQUFKLENBQVUsbUJBQVYsQ0FBSCxDQUFoQjtBQUNBLE1BQU1FLE1BQU0sNkJBQUcsSUFBSCxDQUFaO0FBQ0EsSUFBSUMsS0FBSjtBQUNBLElBQUlDLFdBQVcsNkJBQUcsTUFBSCxDQUFmO0FBQ0EsSUFBSUMsWUFBWSw2QkFBRyxDQUFILENBQWhCO0FBRUEsTUFBTUMsU0FBUyw2QkFBR0MsV0FBVyxDQUFDQyxXQUFELEVBQWMsR0FBZCxDQUFkLENBQWYsQyxDQUVBOzs7O0FBQ0EsSUFBSUMsWUFBWSxDQUFDQyxPQUFiLENBQXFCLGFBQXJCLE1BQXdDLElBQTVDLEVBQWtEO0FBQUE7QUFBQTtBQUM5Q0QsRUFBQUEsWUFBWSxDQUFDRSxPQUFiLENBQXFCLGFBQXJCLEVBQW9DLElBQXBDO0FBRDhDO0FBRTlDRixFQUFBQSxZQUFZLENBQUNFLE9BQWIsQ0FBcUIsb0JBQXJCLEVBQTJDLEdBQTNDO0FBRjhDO0FBRzlDRixFQUFBQSxZQUFZLENBQUNFLE9BQWIsQ0FBcUIsbUJBQXJCLEVBQTBDLElBQTFDO0FBQ0gsQ0FKRDtBQUFBO0FBQUE7O0FBS0EsSUFBSUMsUUFBUSw4QkFBR0gsWUFBWSxDQUFDQyxPQUFiLENBQXFCLGFBQXJCLENBQUgsQ0FBWjtBQUNBLElBQUlHLFNBQVMsOEJBQUdKLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixvQkFBckIsQ0FBSCxDQUFiO0FBQ0EsSUFBSUksYUFBYSw4QkFBR0wsWUFBWSxDQUFDQyxPQUFiLENBQXFCLG1CQUFyQixDQUFILENBQWpCOztBQUVBWixvQkFBb0IsQ0FBQ2lCLFNBQXJCLEdBQWtDLEdBQUVILFFBQVMsS0FBN0M7O0FBRUEsU0FBU0ksVUFBVCxHQUFzQjtBQUFBO0FBQ2xCLFFBQU1DLFVBQVUsOEJBQUdyQixRQUFRLENBQUNDLGNBQVQsQ0FBd0IsVUFBeEIsQ0FBSCxDQUFoQjtBQUNBLFFBQU1xQixXQUFXLDhCQUFHdEIsUUFBUSxDQUFDQyxjQUFULENBQXdCLFdBQXhCLENBQUgsQ0FBakI7QUFGa0I7O0FBSWxCLE1BQUksNkJBQUFPLFdBQVcsS0FBSyxNQUFoQixrQ0FBMEJDLFlBQVksSUFBSSxDQUExQyxDQUFKLEVBQWlEO0FBQUE7QUFBQTtBQUM3Q1AsSUFBQUEsb0JBQW9CLENBQUNpQixTQUFyQixHQUFrQyxHQUFFRCxhQUFjLEtBQWxEO0FBRDZDOztBQUU3QyxRQUFJRyxVQUFVLENBQUNFLFlBQVgsQ0FBd0IsT0FBeEIsTUFBcUMsUUFBekMsRUFBbUQ7QUFBQTtBQUFBO0FBQy9DRixNQUFBQSxVQUFVLENBQUNHLFNBQVgsQ0FBcUJDLE1BQXJCLENBQTRCLFFBQTVCO0FBRCtDO0FBRS9DSCxNQUFBQSxXQUFXLENBQUNFLFNBQVosQ0FBc0JDLE1BQXRCLENBQTZCLFFBQTdCO0FBQ0gsS0FIRDtBQUFBO0FBQUE7O0FBRjZDO0FBTTdDakIsSUFBQUEsV0FBVyxHQUFHLE9BQWQ7QUFONkM7QUFPN0NDLElBQUFBLFlBQVksR0FBRyxDQUFmO0FBQ0gsR0FSRCxNQVFPO0FBQUE7QUFBQTs7QUFBQSxRQUFJRCxXQUFXLEtBQUssTUFBcEIsRUFBNEI7QUFBQTtBQUFBO0FBQy9CTixNQUFBQSxvQkFBb0IsQ0FBQ2lCLFNBQXJCLEdBQWtDLEdBQUVGLFNBQVUsS0FBOUM7QUFEK0I7O0FBRS9CLFVBQUlJLFVBQVUsQ0FBQ0UsWUFBWCxDQUF3QixPQUF4QixNQUFxQyxRQUF6QyxFQUFtRDtBQUFBO0FBQUE7QUFDL0NGLFFBQUFBLFVBQVUsQ0FBQ0csU0FBWCxDQUFxQkMsTUFBckIsQ0FBNEIsUUFBNUI7QUFEK0M7QUFFL0NILFFBQUFBLFdBQVcsQ0FBQ0UsU0FBWixDQUFzQkMsTUFBdEIsQ0FBNkIsUUFBN0I7QUFDSCxPQUhEO0FBQUE7QUFBQTs7QUFGK0I7QUFNL0JqQixNQUFBQSxXQUFXLEdBQUcsT0FBZDtBQU4rQjtBQU8vQkMsTUFBQUEsWUFBWSxJQUFJLENBQWhCO0FBQ0gsS0FSTSxNQVFBO0FBQUE7QUFBQTtBQUNIUCxNQUFBQSxvQkFBb0IsQ0FBQ2lCLFNBQXJCLEdBQWtDLEdBQUVILFFBQVMsS0FBN0M7QUFERzs7QUFFSCxVQUFJSyxVQUFVLENBQUNFLFlBQVgsQ0FBd0IsT0FBeEIsTUFBcUMsUUFBekMsRUFBbUQ7QUFBQTtBQUFBO0FBQy9DRixRQUFBQSxVQUFVLENBQUNHLFNBQVgsQ0FBcUJDLE1BQXJCLENBQTRCLFFBQTVCO0FBRCtDO0FBRS9DSCxRQUFBQSxXQUFXLENBQUNFLFNBQVosQ0FBc0JDLE1BQXRCLENBQTZCLFFBQTdCO0FBQ0gsT0FIRDtBQUFBO0FBQUE7O0FBRkc7QUFNSGpCLE1BQUFBLFdBQVcsR0FBRyxNQUFkO0FBQ0g7QUFBQTtBQUNKOztBQUVELGVBQWVrQixhQUFmLEdBQStCO0FBQUE7QUFDM0IsTUFBSUMsU0FBUyw4QkFBR3pCLG9CQUFvQixDQUFDaUIsU0FBeEIsQ0FBYjtBQUQyQjs7QUFHM0IsTUFBSVEsU0FBUyxLQUFLLE1BQWxCLEVBQTBCO0FBQUE7QUFBQTtBQUN0QlAsSUFBQUEsVUFBVTtBQURZO0FBRXRCTyxJQUFBQSxTQUFTLEdBQUd6QixvQkFBb0IsQ0FBQ2lCLFNBQWpDO0FBQ0gsR0FIRDtBQUFBO0FBQUE7O0FBSDJCOztBQVEzQixNQUFJUSxTQUFTLEtBQUssTUFBbEIsRUFBMEI7QUFBQTtBQUFBO0FBQ3RCdEIsSUFBQUEsVUFBVSxDQUFDdUIsTUFBWCxHQUFvQixPQUFPQyxRQUFRLENBQUNoQixZQUFZLENBQUNDLE9BQWIsQ0FBcUIsUUFBckIsQ0FBRCxFQUFpQyxFQUFqQyxDQUFuQyxDQURzQixDQUV0Qjs7QUFGc0I7QUFHdEJULElBQUFBLFVBQVUsQ0FBQ3lCLElBQVg7QUFDSCxHQUpEO0FBQUE7QUFBQTs7QUFNQSxNQUFJQyxPQUFPLDhCQUFHQyxNQUFNLENBQUNMLFNBQVMsQ0FBQ00sU0FBVixDQUFvQixDQUFwQixFQUF1Qk4sU0FBUyxDQUFDTyxNQUFWLEdBQW1CLENBQTFDLENBQUQsQ0FBVCxDQUFYO0FBQ0EsTUFBSUMsT0FBTyw4QkFBR0gsTUFBTSxDQUFDTCxTQUFTLENBQUNNLFNBQVYsQ0FBb0JOLFNBQVMsQ0FBQ08sTUFBVixHQUFtQixDQUF2QyxDQUFELENBQVQsQ0FBWDtBQWYyQjs7QUFpQjNCLE1BQUksRUFBRUMsT0FBTyxLQUFLLENBQWQsQ0FBSixFQUFzQjtBQUFBO0FBQUE7QUFDbEJBLElBQUFBLE9BQU8sSUFBSSxDQUFYO0FBQ0gsR0FGRCxNQUVPO0FBQUE7QUFBQTtBQUNIQSxJQUFBQSxPQUFPLEdBQUcsRUFBVjtBQURHO0FBRUhKLElBQUFBLE9BQU8sSUFBSSxDQUFYO0FBQ0g7O0FBdEIwQjs7QUF3QjNCLE1BQUlJLE9BQU8sR0FBRyxFQUFkLEVBQWtCO0FBQUE7QUFBQTtBQUNkQSxJQUFBQSxPQUFPLEdBQUksSUFBR0MsTUFBTSxDQUFDRCxPQUFELENBQVUsRUFBOUI7QUFDSCxHQUZEO0FBQUE7QUFBQTs7QUF4QjJCO0FBNEIzQmpDLEVBQUFBLG9CQUFvQixDQUFDaUIsU0FBckIsR0FBa0MsR0FBRVksT0FBUSxJQUFHSSxPQUFRLEVBQXZEO0FBQ0g7O0FBRUQsZUFBZXZCLFdBQWYsR0FBNkI7QUFBQTtBQUFBOztBQUN6QixNQUFJQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsTUFBckIsS0FBZ0MsTUFBcEMsRUFBNEM7QUFBQTtBQUFBO0FBQ3hDdUIsSUFBQUEsSUFBSTtBQURvQztBQUV4Q3hCLElBQUFBLFlBQVksQ0FBQ0UsT0FBYixDQUFxQixNQUFyQixFQUE2QixPQUE3QjtBQUNILEdBSEQ7QUFBQTtBQUFBO0FBSUg7O0FBRUQsZUFBZXVCLEtBQWYsR0FBdUI7QUFBQTtBQUFBO0FBQ25CdkMsRUFBQUEsV0FBVyxDQUFDb0IsU0FBWixHQUF3QixNQUF4QjtBQURtQjtBQUVuQlosRUFBQUEsS0FBSyxHQUFHSSxXQUFXLENBQUNlLGFBQUQsRUFBZ0JwQixNQUFoQixDQUFuQjtBQUNIOztBQUVELGVBQWUrQixJQUFmLEdBQXNCO0FBQUE7QUFBQTtBQUNsQnJCLEVBQUFBLFFBQVEsR0FBR0gsWUFBWSxDQUFDQyxPQUFiLENBQXFCLGFBQXJCLENBQVg7QUFEa0I7QUFFbEJHLEVBQUFBLFNBQVMsR0FBR0osWUFBWSxDQUFDQyxPQUFiLENBQXFCLG9CQUFyQixDQUFaO0FBRmtCO0FBR2xCSSxFQUFBQSxhQUFhLEdBQUdMLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixtQkFBckIsQ0FBaEI7QUFIa0I7QUFJbEJ5QixFQUFBQSxhQUFhLENBQUNoQyxLQUFELENBQWI7QUFKa0I7QUFLbEJDLEVBQUFBLFdBQVcsR0FBRyxPQUFkO0FBTGtCO0FBTWxCZ0MsRUFBQUEsVUFBVSxDQUFDcEIsVUFBRCxFQUFhZCxNQUFNLEdBQUcsRUFBdEIsQ0FBVjtBQU5rQjtBQU9sQkcsRUFBQUEsWUFBWSxHQUFHLENBQWY7QUFQa0I7QUFRbEJWLEVBQUFBLFdBQVcsQ0FBQ29CLFNBQVosR0FBd0IsT0FBeEI7QUFDSDs7QUFFRCxlQUFlc0Isa0JBQWYsR0FBb0M7QUFBQTtBQUFBO0FBQ2hDdEMsRUFBQUEsUUFBUSxDQUFDeUIsTUFBVCxHQUFrQixPQUFPQyxRQUFRLENBQUNoQixZQUFZLENBQUNDLE9BQWIsQ0FBcUIsUUFBckIsQ0FBRCxFQUFpQyxFQUFqQyxDQUFqQztBQURnQztBQUVoQ1gsRUFBQUEsUUFBUSxDQUFDMkIsSUFBVDtBQUZnQzs7QUFHaEMsTUFBSS9CLFdBQVcsQ0FBQ29CLFNBQVosS0FBMEIsT0FBOUIsRUFBdUM7QUFBQTtBQUFBO0FBQ25DbUIsSUFBQUEsS0FBSztBQUNSLEdBRkQsTUFFTztBQUFBO0FBQUE7QUFDSEQsSUFBQUEsSUFBSTtBQUNQO0FBQ0o7OztBQUNEdEMsV0FBVyxDQUFDMkMsZ0JBQVosQ0FBNkIsT0FBN0IsRUFBc0NELGtCQUF0QyxFLENBQ0E7OztBQUNBRSxNQUFNLENBQUNELGdCQUFQLENBQXdCLE9BQXhCLEVBQWtDRSxLQUFELElBQVc7QUFBQTtBQUN4QyxRQUFNQyxNQUFNLDhCQUFHN0MsUUFBUSxDQUFDOEMsYUFBVCxDQUF1QixZQUF2QixFQUFxQ0MsVUFBckMsQ0FBZ0Q5QyxjQUFoRCxDQUErRCxnQkFBL0QsRUFBaUYrQyxLQUFqRixDQUF1RkMsT0FBMUYsQ0FBWjtBQUNBLFFBQU1DLE1BQU0sOEJBQUdsRCxRQUFRLENBQUM4QyxhQUFULENBQXVCLGdCQUF2QixFQUF5Q0MsVUFBekMsQ0FBb0Q5QyxjQUFwRCxDQUFtRSx3QkFBbkUsRUFBNkYrQyxLQUE3RixDQUFtR0MsT0FBdEcsQ0FBWjtBQUNBLFFBQU1FLE1BQU0sOEJBQUduRCxRQUFRLENBQUM4QyxhQUFULENBQXVCLGFBQXZCLEVBQXNDQyxVQUF0QyxDQUFpRDlDLGNBQWpELENBQWdFLHFCQUFoRSxFQUF1RitDLEtBQXZGLENBQTZGQyxPQUFoRyxDQUFaO0FBQ0EsUUFBTUcsT0FBTyw4QkFBR3BELFFBQVEsQ0FBQzhDLGFBQVQsQ0FBdUIsWUFBdkIsRUFBcUNDLFVBQXJDLENBQWdEOUMsY0FBaEQsQ0FBK0QsWUFBL0QsRUFBNkUrQyxLQUE3RSxDQUFtRkMsT0FBdEYsQ0FBYjtBQUp3Qzs7QUFLeEMsTUFBSSwrQkFBQ0osTUFBRCxtQ0FBV0EsTUFBTSxLQUFLLE1BQXRCLENBQUosRUFBa0M7QUFBQTtBQUFBOztBQUM5QixZQUFRRCxLQUFLLENBQUNTLElBQWQ7QUFDQSxXQUFLLE1BQUw7QUFBQTtBQUFBO0FBQ0lsRCxRQUFBQSxRQUFRLENBQUN5QixNQUFULEdBQWtCLE9BQU9DLFFBQVEsQ0FBQ2hCLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixRQUFyQixDQUFELEVBQWlDLEVBQWpDLENBQWpDO0FBREo7QUFFSVgsUUFBQUEsUUFBUSxDQUFDMkIsSUFBVDtBQUZKO0FBR0k5QixRQUFBQSxRQUFRLENBQUNDLGNBQVQsQ0FBd0IsY0FBeEIsRUFBd0NxRCxLQUF4QztBQUhKO0FBSUk7O0FBQ0osV0FBSyxNQUFMO0FBQUE7QUFBQTtBQUNJdkQsUUFBQUEsV0FBVyxDQUFDdUQsS0FBWjtBQURKO0FBRUk7O0FBQ0osV0FBSyxNQUFMO0FBQUE7QUFBQTtBQUNJdEQsUUFBQUEsUUFBUSxDQUFDQyxjQUFULENBQXdCLGNBQXhCLEVBQXdDcUQsS0FBeEM7QUFESjtBQUVJOztBQUNKLFdBQUssTUFBTDtBQUFBO0FBQUE7QUFDSXRELFFBQUFBLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixhQUF4QixFQUF1Q3FELEtBQXZDO0FBREo7QUFFSTs7QUFDSixXQUFLLFdBQUw7QUFBQTtBQUFBO0FBQ0l0RCxRQUFBQSxRQUFRLENBQUNDLGNBQVQsQ0FBd0IsZ0JBQXhCLEVBQTBDcUQsS0FBMUM7QUFESjtBQUVJOztBQUNKLFdBQUssUUFBTDtBQUFBO0FBQUE7O0FBQ0ksWUFBSUosTUFBTSxLQUFLLE9BQWYsRUFBd0I7QUFBQTtBQUFBO0FBQ3BCbEQsVUFBQUEsUUFBUSxDQUFDOEMsYUFBVCxDQUF1Qix1QkFBdkIsRUFBZ0RDLFVBQWhELENBQTJERCxhQUEzRCxDQUF5RSxhQUF6RSxFQUF3RlEsS0FBeEY7QUFDSCxTQUZELE1BRU87QUFBQTtBQUFBOztBQUFBLGNBQUlILE1BQU0sS0FBSyxPQUFmLEVBQXdCO0FBQUE7QUFBQTtBQUMzQm5ELFlBQUFBLFFBQVEsQ0FBQzhDLGFBQVQsQ0FBdUIsb0JBQXZCLEVBQTZDQyxVQUE3QyxDQUF3REQsYUFBeEQsQ0FBc0UsYUFBdEUsRUFBcUZRLEtBQXJGO0FBQ0gsV0FGTSxNQUVBO0FBQUE7QUFBQTs7QUFBQSxnQkFBSUYsT0FBTyxLQUFLLE9BQWhCLEVBQXlCO0FBQUE7QUFBQTtBQUM1QnBELGNBQUFBLFFBQVEsQ0FBQzhDLGFBQVQsQ0FBdUIsbUJBQXZCLEVBQTRDQyxVQUE1QyxDQUF1REQsYUFBdkQsQ0FBcUUsYUFBckUsRUFBb0ZRLEtBQXBGO0FBQ0gsYUFGTTtBQUFBO0FBQUE7QUFFTjtBQUFBOztBQVBMO0FBUUk7O0FBQ0osV0FBSyxNQUFMO0FBQUE7QUFDSSxjQUFNQyxLQUFLLDhCQUFHMUMsWUFBWSxDQUFDQyxPQUFiLENBQXFCLE9BQXJCLENBQUgsQ0FBWDtBQURKOztBQUVJLFlBQUl5QyxLQUFLLEtBQUssU0FBZCxFQUF5QjtBQUFBO0FBQUE7QUFBQXZELFVBQUFBLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixnQkFBeEIsRUFBMENxRCxLQUExQztBQUFrRCxTQUEzRTtBQUFBO0FBQUE7O0FBRko7QUFHSTs7QUFDSixXQUFLLE9BQUw7QUFBQTtBQUFBOztBQUNJLFlBQUlKLE1BQU0sS0FBSyxPQUFmLEVBQXdCO0FBQUE7QUFBQTtBQUNwQmxELFVBQUFBLFFBQVEsQ0FBQzhDLGFBQVQsQ0FBdUIsdUJBQXZCLEVBQWdEQyxVQUFoRCxDQUEyREQsYUFBM0QsQ0FBeUUsdUJBQXpFLEVBQWtHUSxLQUFsRztBQUNILFNBRkQsTUFFTztBQUFBO0FBQUE7O0FBQUEsY0FBSUgsTUFBTSxLQUFLLE9BQWYsRUFBd0I7QUFBQTtBQUFBO0FBQzNCbkQsWUFBQUEsUUFBUSxDQUFDOEMsYUFBVCxDQUF1QixvQkFBdkIsRUFBNkNDLFVBQTdDLENBQXdERCxhQUF4RCxDQUFzRSxvQkFBdEUsRUFBNEZRLEtBQTVGO0FBQ0gsV0FGTTtBQUFBO0FBQUE7QUFFTjs7QUFMTDtBQU1JOztBQUNKO0FBQUE7QUFBQTtBQUNJO0FBdkNKO0FBeUNILEdBMUNELE1BMENPO0FBQUE7QUFBQTs7QUFBQSxRQUFJVCxNQUFNLEtBQUssT0FBZixFQUF3QjtBQUFBO0FBQUE7O0FBQzNCLFVBQUlELEtBQUssQ0FBQ1MsSUFBTixLQUFlLE9BQW5CLEVBQTRCO0FBQUE7QUFBQTtBQUN4QnJELFFBQUFBLFFBQVEsQ0FBQzhDLGFBQVQsQ0FBdUIsbUJBQXZCLEVBQTRDQyxVQUE1QyxDQUF1REQsYUFBdkQsQ0FBcUUsZUFBckUsRUFBc0ZRLEtBQXRGO0FBQ0gsT0FGRCxNQUVPO0FBQUE7QUFBQTs7QUFBQSxZQUFJVixLQUFLLENBQUNTLElBQU4sS0FBZSxRQUFuQixFQUE2QjtBQUFBO0FBQUE7QUFDaENyRCxVQUFBQSxRQUFRLENBQUM4QyxhQUFULENBQXVCLG1CQUF2QixFQUE0Q0MsVUFBNUMsQ0FBdURELGFBQXZELENBQXFFLGFBQXJFLEVBQW9GUSxLQUFwRjtBQUNILFNBRk0sTUFFQTtBQUFBO0FBQ047QUFBQTtBQUNKLEtBUE0sTUFPQTtBQUFBO0FBQ047QUFBQTtBQUNKLENBeEREIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qgc3RhcnRCdXR0b24gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc3RhcnQtYnRuJyk7XHJcbmNvbnN0IHRpbWVyRGlzcGxheUR1cmF0aW9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3RpbWVyX2Rpc3BsYXlfZHVyYXRpb24nKTtcclxuY29uc3QgYnRuU291bmQgPSBuZXcgQXVkaW8oJy4vaWNvbnMvYnRuQ2xpY2subXAzJyk7XHJcbmNvbnN0IGFsYXJtU291bmQgPSBuZXcgQXVkaW8oJy4vaWNvbnMvYWxhcm0ubXAzJyk7XHJcbmNvbnN0IFNFQ09ORCA9IDEwMDA7XHJcbmxldCB0aW1lcjtcclxubGV0IHRpbWVyU3RhdHVzID0gJ3BvbW8nO1xyXG5sZXQgYnJlYWtDb3VudGVyID0gMDtcclxuXHJcbmNvbnN0IHN0b3BDaGVjayA9IHNldEludGVydmFsKHN0b3BDaGVja2VyLCA1MDApO1xyXG5cclxuLy8gYXNzaWduIGRlZmF1bHQgc2Vzc2lvbiBsZW5ndGhzIHRvIGxvY2FsIHN0b3JhZ2VcclxuaWYgKGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdwb21vLWxlbmd0aCcpID09PSBudWxsKSB7XHJcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgncG9tby1sZW5ndGgnLCAnMjUnKTtcclxuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdzaG9ydC1icmVhay1sZW5ndGgnLCAnNScpO1xyXG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2xvbmctYnJlYWstbGVuZ3RoJywgJzE1Jyk7XHJcbn1cclxubGV0IHBvbW9UaW1lID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3BvbW8tbGVuZ3RoJyk7XHJcbmxldCBicmVha1RpbWUgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnc2hvcnQtYnJlYWstbGVuZ3RoJyk7XHJcbmxldCBsb25nQnJlYWtUaW1lID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2xvbmctYnJlYWstbGVuZ3RoJyk7XHJcblxyXG50aW1lckRpc3BsYXlEdXJhdGlvbi5pbm5lckhUTUwgPSBgJHtwb21vVGltZX06MDBgO1xyXG5cclxuZnVuY3Rpb24gc3dpdGNoTW9kZSgpIHtcclxuICAgIGNvbnN0IHBvbW9CdXR0b24gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncG9tby1idG4nKTtcclxuICAgIGNvbnN0IGJyZWFrQnV0dG9uID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2JyZWFrLWJ0bicpO1xyXG5cclxuICAgIGlmICh0aW1lclN0YXR1cyA9PT0gJ3BvbW8nICYmIGJyZWFrQ291bnRlciA+PSAzKSB7XHJcbiAgICAgICAgdGltZXJEaXNwbGF5RHVyYXRpb24uaW5uZXJIVE1MID0gYCR7bG9uZ0JyZWFrVGltZX06MDBgO1xyXG4gICAgICAgIGlmIChwb21vQnV0dG9uLmdldEF0dHJpYnV0ZSgnY2xhc3MnKSAhPT0gJ3RvZ2dsZScpIHtcclxuICAgICAgICAgICAgcG9tb0J1dHRvbi5jbGFzc0xpc3QudG9nZ2xlKCd0b2dnbGUnKTtcclxuICAgICAgICAgICAgYnJlYWtCdXR0b24uY2xhc3NMaXN0LnRvZ2dsZSgndG9nZ2xlJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRpbWVyU3RhdHVzID0gJ2JyZWFrJztcclxuICAgICAgICBicmVha0NvdW50ZXIgPSAwO1xyXG4gICAgfSBlbHNlIGlmICh0aW1lclN0YXR1cyA9PT0gJ3BvbW8nKSB7XHJcbiAgICAgICAgdGltZXJEaXNwbGF5RHVyYXRpb24uaW5uZXJIVE1MID0gYCR7YnJlYWtUaW1lfTowMGA7XHJcbiAgICAgICAgaWYgKHBvbW9CdXR0b24uZ2V0QXR0cmlidXRlKCdjbGFzcycpICE9PSAndG9nZ2xlJykge1xyXG4gICAgICAgICAgICBwb21vQnV0dG9uLmNsYXNzTGlzdC50b2dnbGUoJ3RvZ2dsZScpO1xyXG4gICAgICAgICAgICBicmVha0J1dHRvbi5jbGFzc0xpc3QudG9nZ2xlKCd0b2dnbGUnKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGltZXJTdGF0dXMgPSAnYnJlYWsnO1xyXG4gICAgICAgIGJyZWFrQ291bnRlciArPSAxO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgICB0aW1lckRpc3BsYXlEdXJhdGlvbi5pbm5lckhUTUwgPSBgJHtwb21vVGltZX06MDBgO1xyXG4gICAgICAgIGlmIChwb21vQnV0dG9uLmdldEF0dHJpYnV0ZSgnY2xhc3MnKSA9PT0gJ3RvZ2dsZScpIHtcclxuICAgICAgICAgICAgcG9tb0J1dHRvbi5jbGFzc0xpc3QudG9nZ2xlKCd0b2dnbGUnKTtcclxuICAgICAgICAgICAgYnJlYWtCdXR0b24uY2xhc3NMaXN0LnRvZ2dsZSgndG9nZ2xlJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRpbWVyU3RhdHVzID0gJ3BvbW8nO1xyXG4gICAgfVxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiB0aW1lckZ1bmN0aW9uKCkge1xyXG4gICAgbGV0IHRpbWVyVGV4dCA9IHRpbWVyRGlzcGxheUR1cmF0aW9uLmlubmVySFRNTDtcclxuXHJcbiAgICBpZiAodGltZXJUZXh0ID09PSAnMDowMCcpIHtcclxuICAgICAgICBzd2l0Y2hNb2RlKCk7XHJcbiAgICAgICAgdGltZXJUZXh0ID0gdGltZXJEaXNwbGF5RHVyYXRpb24uaW5uZXJIVE1MO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICh0aW1lclRleHQgPT09ICcwOjAxJykge1xyXG4gICAgICAgIGFsYXJtU291bmQudm9sdW1lID0gMC4wMSAqIHBhcnNlSW50KGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd2b2x1bWUnKSwgMTApO1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKGFsYXJtU291bmQudm9sdW1lKTtcclxuICAgICAgICBhbGFybVNvdW5kLnBsYXkoKTtcclxuICAgIH1cclxuXHJcbiAgICBsZXQgbWludXRlcyA9IE51bWJlcih0aW1lclRleHQuc3Vic3RyaW5nKDAsIHRpbWVyVGV4dC5sZW5ndGggLSAzKSk7XHJcbiAgICBsZXQgc2Vjb25kcyA9IE51bWJlcih0aW1lclRleHQuc3Vic3RyaW5nKHRpbWVyVGV4dC5sZW5ndGggLSAyKSk7XHJcblxyXG4gICAgaWYgKCEoc2Vjb25kcyA9PT0gMCkpIHtcclxuICAgICAgICBzZWNvbmRzIC09IDE7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNlY29uZHMgPSA1OTtcclxuICAgICAgICBtaW51dGVzIC09IDE7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHNlY29uZHMgPCAxMCkge1xyXG4gICAgICAgIHNlY29uZHMgPSBgMCR7U3RyaW5nKHNlY29uZHMpfWA7XHJcbiAgICB9XHJcblxyXG4gICAgdGltZXJEaXNwbGF5RHVyYXRpb24uaW5uZXJIVE1MID0gYCR7bWludXRlc306JHtzZWNvbmRzfWA7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHN0b3BDaGVja2VyKCkge1xyXG4gICAgaWYgKGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdzdG9wJykgPT0gJ3RydWUnKSB7XHJcbiAgICAgICAgc3RvcCgpO1xyXG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdzdG9wJywgJ2ZhbHNlJyk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHN0YXJ0KCkge1xyXG4gICAgc3RhcnRCdXR0b24uaW5uZXJIVE1MID0gJ1N0b3AnO1xyXG4gICAgdGltZXIgPSBzZXRJbnRlcnZhbCh0aW1lckZ1bmN0aW9uLCBTRUNPTkQpO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBzdG9wKCkge1xyXG4gICAgcG9tb1RpbWUgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgncG9tby1sZW5ndGgnKTtcclxuICAgIGJyZWFrVGltZSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdzaG9ydC1icmVhay1sZW5ndGgnKTtcclxuICAgIGxvbmdCcmVha1RpbWUgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbG9uZy1icmVhay1sZW5ndGgnKTtcclxuICAgIGNsZWFySW50ZXJ2YWwodGltZXIpO1xyXG4gICAgdGltZXJTdGF0dXMgPSAnYnJlYWsnO1xyXG4gICAgc2V0VGltZW91dChzd2l0Y2hNb2RlLCBTRUNPTkQgLyAxMCk7XHJcbiAgICBicmVha0NvdW50ZXIgPSAwO1xyXG4gICAgc3RhcnRCdXR0b24uaW5uZXJIVE1MID0gJ1N0YXJ0JztcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc3RhcnRBbmRTdG9wQnV0dG9uKCkge1xyXG4gICAgYnRuU291bmQudm9sdW1lID0gMC4wMSAqIHBhcnNlSW50KGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd2b2x1bWUnKSwgMTApO1xyXG4gICAgYnRuU291bmQucGxheSgpO1xyXG4gICAgaWYgKHN0YXJ0QnV0dG9uLmlubmVySFRNTCA9PT0gJ1N0YXJ0Jykge1xyXG4gICAgICAgIHN0YXJ0KCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAgIHN0b3AoKTtcclxuICAgIH1cclxufVxyXG5zdGFydEJ1dHRvbi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIHN0YXJ0QW5kU3RvcEJ1dHRvbik7XHJcbi8vIGtleWJvYXJkIGV2ZW50IHN0dWZmXHJcbndpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXl1cCcsIChldmVudCkgPT4ge1xyXG4gICAgY29uc3QgYWRkRGlzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcigndGFzay1wb3B1cCcpLnNoYWRvd1Jvb3QuZ2V0RWxlbWVudEJ5SWQoJ2FkZC10YXNrLXBvcHVwJykuc3R5bGUuZGlzcGxheTtcclxuICAgIGNvbnN0IHNldERpcyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ3NldHRpbmdzLXBvcHVwJykuc2hhZG93Um9vdC5nZXRFbGVtZW50QnlJZCgnc2V0dGluZ3MtY29uZmlybS1wb3B1cCcpLnN0eWxlLmRpc3BsYXk7XHJcbiAgICBjb25zdCByZXNEaXMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdyZXNldC1wb3B1cCcpLnNoYWRvd1Jvb3QuZ2V0RWxlbWVudEJ5SWQoJ3Jlc2V0LWNvbmZpcm0tcG9wdXAnKS5zdHlsZS5kaXNwbGF5O1xyXG4gICAgY29uc3QgaGVscERpcyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2hlbHAtcG9wdXAnKS5zaGFkb3dSb290LmdldEVsZW1lbnRCeUlkKCdoZWxwLXBvcHVwJykuc3R5bGUuZGlzcGxheTtcclxuICAgIGlmICghYWRkRGlzIHx8IGFkZERpcyA9PT0gJ25vbmUnKSB7XHJcbiAgICAgICAgc3dpdGNoIChldmVudC5jb2RlKSB7XHJcbiAgICAgICAgY2FzZSAnS2V5Ric6XHJcbiAgICAgICAgICAgIGJ0blNvdW5kLnZvbHVtZSA9IDAuMDEgKiBwYXJzZUludChsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndm9sdW1lJyksIDEwKTtcclxuICAgICAgICAgICAgYnRuU291bmQucGxheSgpO1xyXG4gICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZm9jdXMtYnV0dG9uJykuY2xpY2soKTtcclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgY2FzZSAnS2V5Uyc6XHJcbiAgICAgICAgICAgIHN0YXJ0QnV0dG9uLmNsaWNrKCk7XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgJ0tleVInOlxyXG4gICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncmVzZXQtYnV0dG9uJykuY2xpY2soKTtcclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgY2FzZSAnS2V5SCc6XHJcbiAgICAgICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdoZWxwLWJ1dHRvbicpLmNsaWNrKCk7XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgJ1NlbWljb2xvbic6XHJcbiAgICAgICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzZXR0aW5nLWJ1dHRvbicpLmNsaWNrKCk7XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgJ0VzY2FwZSc6XHJcbiAgICAgICAgICAgIGlmIChzZXREaXMgPT09ICdibG9jaycpIHtcclxuICAgICAgICAgICAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2JvZHkgPiBzZXR0aW5ncy1wb3B1cCcpLnNoYWRvd1Jvb3QucXVlcnlTZWxlY3RvcignI2Nsb3NlLWljb24nKS5jbGljaygpO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKHJlc0RpcyA9PT0gJ2Jsb2NrJykge1xyXG4gICAgICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignYm9keSA+IHJlc2V0LXBvcHVwJykuc2hhZG93Um9vdC5xdWVyeVNlbGVjdG9yKCcjY2xvc2UtaWNvbicpLmNsaWNrKCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoaGVscERpcyA9PT0gJ2Jsb2NrJykge1xyXG4gICAgICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignYm9keSA+IGhlbHAtcG9wdXAnKS5zaGFkb3dSb290LnF1ZXJ5U2VsZWN0b3IoJyNjbG9zZS1pY29uJykuY2xpY2soKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlICdLZXlBJzpcclxuICAgICAgICAgICAgY29uc3Qgc3RhdGUgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnc3RhdGUnKTtcclxuICAgICAgICAgICAgaWYgKHN0YXRlID09PSAnZGVmYXVsdCcpIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0YXNrLXBvcHVwLWJ0bicpLmNsaWNrKCk7XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgJ0VudGVyJzpcclxuICAgICAgICAgICAgaWYgKHNldERpcyA9PT0gJ2Jsb2NrJykge1xyXG4gICAgICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignYm9keSA+IHNldHRpbmdzLXBvcHVwJykuc2hhZG93Um9vdC5xdWVyeVNlbGVjdG9yKCcjY29uZmlybS1zZXR0aW5ncy1idG4nKS5jbGljaygpO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKHJlc0RpcyA9PT0gJ2Jsb2NrJykge1xyXG4gICAgICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignYm9keSA+IHJlc2V0LXBvcHVwJykuc2hhZG93Um9vdC5xdWVyeVNlbGVjdG9yKCcjY29uZmlybS1yZXNldC1idG4nKS5jbGljaygpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgIH0gZWxzZSBpZiAoYWRkRGlzID09PSAnYmxvY2snKSB7XHJcbiAgICAgICAgaWYgKGV2ZW50LmNvZGUgPT09ICdFbnRlcicpIHtcclxuICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignYm9keSA+IHRhc2stcG9wdXAnKS5zaGFkb3dSb290LnF1ZXJ5U2VsZWN0b3IoJyNhZGQtdGFzay1idG4nKS5jbGljaygpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoZXZlbnQuY29kZSA9PT0gJ0VzY2FwZScpIHtcclxuICAgICAgICAgICAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignYm9keSA+IHRhc2stcG9wdXAnKS5zaGFkb3dSb290LnF1ZXJ5U2VsZWN0b3IoJyNjbG9zZS1pY29uJykuY2xpY2soKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICB9XHJcbn0pO1xyXG4iXX0=
function cov_1l4fuz3y2b() {
  var path = "D:\\\u5B66\u4E60\\21WI\\CSE110\\cse110-w21-group13\\source\\src\\components\\SettingsPopUp.js";
  var hash = "1a7faee7758173ae443383bd17a48c4e74b79296";
  var global = new Function("return this")();
  var gcv = "__coverage__";
  var coverageData = {
    path: "D:\\\u5B66\u4E60\\21WI\\CSE110\\cse110-w21-group13\\source\\src\\components\\SettingsPopUp.js",
    statementMap: {
      "0": {
        start: {
          line: 3,
          column: 24
        },
        end: {
          line: 3,
          column: 80
        }
      },
      "1": {
        start: {
          line: 4,
          column: 8
        },
        end: {
          line: 4,
          column: 39
        }
      },
      "2": {
        start: {
          line: 8,
          column: 27
        },
        end: {
          line: 8,
          column: 98
        }
      },
      "3": {
        start: {
          line: 9,
          column: 27
        },
        end: {
          line: 9,
          column: 98
        }
      },
      "4": {
        start: {
          line: 10,
          column: 26
        },
        end: {
          line: 10,
          column: 96
        }
      },
      "5": {
        start: {
          line: 11,
          column: 8
        },
        end: {
          line: 11,
          column: 64
        }
      },
      "6": {
        start: {
          line: 12,
          column: 8
        },
        end: {
          line: 12,
          column: 71
        }
      },
      "7": {
        start: {
          line: 13,
          column: 8
        },
        end: {
          line: 13,
          column: 69
        }
      },
      "8": {
        start: {
          line: 14,
          column: 25
        },
        end: {
          line: 14,
          column: 58
        }
      },
      "9": {
        start: {
          line: 15,
          column: 8
        },
        end: {
          line: 15,
          column: 78
        }
      },
      "10": {
        start: {
          line: 16,
          column: 8
        },
        end: {
          line: 16,
          column: 24
        }
      },
      "11": {
        start: {
          line: 17,
          column: 8
        },
        end: {
          line: 17,
          column: 45
        }
      },
      "12": {
        start: {
          line: 18,
          column: 8
        },
        end: {
          line: 18,
          column: 26
        }
      },
      "13": {
        start: {
          line: 23,
          column: 8
        },
        end: {
          line: 27,
          column: 9
        }
      },
      "14": {
        start: {
          line: 24,
          column: 12
        },
        end: {
          line: 24,
          column: 50
        }
      },
      "15": {
        start: {
          line: 26,
          column: 12
        },
        end: {
          line: 26,
          column: 51
        }
      },
      "16": {
        start: {
          line: 28,
          column: 8
        },
        end: {
          line: 28,
          column: 53
        }
      },
      "17": {
        start: {
          line: 32,
          column: 23
        },
        end: {
          line: 32,
          column: 68
        }
      },
      "18": {
        start: {
          line: 33,
          column: 8
        },
        end: {
          line: 33,
          column: 52
        }
      },
      "19": {
        start: {
          line: 37,
          column: 8
        },
        end: {
          line: 37,
          column: 16
        }
      },
      "20": {
        start: {
          line: 38,
          column: 23
        },
        end: {
          line: 38,
          column: 58
        }
      },
      "21": {
        start: {
          line: 40,
          column: 24
        },
        end: {
          line: 40,
          column: 53
        }
      },
      "22": {
        start: {
          line: 41,
          column: 8
        },
        end: {
          line: 41,
          column: 61
        }
      },
      "23": {
        start: {
          line: 43,
          column: 22
        },
        end: {
          line: 43,
          column: 72
        }
      },
      "24": {
        start: {
          line: 44,
          column: 8
        },
        end: {
          line: 44,
          column: 53
        }
      },
      "25": {
        start: {
          line: 45,
          column: 8
        },
        end: {
          line: 45,
          column: 47
        }
      },
      "26": {
        start: {
          line: 47,
          column: 22
        },
        end: {
          line: 47,
          column: 71
        }
      },
      "27": {
        start: {
          line: 48,
          column: 8
        },
        end: {
          line: 48,
          column: 37
        }
      },
      "28": {
        start: {
          line: 50,
          column: 29
        },
        end: {
          line: 50,
          column: 78
        }
      },
      "29": {
        start: {
          line: 51,
          column: 8
        },
        end: {
          line: 51,
          column: 58
        }
      },
      "30": {
        start: {
          line: 52,
          column: 8
        },
        end: {
          line: 52,
          column: 60
        }
      },
      "31": {
        start: {
          line: 54,
          column: 24
        },
        end: {
          line: 54,
          column: 74
        }
      },
      "32": {
        start: {
          line: 55,
          column: 8
        },
        end: {
          line: 55,
          column: 46
        }
      },
      "33": {
        start: {
          line: 57,
          column: 28
        },
        end: {
          line: 57,
          column: 78
        }
      },
      "34": {
        start: {
          line: 58,
          column: 8
        },
        end: {
          line: 58,
          column: 60
        }
      },
      "35": {
        start: {
          line: 59,
          column: 26
        },
        end: {
          line: 59,
          column: 82
        }
      },
      "36": {
        start: {
          line: 60,
          column: 8
        },
        end: {
          line: 60,
          column: 46
        }
      },
      "37": {
        start: {
          line: 61,
          column: 8
        },
        end: {
          line: 61,
          column: 41
        }
      },
      "38": {
        start: {
          line: 62,
          column: 26
        },
        end: {
          line: 62,
          column: 82
        }
      },
      "39": {
        start: {
          line: 63,
          column: 8
        },
        end: {
          line: 63,
          column: 49
        }
      },
      "40": {
        start: {
          line: 64,
          column: 8
        },
        end: {
          line: 64,
          column: 58
        }
      },
      "41": {
        start: {
          line: 65,
          column: 8
        },
        end: {
          line: 65,
          column: 91
        }
      },
      "42": {
        start: {
          line: 66,
          column: 8
        },
        end: {
          line: 66,
          column: 41
        }
      },
      "43": {
        start: {
          line: 67,
          column: 8
        },
        end: {
          line: 67,
          column: 42
        }
      },
      "44": {
        start: {
          line: 68,
          column: 8
        },
        end: {
          line: 68,
          column: 73
        }
      },
      "45": {
        start: {
          line: 69,
          column: 34
        },
        end: {
          line: 69,
          column: 84
        }
      },
      "46": {
        start: {
          line: 70,
          column: 8
        },
        end: {
          line: 70,
          column: 66
        }
      },
      "47": {
        start: {
          line: 71,
          column: 32
        },
        end: {
          line: 71,
          column: 94
        }
      },
      "48": {
        start: {
          line: 72,
          column: 8
        },
        end: {
          line: 72,
          column: 59
        }
      },
      "49": {
        start: {
          line: 73,
          column: 8
        },
        end: {
          line: 73,
          column: 50
        }
      },
      "50": {
        start: {
          line: 74,
          column: 32
        },
        end: {
          line: 74,
          column: 94
        }
      },
      "51": {
        start: {
          line: 75,
          column: 8
        },
        end: {
          line: 75,
          column: 55
        }
      },
      "52": {
        start: {
          line: 76,
          column: 8
        },
        end: {
          line: 76,
          column: 64
        }
      },
      "53": {
        start: {
          line: 77,
          column: 8
        },
        end: {
          line: 77,
          column: 104
        }
      },
      "54": {
        start: {
          line: 78,
          column: 8
        },
        end: {
          line: 78,
          column: 47
        }
      },
      "55": {
        start: {
          line: 79,
          column: 8
        },
        end: {
          line: 79,
          column: 48
        }
      },
      "56": {
        start: {
          line: 80,
          column: 8
        },
        end: {
          line: 80,
          column: 79
        }
      },
      "57": {
        start: {
          line: 81,
          column: 33
        },
        end: {
          line: 81,
          column: 83
        }
      },
      "58": {
        start: {
          line: 82,
          column: 8
        },
        end: {
          line: 82,
          column: 65
        }
      },
      "59": {
        start: {
          line: 83,
          column: 31
        },
        end: {
          line: 83,
          column: 92
        }
      },
      "60": {
        start: {
          line: 84,
          column: 8
        },
        end: {
          line: 84,
          column: 57
        }
      },
      "61": {
        start: {
          line: 85,
          column: 8
        },
        end: {
          line: 85,
          column: 48
        }
      },
      "62": {
        start: {
          line: 86,
          column: 31
        },
        end: {
          line: 86,
          column: 92
        }
      },
      "63": {
        start: {
          line: 87,
          column: 8
        },
        end: {
          line: 87,
          column: 54
        }
      },
      "64": {
        start: {
          line: 88,
          column: 8
        },
        end: {
          line: 88,
          column: 62
        }
      },
      "65": {
        start: {
          line: 89,
          column: 8
        },
        end: {
          line: 89,
          column: 102
        }
      },
      "66": {
        start: {
          line: 90,
          column: 8
        },
        end: {
          line: 90,
          column: 46
        }
      },
      "67": {
        start: {
          line: 91,
          column: 8
        },
        end: {
          line: 91,
          column: 47
        }
      },
      "68": {
        start: {
          line: 92,
          column: 8
        },
        end: {
          line: 92,
          column: 78
        }
      },
      "69": {
        start: {
          line: 94,
          column: 28
        },
        end: {
          line: 94,
          column: 78
        }
      },
      "70": {
        start: {
          line: 95,
          column: 8
        },
        end: {
          line: 95,
          column: 52
        }
      },
      "71": {
        start: {
          line: 96,
          column: 30
        },
        end: {
          line: 96,
          column: 83
        }
      },
      "72": {
        start: {
          line: 97,
          column: 8
        },
        end: {
          line: 97,
          column: 61
        }
      },
      "73": {
        start: {
          line: 98,
          column: 8
        },
        end: {
          line: 98,
          column: 54
        }
      },
      "74": {
        start: {
          line: 99,
          column: 27
        },
        end: {
          line: 99,
          column: 83
        }
      },
      "75": {
        start: {
          line: 100,
          column: 8
        },
        end: {
          line: 100,
          column: 51
        }
      },
      "76": {
        start: {
          line: 101,
          column: 30
        },
        end: {
          line: 101,
          column: 85
        }
      },
      "77": {
        start: {
          line: 102,
          column: 8
        },
        end: {
          line: 102,
          column: 55
        }
      },
      "78": {
        start: {
          line: 103,
          column: 8
        },
        end: {
          line: 105,
          column: 9
        }
      },
      "79": {
        start: {
          line: 104,
          column: 12
        },
        end: {
          line: 104,
          column: 46
        }
      },
      "80": {
        start: {
          line: 106,
          column: 23
        },
        end: {
          line: 106,
          column: 77
        }
      },
      "81": {
        start: {
          line: 107,
          column: 8
        },
        end: {
          line: 107,
          column: 47
        }
      },
      "82": {
        start: {
          line: 109,
          column: 8
        },
        end: {
          line: 109,
          column: 69
        }
      },
      "83": {
        start: {
          line: 111,
          column: 26
        },
        end: {
          line: 111,
          column: 76
        }
      },
      "84": {
        start: {
          line: 112,
          column: 8
        },
        end: {
          line: 112,
          column: 51
        }
      },
      "85": {
        start: {
          line: 113,
          column: 28
        },
        end: {
          line: 113,
          column: 79
        }
      },
      "86": {
        start: {
          line: 114,
          column: 8
        },
        end: {
          line: 114,
          column: 55
        }
      },
      "87": {
        start: {
          line: 115,
          column: 8
        },
        end: {
          line: 115,
          column: 47
        }
      },
      "88": {
        start: {
          line: 116,
          column: 21
        },
        end: {
          line: 116,
          column: 71
        }
      },
      "89": {
        start: {
          line: 117,
          column: 24
        },
        end: {
          line: 117,
          column: 72
        }
      },
      "90": {
        start: {
          line: 118,
          column: 8
        },
        end: {
          line: 118,
          column: 52
        }
      },
      "91": {
        start: {
          line: 119,
          column: 26
        },
        end: {
          line: 119,
          column: 78
        }
      },
      "92": {
        start: {
          line: 120,
          column: 8
        },
        end: {
          line: 120,
          column: 54
        }
      },
      "93": {
        start: {
          line: 121,
          column: 27
        },
        end: {
          line: 121,
          column: 81
        }
      },
      "94": {
        start: {
          line: 122,
          column: 8
        },
        end: {
          line: 122,
          column: 49
        }
      },
      "95": {
        start: {
          line: 123,
          column: 8
        },
        end: {
          line: 123,
          column: 42
        }
      },
      "96": {
        start: {
          line: 124,
          column: 8
        },
        end: {
          line: 124,
          column: 44
        }
      },
      "97": {
        start: {
          line: 125,
          column: 8
        },
        end: {
          line: 125,
          column: 87
        }
      },
      "98": {
        start: {
          line: 126,
          column: 8
        },
        end: {
          line: 126,
          column: 55
        }
      },
      "99": {
        start: {
          line: 127,
          column: 8
        },
        end: {
          line: 127,
          column: 47
        }
      },
      "100": {
        start: {
          line: 129,
          column: 23
        },
        end: {
          line: 129,
          column: 73
        }
      },
      "101": {
        start: {
          line: 130,
          column: 8
        },
        end: {
          line: 130,
          column: 54
        }
      },
      "102": {
        start: {
          line: 131,
          column: 27
        },
        end: {
          line: 131,
          column: 79
        }
      },
      "103": {
        start: {
          line: 132,
          column: 8
        },
        end: {
          line: 132,
          column: 64
        }
      },
      "104": {
        start: {
          line: 133,
          column: 8
        },
        end: {
          line: 133,
          column: 62
        }
      },
      "105": {
        start: {
          line: 134,
          column: 8
        },
        end: {
          line: 134,
          column: 41
        }
      },
      "106": {
        start: {
          line: 136,
          column: 8
        },
        end: {
          line: 136,
          column: 78
        }
      },
      "107": {
        start: {
          line: 137,
          column: 8
        },
        end: {
          line: 137,
          column: 68
        }
      },
      "108": {
        start: {
          line: 139,
          column: 8
        },
        end: {
          line: 139,
          column: 73
        }
      },
      "109": {
        start: {
          line: 140,
          column: 8
        },
        end: {
          line: 140,
          column: 45
        }
      },
      "110": {
        start: {
          line: 142,
          column: 8
        },
        end: {
          line: 144,
          column: 11
        }
      },
      "111": {
        start: {
          line: 143,
          column: 12
        },
        end: {
          line: 143,
          column: 43
        }
      },
      "112": {
        start: {
          line: 146,
          column: 8
        },
        end: {
          line: 146,
          column: 63
        }
      },
      "113": {
        start: {
          line: 147,
          column: 8
        },
        end: {
          line: 147,
          column: 49
        }
      },
      "114": {
        start: {
          line: 148,
          column: 8
        },
        end: {
          line: 148,
          column: 50
        }
      },
      "115": {
        start: {
          line: 149,
          column: 8
        },
        end: {
          line: 149,
          column: 60
        }
      },
      "116": {
        start: {
          line: 150,
          column: 8
        },
        end: {
          line: 150,
          column: 57
        }
      },
      "117": {
        start: {
          line: 151,
          column: 8
        },
        end: {
          line: 151,
          column: 56
        }
      },
      "118": {
        start: {
          line: 152,
          column: 8
        },
        end: {
          line: 152,
          column: 63
        }
      },
      "119": {
        start: {
          line: 153,
          column: 8
        },
        end: {
          line: 153,
          column: 62
        }
      },
      "120": {
        start: {
          line: 154,
          column: 8
        },
        end: {
          line: 154,
          column: 62
        }
      },
      "121": {
        start: {
          line: 155,
          column: 8
        },
        end: {
          line: 155,
          column: 61
        }
      },
      "122": {
        start: {
          line: 156,
          column: 8
        },
        end: {
          line: 156,
          column: 63
        }
      },
      "123": {
        start: {
          line: 157,
          column: 8
        },
        end: {
          line: 157,
          column: 57
        }
      },
      "124": {
        start: {
          line: 158,
          column: 8
        },
        end: {
          line: 158,
          column: 54
        }
      },
      "125": {
        start: {
          line: 159,
          column: 8
        },
        end: {
          line: 159,
          column: 56
        }
      },
      "126": {
        start: {
          line: 160,
          column: 8
        },
        end: {
          line: 160,
          column: 50
        }
      },
      "127": {
        start: {
          line: 161,
          column: 8
        },
        end: {
          line: 161,
          column: 55
        }
      },
      "128": {
        start: {
          line: 162,
          column: 22
        },
        end: {
          line: 162,
          column: 53
        }
      },
      "129": {
        start: {
          line: 163,
          column: 8
        },
        end: {
          line: 399,
          column: 11
        }
      },
      "130": {
        start: {
          line: 400,
          column: 8
        },
        end: {
          line: 400,
          column: 36
        }
      },
      "131": {
        start: {
          line: 401,
          column: 8
        },
        end: {
          line: 401,
          column: 34
        }
      },
      "132": {
        start: {
          line: 404,
          column: 0
        },
        end: {
          line: 404,
          column: 55
        }
      },
      "133": {
        start: {
          line: 406,
          column: 0
        },
        end: {
          line: 422,
          column: 3
        }
      },
      "134": {
        start: {
          line: 407,
          column: 27
        },
        end: {
          line: 407,
          column: 68
        }
      },
      "135": {
        start: {
          line: 408,
          column: 26
        },
        end: {
          line: 408,
          column: 66
        }
      },
      "136": {
        start: {
          line: 409,
          column: 4
        },
        end: {
          line: 409,
          column: 49
        }
      },
      "137": {
        start: {
          line: 410,
          column: 4
        },
        end: {
          line: 410,
          column: 45
        }
      },
      "138": {
        start: {
          line: 411,
          column: 4
        },
        end: {
          line: 421,
          column: 7
        }
      },
      "139": {
        start: {
          line: 412,
          column: 25
        },
        end: {
          line: 412,
          column: 58
        }
      },
      "140": {
        start: {
          line: 413,
          column: 8
        },
        end: {
          line: 413,
          column: 78
        }
      },
      "141": {
        start: {
          line: 414,
          column: 8
        },
        end: {
          line: 414,
          column: 24
        }
      },
      "142": {
        start: {
          line: 416,
          column: 23
        },
        end: {
          line: 416,
          column: 75
        }
      },
      "143": {
        start: {
          line: 417,
          column: 8
        },
        end: {
          line: 419,
          column: 9
        }
      },
      "144": {
        start: {
          line: 417,
          column: 21
        },
        end: {
          line: 417,
          column: 22
        }
      },
      "145": {
        start: {
          line: 418,
          column: 12
        },
        end: {
          line: 418,
          column: 35
        }
      },
      "146": {
        start: {
          line: 420,
          column: 8
        },
        end: {
          line: 420,
          column: 113
        }
      }
    },
    fnMap: {
      "0": {
        name: "(anonymous_0)",
        decl: {
          start: {
            line: 2,
            column: 4
          },
          end: {
            line: 2,
            column: 5
          }
        },
        loc: {
          start: {
            line: 2,
            column: 17
          },
          end: {
            line: 5,
            column: 5
          }
        },
        line: 2
      },
      "1": {
        name: "(anonymous_1)",
        decl: {
          start: {
            line: 7,
            column: 4
          },
          end: {
            line: 7,
            column: 5
          }
        },
        loc: {
          start: {
            line: 7,
            column: 22
          },
          end: {
            line: 19,
            column: 5
          }
        },
        line: 7
      },
      "2": {
        name: "(anonymous_2)",
        decl: {
          start: {
            line: 22,
            column: 4
          },
          end: {
            line: 22,
            column: 5
          }
        },
        loc: {
          start: {
            line: 22,
            column: 17
          },
          end: {
            line: 29,
            column: 5
          }
        },
        line: 22
      },
      "3": {
        name: "(anonymous_3)",
        decl: {
          start: {
            line: 31,
            column: 4
          },
          end: {
            line: 31,
            column: 5
          }
        },
        loc: {
          start: {
            line: 31,
            column: 16
          },
          end: {
            line: 34,
            column: 5
          }
        },
        line: 31
      },
      "4": {
        name: "(anonymous_4)",
        decl: {
          start: {
            line: 36,
            column: 4
          },
          end: {
            line: 36,
            column: 5
          }
        },
        loc: {
          start: {
            line: 36,
            column: 18
          },
          end: {
            line: 402,
            column: 5
          }
        },
        line: 36
      },
      "5": {
        name: "(anonymous_5)",
        decl: {
          start: {
            line: 142,
            column: 45
          },
          end: {
            line: 142,
            column: 46
          }
        },
        loc: {
          start: {
            line: 142,
            column: 57
          },
          end: {
            line: 144,
            column: 9
          }
        },
        line: 142
      },
      "6": {
        name: "(anonymous_6)",
        decl: {
          start: {
            line: 406,
            column: 32
          },
          end: {
            line: 406,
            column: 33
          }
        },
        loc: {
          start: {
            line: 406,
            column: 38
          },
          end: {
            line: 422,
            column: 1
          }
        },
        line: 406
      },
      "7": {
        name: "(anonymous_7)",
        decl: {
          start: {
            line: 411,
            column: 45
          },
          end: {
            line: 411,
            column: 46
          }
        },
        loc: {
          start: {
            line: 411,
            column: 51
          },
          end: {
            line: 421,
            column: 5
          }
        },
        line: 411
      }
    },
    branchMap: {
      "0": {
        loc: {
          start: {
            line: 23,
            column: 8
          },
          end: {
            line: 27,
            column: 9
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 23,
            column: 8
          },
          end: {
            line: 27,
            column: 9
          }
        }, {
          start: {
            line: 23,
            column: 8
          },
          end: {
            line: 27,
            column: 9
          }
        }],
        line: 23
      },
      "1": {
        loc: {
          start: {
            line: 103,
            column: 8
          },
          end: {
            line: 105,
            column: 9
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 103,
            column: 8
          },
          end: {
            line: 105,
            column: 9
          }
        }, {
          start: {
            line: 103,
            column: 8
          },
          end: {
            line: 105,
            column: 9
          }
        }],
        line: 103
      }
    },
    s: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0,
      "11": 0,
      "12": 0,
      "13": 0,
      "14": 0,
      "15": 0,
      "16": 0,
      "17": 0,
      "18": 0,
      "19": 0,
      "20": 0,
      "21": 0,
      "22": 0,
      "23": 0,
      "24": 0,
      "25": 0,
      "26": 0,
      "27": 0,
      "28": 0,
      "29": 0,
      "30": 0,
      "31": 0,
      "32": 0,
      "33": 0,
      "34": 0,
      "35": 0,
      "36": 0,
      "37": 0,
      "38": 0,
      "39": 0,
      "40": 0,
      "41": 0,
      "42": 0,
      "43": 0,
      "44": 0,
      "45": 0,
      "46": 0,
      "47": 0,
      "48": 0,
      "49": 0,
      "50": 0,
      "51": 0,
      "52": 0,
      "53": 0,
      "54": 0,
      "55": 0,
      "56": 0,
      "57": 0,
      "58": 0,
      "59": 0,
      "60": 0,
      "61": 0,
      "62": 0,
      "63": 0,
      "64": 0,
      "65": 0,
      "66": 0,
      "67": 0,
      "68": 0,
      "69": 0,
      "70": 0,
      "71": 0,
      "72": 0,
      "73": 0,
      "74": 0,
      "75": 0,
      "76": 0,
      "77": 0,
      "78": 0,
      "79": 0,
      "80": 0,
      "81": 0,
      "82": 0,
      "83": 0,
      "84": 0,
      "85": 0,
      "86": 0,
      "87": 0,
      "88": 0,
      "89": 0,
      "90": 0,
      "91": 0,
      "92": 0,
      "93": 0,
      "94": 0,
      "95": 0,
      "96": 0,
      "97": 0,
      "98": 0,
      "99": 0,
      "100": 0,
      "101": 0,
      "102": 0,
      "103": 0,
      "104": 0,
      "105": 0,
      "106": 0,
      "107": 0,
      "108": 0,
      "109": 0,
      "110": 0,
      "111": 0,
      "112": 0,
      "113": 0,
      "114": 0,
      "115": 0,
      "116": 0,
      "117": 0,
      "118": 0,
      "119": 0,
      "120": 0,
      "121": 0,
      "122": 0,
      "123": 0,
      "124": 0,
      "125": 0,
      "126": 0,
      "127": 0,
      "128": 0,
      "129": 0,
      "130": 0,
      "131": 0,
      "132": 0,
      "133": 0,
      "134": 0,
      "135": 0,
      "136": 0,
      "137": 0,
      "138": 0,
      "139": 0,
      "140": 0,
      "141": 0,
      "142": 0,
      "143": 0,
      "144": 0,
      "145": 0,
      "146": 0
    },
    f: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0
    },
    b: {
      "0": [0, 0],
      "1": [0, 0]
    },
    _coverageSchema: "1a1c01bbd47fc00a2c39e90264f33305004495a9",
    hash: "1a7faee7758173ae443383bd17a48c4e74b79296"
  };
  var coverage = global[gcv] || (global[gcv] = {});

  if (!coverage[path] || coverage[path].hash !== hash) {
    coverage[path] = coverageData;
  }

  var actualCoverage = coverage[path];
  {
    // @ts-ignore
    cov_1l4fuz3y2b = function () {
      return actualCoverage;
    };
  }
  return actualCoverage;
}

cov_1l4fuz3y2b();

class SettingsPopUp extends HTMLElement {
  closePopUp() {
    cov_1l4fuz3y2b().f[0]++;
    const wrapper = (cov_1l4fuz3y2b().s[0]++, this.shadowRoot.getElementById('settings-confirm-popup'));
    cov_1l4fuz3y2b().s[1]++;
    wrapper.style.display = 'none';
  }

  confirmSettings() {
    cov_1l4fuz3y2b().f[1]++;
    const pomoLength = (cov_1l4fuz3y2b().s[2]++, parseInt(this.shadowRoot.getElementById('pomo-length-input').value, 10));
    const shortBreak = (cov_1l4fuz3y2b().s[3]++, parseInt(this.shadowRoot.getElementById('short-break-input').value, 10));
    const longBreak = (cov_1l4fuz3y2b().s[4]++, parseInt(this.shadowRoot.getElementById('long-break-input').value, 10));
    cov_1l4fuz3y2b().s[5]++;
    localStorage.setItem('pomo-length', String(pomoLength));
    cov_1l4fuz3y2b().s[6]++;
    localStorage.setItem('short-break-length', String(shortBreak));
    cov_1l4fuz3y2b().s[7]++;
    localStorage.setItem('long-break-length', String(longBreak));
    const btnSound = (cov_1l4fuz3y2b().s[8]++, new Audio('./icons/btnClick.mp3'));
    cov_1l4fuz3y2b().s[9]++;
    btnSound.volume = 0.01 * parseInt(localStorage.getItem('volume'), 10);
    cov_1l4fuz3y2b().s[10]++;
    btnSound.play();
    cov_1l4fuz3y2b().s[11]++;
    localStorage.setItem('stop', 'true');
    cov_1l4fuz3y2b().s[12]++;
    this.closePopUp();
  } // eslint-disable-line


  toggleMode() {
    cov_1l4fuz3y2b().f[2]++;
    cov_1l4fuz3y2b().s[13]++;

    if (localStorage.getItem('theme') === 'light') {
      cov_1l4fuz3y2b().b[0][0]++;
      cov_1l4fuz3y2b().s[14]++;
      localStorage.setItem('theme', 'dark');
    } else {
      cov_1l4fuz3y2b().b[0][1]++;
      cov_1l4fuz3y2b().s[15]++;
      localStorage.setItem('theme', 'light');
    }

    cov_1l4fuz3y2b().s[16]++;
    document.body.classList.toggle('dark-theme');
  }

  setVolume() {
    cov_1l4fuz3y2b().f[3]++;
    const volume = (cov_1l4fuz3y2b().s[17]++, this.shadowRoot.getElementById('range').value);
    cov_1l4fuz3y2b().s[18]++;
    localStorage.setItem('volume', `${volume}`);
  }

  constructor() {
    cov_1l4fuz3y2b().f[4]++;
    cov_1l4fuz3y2b().s[19]++;
    super();
    const shadow = (cov_1l4fuz3y2b().s[20]++, this.attachShadow({
      mode: 'open'
    })); // use div as wrapper

    const wrapper = (cov_1l4fuz3y2b().s[21]++, document.createElement('div'));
    cov_1l4fuz3y2b().s[22]++;
    wrapper.setAttribute('id', 'settings-confirm-popup'); // close icon

    const close = (cov_1l4fuz3y2b().s[23]++, wrapper.appendChild(document.createElement('img')));
    cov_1l4fuz3y2b().s[24]++;
    close.setAttribute('src', 'icons/close.svg');
    cov_1l4fuz3y2b().s[25]++;
    close.setAttribute('id', 'close-icon'); // title

    const title = (cov_1l4fuz3y2b().s[26]++, wrapper.appendChild(document.createElement('h3')));
    cov_1l4fuz3y2b().s[27]++;
    title.innerHTML = 'Settings'; // session title

    const sessionTitle = (cov_1l4fuz3y2b().s[28]++, wrapper.appendChild(document.createElement('h4')));
    cov_1l4fuz3y2b().s[29]++;
    sessionTitle.setAttribute('id', 'timer-settings');
    cov_1l4fuz3y2b().s[30]++;
    sessionTitle.innerHTML = 'Session Length (minutes)'; // session div

    const session = (cov_1l4fuz3y2b().s[31]++, wrapper.appendChild(document.createElement('div')));
    cov_1l4fuz3y2b().s[32]++;
    session.setAttribute('id', 'session'); // append input forms

    const pomoWrapper = (cov_1l4fuz3y2b().s[33]++, session.appendChild(document.createElement('div')));
    cov_1l4fuz3y2b().s[34]++;
    pomoWrapper.setAttribute('class', 'session-inputs');
    const pomoLabel = (cov_1l4fuz3y2b().s[35]++, pomoWrapper.appendChild(document.createElement('label')));
    cov_1l4fuz3y2b().s[36]++;
    pomoLabel.setAttribute('for', 'pomo');
    cov_1l4fuz3y2b().s[37]++;
    pomoLabel.innerHTML = 'Pomodoro';
    const pomoInput = (cov_1l4fuz3y2b().s[38]++, pomoWrapper.appendChild(document.createElement('input')));
    cov_1l4fuz3y2b().s[39]++;
    pomoInput.setAttribute('type', 'number');
    cov_1l4fuz3y2b().s[40]++;
    pomoInput.setAttribute('id', 'pomo-length-input');
    cov_1l4fuz3y2b().s[41]++;
    pomoInput.setAttribute('value', parseInt(localStorage.getItem('pomo-length'), 10));
    cov_1l4fuz3y2b().s[42]++;
    pomoInput.setAttribute('min', 1); // values subj. to change

    cov_1l4fuz3y2b().s[43]++;
    pomoInput.setAttribute('max', 60); // values subj. to change

    cov_1l4fuz3y2b().s[44]++;
    pomoInput.setAttribute('oninput', "validity.valid||(value='');");
    const shortBreakWrapper = (cov_1l4fuz3y2b().s[45]++, session.appendChild(document.createElement('div')));
    cov_1l4fuz3y2b().s[46]++;
    shortBreakWrapper.setAttribute('class', 'session-inputs');
    const shortBreakLabel = (cov_1l4fuz3y2b().s[47]++, shortBreakWrapper.appendChild(document.createElement('label')));
    cov_1l4fuz3y2b().s[48]++;
    shortBreakLabel.setAttribute('for', 'short-break');
    cov_1l4fuz3y2b().s[49]++;
    shortBreakLabel.innerHTML = 'Short Break';
    const shortBreakInput = (cov_1l4fuz3y2b().s[50]++, shortBreakWrapper.appendChild(document.createElement('input')));
    cov_1l4fuz3y2b().s[51]++;
    shortBreakInput.setAttribute('type', 'number');
    cov_1l4fuz3y2b().s[52]++;
    shortBreakInput.setAttribute('id', 'short-break-input');
    cov_1l4fuz3y2b().s[53]++;
    shortBreakInput.setAttribute('value', parseInt(localStorage.getItem('short-break-length'), 10));
    cov_1l4fuz3y2b().s[54]++;
    shortBreakInput.setAttribute('min', 1); // values subj. to change

    cov_1l4fuz3y2b().s[55]++;
    shortBreakInput.setAttribute('max', 60); // values subj. to change

    cov_1l4fuz3y2b().s[56]++;
    shortBreakInput.setAttribute('oninput', "validity.valid||(value='');");
    const longBreakWrapper = (cov_1l4fuz3y2b().s[57]++, session.appendChild(document.createElement('div')));
    cov_1l4fuz3y2b().s[58]++;
    longBreakWrapper.setAttribute('class', 'session-inputs');
    const longBreakLabel = (cov_1l4fuz3y2b().s[59]++, longBreakWrapper.appendChild(document.createElement('label')));
    cov_1l4fuz3y2b().s[60]++;
    longBreakLabel.setAttribute('for', 'long-break');
    cov_1l4fuz3y2b().s[61]++;
    longBreakLabel.innerHTML = 'Long Break';
    const longBreakInput = (cov_1l4fuz3y2b().s[62]++, longBreakWrapper.appendChild(document.createElement('input')));
    cov_1l4fuz3y2b().s[63]++;
    longBreakInput.setAttribute('type', 'number');
    cov_1l4fuz3y2b().s[64]++;
    longBreakInput.setAttribute('id', 'long-break-input');
    cov_1l4fuz3y2b().s[65]++;
    longBreakInput.setAttribute('value', parseInt(localStorage.getItem('long-break-length'), 10));
    cov_1l4fuz3y2b().s[66]++;
    longBreakInput.setAttribute('min', 1); // values subj. to change

    cov_1l4fuz3y2b().s[67]++;
    longBreakInput.setAttribute('max', 60); // values subj. to change

    cov_1l4fuz3y2b().s[68]++;
    longBreakInput.setAttribute('oninput', "validity.valid||(value='');"); // separate div for dark mode setting

    const darkModeDiv = (cov_1l4fuz3y2b().s[69]++, wrapper.appendChild(document.createElement('div')));
    cov_1l4fuz3y2b().s[70]++;
    darkModeDiv.setAttribute('id', 'dark-mode');
    const darkModeTitle = (cov_1l4fuz3y2b().s[71]++, darkModeDiv.appendChild(document.createElement('h4')));
    cov_1l4fuz3y2b().s[72]++;
    darkModeTitle.setAttribute('id', 'enable-dark-mode');
    cov_1l4fuz3y2b().s[73]++;
    darkModeTitle.innerHTML = 'Enable Dark Mode?';
    const modeSwitch = (cov_1l4fuz3y2b().s[74]++, darkModeDiv.appendChild(document.createElement('label')));
    cov_1l4fuz3y2b().s[75]++;
    modeSwitch.setAttribute('class', 'switch');
    const checkboxInput = (cov_1l4fuz3y2b().s[76]++, modeSwitch.appendChild(document.createElement('input')));
    cov_1l4fuz3y2b().s[77]++;
    checkboxInput.setAttribute('type', 'checkbox');
    cov_1l4fuz3y2b().s[78]++;

    if (localStorage.getItem('theme') === 'dark') {
      cov_1l4fuz3y2b().b[1][0]++;
      cov_1l4fuz3y2b().s[79]++;
      checkboxInput.checked = 'checked';
    } else {
      cov_1l4fuz3y2b().b[1][1]++;
    }

    const slider = (cov_1l4fuz3y2b().s[80]++, modeSwitch.appendChild(document.createElement('span')));
    cov_1l4fuz3y2b().s[81]++;
    slider.setAttribute('class', 'slider'); // add event listener to toggle dark mode

    cov_1l4fuz3y2b().s[82]++;
    slider.addEventListener('click', this.toggleMode.bind(this)); // separate div for volume

    const volumeDiv = (cov_1l4fuz3y2b().s[83]++, wrapper.appendChild(document.createElement('div')));
    cov_1l4fuz3y2b().s[84]++;
    volumeDiv.setAttribute('id', 'volume-div');
    const volumeTitle = (cov_1l4fuz3y2b().s[85]++, volumeDiv.appendChild(document.createElement('h4')));
    cov_1l4fuz3y2b().s[86]++;
    volumeTitle.setAttribute('id', 'sound-volume');
    cov_1l4fuz3y2b().s[87]++;
    volumeTitle.innerHTML = 'Audio Volume';
    const volP = (cov_1l4fuz3y2b().s[88]++, volumeDiv.appendChild(document.createElement('p')));
    const volSpan = (cov_1l4fuz3y2b().s[89]++, volP.appendChild(document.createElement('span')));
    cov_1l4fuz3y2b().s[90]++;
    volSpan.setAttribute('id', 'volume-number');
    const sliderDiv = (cov_1l4fuz3y2b().s[91]++, volumeDiv.appendChild(document.createElement('div')));
    cov_1l4fuz3y2b().s[92]++;
    sliderDiv.setAttribute('class', 'slider-div');
    const rangeInput = (cov_1l4fuz3y2b().s[93]++, sliderDiv.appendChild(document.createElement('input')));
    cov_1l4fuz3y2b().s[94]++;
    rangeInput.setAttribute('type', 'range');
    cov_1l4fuz3y2b().s[95]++;
    rangeInput.setAttribute('min', 0);
    cov_1l4fuz3y2b().s[96]++;
    rangeInput.setAttribute('max', 100);
    cov_1l4fuz3y2b().s[97]++;
    rangeInput.setAttribute('value', parseInt(localStorage.getItem('volume'), 10));
    cov_1l4fuz3y2b().s[98]++;
    rangeInput.setAttribute('class', 'vol-slider');
    cov_1l4fuz3y2b().s[99]++;
    rangeInput.setAttribute('id', 'range'); // append confirm btn in footer

    const footer = (cov_1l4fuz3y2b().s[100]++, wrapper.appendChild(document.createElement('div')));
    cov_1l4fuz3y2b().s[101]++;
    footer.setAttribute('class', 'button-footer');
    const confirmBtn = (cov_1l4fuz3y2b().s[102]++, footer.appendChild(document.createElement('button')));
    cov_1l4fuz3y2b().s[103]++;
    confirmBtn.setAttribute('class', 'settings-popup-btns');
    cov_1l4fuz3y2b().s[104]++;
    confirmBtn.setAttribute('id', 'confirm-settings-btn');
    cov_1l4fuz3y2b().s[105]++;
    confirmBtn.innerHTML = 'Confirm'; // event listeners for confirm btn and close icon

    cov_1l4fuz3y2b().s[106]++;
    confirmBtn.addEventListener('click', this.confirmSettings.bind(this));
    cov_1l4fuz3y2b().s[107]++;
    close.addEventListener('click', this.closePopUp.bind(this)); // event listener to set volume in local storage

    cov_1l4fuz3y2b().s[108]++;
    rangeInput.addEventListener('change', this.setVolume.bind(this));
    cov_1l4fuz3y2b().s[109]++;
    volSpan.innerHTML = rangeInput.value; // event listener to dynamically display volume

    cov_1l4fuz3y2b().s[110]++;
    rangeInput.addEventListener('input', function () {
      cov_1l4fuz3y2b().f[5]++;
      cov_1l4fuz3y2b().s[111]++;
      volSpan.innerHTML = this.value;
    }); // use ::part pseudo-element to style element outside of shadow tree -- for dark mode

    cov_1l4fuz3y2b().s[112]++;
    wrapper.setAttribute('part', 'settings-confirm-popup');
    cov_1l4fuz3y2b().s[113]++;
    close.setAttribute('part', 'close-icon');
    cov_1l4fuz3y2b().s[114]++;
    title.setAttribute('part', 'settings-h3');
    cov_1l4fuz3y2b().s[115]++;
    sessionTitle.setAttribute('part', 'timer-settings');
    cov_1l4fuz3y2b().s[116]++;
    pomoLabel.setAttribute('part', 'session-labels');
    cov_1l4fuz3y2b().s[117]++;
    pomoInput.setAttribute('part', 'length-inputs');
    cov_1l4fuz3y2b().s[118]++;
    shortBreakLabel.setAttribute('part', 'session-labels');
    cov_1l4fuz3y2b().s[119]++;
    shortBreakInput.setAttribute('part', 'length-inputs');
    cov_1l4fuz3y2b().s[120]++;
    longBreakLabel.setAttribute('part', 'session-labels');
    cov_1l4fuz3y2b().s[121]++;
    longBreakInput.setAttribute('part', 'length-inputs');
    cov_1l4fuz3y2b().s[122]++;
    darkModeTitle.setAttribute('part', 'enable-dark-mode');
    cov_1l4fuz3y2b().s[123]++;
    volumeTitle.setAttribute('part', 'sound-volume');
    cov_1l4fuz3y2b().s[124]++;
    volSpan.setAttribute('part', 'volume-number');
    cov_1l4fuz3y2b().s[125]++;
    rangeInput.setAttribute('part', 'range-slider');
    cov_1l4fuz3y2b().s[126]++;
    footer.setAttribute('part', 'btn-footer');
    cov_1l4fuz3y2b().s[127]++;
    confirmBtn.setAttribute('part', 'confirm-btn');
    const style = (cov_1l4fuz3y2b().s[128]++, document.createElement('style'));
    cov_1l4fuz3y2b().s[129]++;
    style.textContent = `
        h4 {
                font-size: 1.15vw;
        }
        p {
                display: flex;
                align-items: center;
                margin: 0;
        }
        #volume-number {
                font-size: 1.09375vw;
                font-family: Arial;
                color: rgb(85, 85, 85);
                margin-left: 1.5625vw;
        }
        .vol-slider {
                background-color: #ccc;
                -webkit-appearance: none;
                appearance: none;
                border-radius: 3.90625vw;
                height: 0.546875vw;
                width: 10.390625vw;
                outline: none;
                cursor: pointer;
                opacity: 0.7;
                -webkit-transition: .1s;
                transition: opacity .1s;
        }
        .vol-slider:hover {
                opacity: 1;
        }
        .vol-slider::-webkit-slider-thumb {
                -webkit-appearance: none;
                appearance: none;
                cursor: pointer;
                width: 1.5625vw;
                height: 1.5625vw;
                border-radius: 50%;
                background: #e6e5e5;
                box-shadow: 0 0 3px 1px rgba(0,0,0,0.2);
        }
        .vol-slider::-moz-range-thumb {
                cursor: pointer;
                width: 1.5625vw;
                height: 1.5625vw;
                border-radius: 50%;
                background: #e6e5e5;
                box-shadow: 0 0 3px 1px rgba(0,0,0,0.2);
        }
        #volume-div {
                justify-content: space-between;
                display: flex;
                width: 85%;
                margin: 1.5625vw auto 0.78125vw auto;
                padding-bottom: 1.5625vw;
        }
        .slider-div {
                position: relative;
                display: inline-flex;
                vertical-align: middle;
                align-items: center;
        }
        #sound-volume {
                color: rgb(85, 85, 85);
                margin: 0;
                font-weight: 500;
                display: flex;
                align-items: center;
        }
        #enable-dark-mode {
                color: rgb(85, 85, 85);
                font-weight: 500;
                margin: 0;
                display: flex;
                align-items: center;
        }
        #dark-mode {
                justify-content: space-between;
                display: flex;
                width: 85%;
                margin: 1.5625vw auto 0.78125vw auto;
                border-bottom: solid 1px #d2d2d2;
                padding-bottom: 1.5625vw;
        }
        .switch {
                position: relative;
                display: inline-flex;
                width: 4.6875vw;
                height: 2.65625vw;
        }
        .switch input[type='checkbox'] { 
                opacity: 0;
                width: 0;
                height: 0;
        }
        .slider {
                position: absolute;
                cursor: pointer;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-color: #ccc;
                -webkit-transition: .4s;
                transition: .4s;
                border-radius: 2.65625vw;
        }
        .slider:before {
                position: absolute;
                content: "";
                height: 2.03125vw;
                width: 2.03125vw;
                left: 0.3125vw;
                bottom: 0.3125vw;
                background-color: white;
                -webkit-transition: 0.2s;
                transition: 0.2s;
                border-radius: 50%;
        }
        input[type='checkbox']:checked + .slider {
                background-color: rgb(163 243 67 / 88%);
        }
        input[type='checkbox']:checked + .slider:before {
                -webkit-transform: translateX(2.03125vw);
                -ms-transform: translateX(2.03125vw);
                transform: translateX(2.03125vw);
        }
        #session {
                justify-content: space-between;
                display: flex;
                width: 85%;
                margin: 0.78125vw auto 0.78125vw auto;
                border-bottom: solid 1px #d2d2d2;
                padding-bottom: 1.5625vw;
        }
        label {
                display: block;
                font-size: 0.9375vw;
                color: rgb(85, 85, 85);
                font-weight: 500;
        }
        input[type='number'] {
                font-size: 1.09375vw;
                color: rgb(85, 85, 85);
                border: none;
                border-radius: 0.3125vw;
                background-color: rgb(234 234 234);
                padding: 0.78125vw;
                box-sizing: border-box;
                width: 100%;
                outline: none;
        }
        .button-footer {
                background-color: rgb(234 234 234);
                padding: 1.09375vw 1.5625vw;
                text-align: right;
                position: absolute;
                bottom: 0;
                right: 0;
                left: 0;
                border-bottom-left-radius: 0.3125vw;
                border-bottom-right-radius: 0.3125vw;
        }
        #timer-settings {
                color: rgb(85, 85, 85);
                width: 85%;
                font-weight: 500;
                margin: 1.5625vw auto 0.78125vw auto;
        }
        #close-icon {
                width: 1.171875vw;
                margin-top: 0.78125vw;
                margin-right: 0.78125vw;
                position:absolute;
                top:0;
                right:0;
                cursor: pointer;
                opacity: 0.33;
        }
        #close-icon:hover {
                opacity: 1;
                transform: scale(1.1);
        }
        #settings-confirm-popup {
                display: none;
                position: fixed;
                width: 29.296875vw;
                height: 30.46875vw;
                border-radius: 0.3125vw;
                top:20%;
                left: 34%;
                z-index: 999;
                background-color: whitesmoke;
                box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
                -webkit-animation-name: animatetop; 
                -webkit-animation-duration: 0.3s;
                animation-name: animatetop;
                animation-duration: 0.3s
        }
        @-webkit-keyframes animatetop {
                from {top:-200px; opacity:0} 
                to {top:70; opacity:1}
        }
        @keyframes animatetop {
                from {top:-200px; opacity:0}
                to {top:70; opacity:1}
        }
        #settings-confirm-popup > h3 {
                font-size: 1.6vw;
                color: #f36060;
                border-bottom: solid 1px #d2d2d2;
                padding-bottom: 0.390625vw;
                width: 85%;
                font-weight: 500;
                margin: 1.5625vw auto 0.78125vw auto;
        }
        .settings-popup-btns {
                cursor: pointer;
                border-style: none;
                border-radius: 0.3125vw;
                text-align: center;
                background-color:#f36060;
                color:#fff;
                font-family: 'Quicksand', sans-serif;
                height: 17%;
                width: 27%;
                font-size: 1.25vw;
                font-weight: 500;
                outline: none;
        }
        .settings-popup-btns:hover {
                filter: brightness(105%);
                transform: scale(1.1);
        }
        #confirm-settings-btn {
                padding: 0.625vw 0.9375vw;
        }`;
    cov_1l4fuz3y2b().s[130]++;
    shadow.appendChild(wrapper);
    cov_1l4fuz3y2b().s[131]++;
    shadow.appendChild(style);
  }

}

cov_1l4fuz3y2b().s[132]++;
customElements.define('settings-popup', SettingsPopUp);
cov_1l4fuz3y2b().s[133]++;
window.addEventListener('load', () => {
  cov_1l4fuz3y2b().f[6]++;
  const settingsButton = (cov_1l4fuz3y2b().s[134]++, document.getElementById('setting-button'));
  const settingsPopUp = (cov_1l4fuz3y2b().s[135]++, document.createElement('settings-popup'));
  cov_1l4fuz3y2b().s[136]++;
  settingsPopUp.setAttribute('class', 'popup');
  cov_1l4fuz3y2b().s[137]++;
  document.body.appendChild(settingsPopUp);
  cov_1l4fuz3y2b().s[138]++;
  settingsButton.addEventListener('click', () => {
    cov_1l4fuz3y2b().f[7]++;
    const btnSound = (cov_1l4fuz3y2b().s[139]++, new Audio('./icons/btnClick.mp3'));
    cov_1l4fuz3y2b().s[140]++;
    btnSound.volume = 0.01 * parseInt(localStorage.getItem('volume'), 10);
    cov_1l4fuz3y2b().s[141]++;
    btnSound.play(); // make sure all popups are closed before opening another one

    const popups = (cov_1l4fuz3y2b().s[142]++, Array.from(document.getElementsByClassName('popup')));
    cov_1l4fuz3y2b().s[143]++;

    for (let i = (cov_1l4fuz3y2b().s[144]++, 0); i < popups.length; i += 1) {
      cov_1l4fuz3y2b().s[145]++;
      popups[i].closePopUp();
    }

    cov_1l4fuz3y2b().s[146]++;
    settingsPopUp.shadowRoot.getElementById('settings-confirm-popup').setAttribute('style', 'display:block');
  });
}); // module.exports = SettingsPopUp;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlNldHRpbmdzUG9wVXAuanMiXSwibmFtZXMiOlsiU2V0dGluZ3NQb3BVcCIsIkhUTUxFbGVtZW50IiwiY2xvc2VQb3BVcCIsIndyYXBwZXIiLCJzaGFkb3dSb290IiwiZ2V0RWxlbWVudEJ5SWQiLCJzdHlsZSIsImRpc3BsYXkiLCJjb25maXJtU2V0dGluZ3MiLCJwb21vTGVuZ3RoIiwicGFyc2VJbnQiLCJ2YWx1ZSIsInNob3J0QnJlYWsiLCJsb25nQnJlYWsiLCJsb2NhbFN0b3JhZ2UiLCJzZXRJdGVtIiwiU3RyaW5nIiwiYnRuU291bmQiLCJBdWRpbyIsInZvbHVtZSIsImdldEl0ZW0iLCJwbGF5IiwidG9nZ2xlTW9kZSIsImRvY3VtZW50IiwiYm9keSIsImNsYXNzTGlzdCIsInRvZ2dsZSIsInNldFZvbHVtZSIsImNvbnN0cnVjdG9yIiwic2hhZG93IiwiYXR0YWNoU2hhZG93IiwibW9kZSIsImNyZWF0ZUVsZW1lbnQiLCJzZXRBdHRyaWJ1dGUiLCJjbG9zZSIsImFwcGVuZENoaWxkIiwidGl0bGUiLCJpbm5lckhUTUwiLCJzZXNzaW9uVGl0bGUiLCJzZXNzaW9uIiwicG9tb1dyYXBwZXIiLCJwb21vTGFiZWwiLCJwb21vSW5wdXQiLCJzaG9ydEJyZWFrV3JhcHBlciIsInNob3J0QnJlYWtMYWJlbCIsInNob3J0QnJlYWtJbnB1dCIsImxvbmdCcmVha1dyYXBwZXIiLCJsb25nQnJlYWtMYWJlbCIsImxvbmdCcmVha0lucHV0IiwiZGFya01vZGVEaXYiLCJkYXJrTW9kZVRpdGxlIiwibW9kZVN3aXRjaCIsImNoZWNrYm94SW5wdXQiLCJjaGVja2VkIiwic2xpZGVyIiwiYWRkRXZlbnRMaXN0ZW5lciIsImJpbmQiLCJ2b2x1bWVEaXYiLCJ2b2x1bWVUaXRsZSIsInZvbFAiLCJ2b2xTcGFuIiwic2xpZGVyRGl2IiwicmFuZ2VJbnB1dCIsImZvb3RlciIsImNvbmZpcm1CdG4iLCJ0ZXh0Q29udGVudCIsImN1c3RvbUVsZW1lbnRzIiwiZGVmaW5lIiwid2luZG93Iiwic2V0dGluZ3NCdXR0b24iLCJzZXR0aW5nc1BvcFVwIiwicG9wdXBzIiwiQXJyYXkiLCJmcm9tIiwiZ2V0RWxlbWVudHNCeUNsYXNzTmFtZSIsImkiLCJsZW5ndGgiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFlWTs7Ozs7Ozs7OztBQWZaLE1BQU1BLGFBQU4sU0FBNEJDLFdBQTVCLENBQXdDO0FBQ3BDQyxFQUFBQSxVQUFVLEdBQUc7QUFBQTtBQUNULFVBQU1DLE9BQU8sNkJBQUcsS0FBS0MsVUFBTCxDQUFnQkMsY0FBaEIsQ0FBK0Isd0JBQS9CLENBQUgsQ0FBYjtBQURTO0FBRVRGLElBQUFBLE9BQU8sQ0FBQ0csS0FBUixDQUFjQyxPQUFkLEdBQXdCLE1BQXhCO0FBQ0g7O0FBRURDLEVBQUFBLGVBQWUsR0FBRztBQUFBO0FBQ2QsVUFBTUMsVUFBVSw2QkFBR0MsUUFBUSxDQUFDLEtBQUtOLFVBQUwsQ0FBZ0JDLGNBQWhCLENBQStCLG1CQUEvQixFQUFvRE0sS0FBckQsRUFBNEQsRUFBNUQsQ0FBWCxDQUFoQjtBQUNBLFVBQU1DLFVBQVUsNkJBQUdGLFFBQVEsQ0FBQyxLQUFLTixVQUFMLENBQWdCQyxjQUFoQixDQUErQixtQkFBL0IsRUFBb0RNLEtBQXJELEVBQTRELEVBQTVELENBQVgsQ0FBaEI7QUFDQSxVQUFNRSxTQUFTLDZCQUFHSCxRQUFRLENBQUMsS0FBS04sVUFBTCxDQUFnQkMsY0FBaEIsQ0FBK0Isa0JBQS9CLEVBQW1ETSxLQUFwRCxFQUEyRCxFQUEzRCxDQUFYLENBQWY7QUFIYztBQUlkRyxJQUFBQSxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsYUFBckIsRUFBb0NDLE1BQU0sQ0FBQ1AsVUFBRCxDQUExQztBQUpjO0FBS2RLLElBQUFBLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixvQkFBckIsRUFBMkNDLE1BQU0sQ0FBQ0osVUFBRCxDQUFqRDtBQUxjO0FBTWRFLElBQUFBLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixtQkFBckIsRUFBMENDLE1BQU0sQ0FBQ0gsU0FBRCxDQUFoRDtBQUNBLFVBQU1JLFFBQVEsNkJBQUcsSUFBSUMsS0FBSixDQUFVLHNCQUFWLENBQUgsQ0FBZDtBQVBjO0FBUWRELElBQUFBLFFBQVEsQ0FBQ0UsTUFBVCxHQUFrQixPQUFPVCxRQUFRLENBQUNJLFlBQVksQ0FBQ00sT0FBYixDQUFxQixRQUFyQixDQUFELEVBQWlDLEVBQWpDLENBQWpDO0FBUmM7QUFTZEgsSUFBQUEsUUFBUSxDQUFDSSxJQUFUO0FBVGM7QUFVZFAsSUFBQUEsWUFBWSxDQUFDQyxPQUFiLENBQXFCLE1BQXJCLEVBQTZCLE1BQTdCO0FBVmM7QUFXZCxTQUFLYixVQUFMO0FBQ0gsR0FsQm1DLENBb0JwQzs7O0FBQ0FvQixFQUFBQSxVQUFVLEdBQUc7QUFBQTtBQUFBOztBQUNULFFBQUlSLFlBQVksQ0FBQ00sT0FBYixDQUFxQixPQUFyQixNQUFrQyxPQUF0QyxFQUErQztBQUFBO0FBQUE7QUFDM0NOLE1BQUFBLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixPQUFyQixFQUE4QixNQUE5QjtBQUNILEtBRkQsTUFFTztBQUFBO0FBQUE7QUFDSEQsTUFBQUEsWUFBWSxDQUFDQyxPQUFiLENBQXFCLE9BQXJCLEVBQThCLE9BQTlCO0FBQ0g7O0FBTFE7QUFNVFEsSUFBQUEsUUFBUSxDQUFDQyxJQUFULENBQWNDLFNBQWQsQ0FBd0JDLE1BQXhCLENBQStCLFlBQS9CO0FBQ0g7O0FBRURDLEVBQUFBLFNBQVMsR0FBRztBQUFBO0FBQ1IsVUFBTVIsTUFBTSw4QkFBRyxLQUFLZixVQUFMLENBQWdCQyxjQUFoQixDQUErQixPQUEvQixFQUF3Q00sS0FBM0MsQ0FBWjtBQURRO0FBRVJHLElBQUFBLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixRQUFyQixFQUFnQyxHQUFFSSxNQUFPLEVBQXpDO0FBQ0g7O0FBRURTLEVBQUFBLFdBQVcsR0FBRztBQUFBO0FBQUE7QUFDVjtBQUNBLFVBQU1DLE1BQU0sOEJBQUcsS0FBS0MsWUFBTCxDQUFrQjtBQUFFQyxNQUFBQSxJQUFJLEVBQUU7QUFBUixLQUFsQixDQUFILENBQVosQ0FGVSxDQUdWOztBQUNBLFVBQU01QixPQUFPLDhCQUFHb0IsUUFBUSxDQUFDUyxhQUFULENBQXVCLEtBQXZCLENBQUgsQ0FBYjtBQUpVO0FBS1Y3QixJQUFBQSxPQUFPLENBQUM4QixZQUFSLENBQXFCLElBQXJCLEVBQTJCLHdCQUEzQixFQUxVLENBTVY7O0FBQ0EsVUFBTUMsS0FBSyw4QkFBRy9CLE9BQU8sQ0FBQ2dDLFdBQVIsQ0FBb0JaLFFBQVEsQ0FBQ1MsYUFBVCxDQUF1QixLQUF2QixDQUFwQixDQUFILENBQVg7QUFQVTtBQVFWRSxJQUFBQSxLQUFLLENBQUNELFlBQU4sQ0FBbUIsS0FBbkIsRUFBMEIsaUJBQTFCO0FBUlU7QUFTVkMsSUFBQUEsS0FBSyxDQUFDRCxZQUFOLENBQW1CLElBQW5CLEVBQXlCLFlBQXpCLEVBVFUsQ0FVVjs7QUFDQSxVQUFNRyxLQUFLLDhCQUFHakMsT0FBTyxDQUFDZ0MsV0FBUixDQUFvQlosUUFBUSxDQUFDUyxhQUFULENBQXVCLElBQXZCLENBQXBCLENBQUgsQ0FBWDtBQVhVO0FBWVZJLElBQUFBLEtBQUssQ0FBQ0MsU0FBTixHQUFrQixVQUFsQixDQVpVLENBYVY7O0FBQ0EsVUFBTUMsWUFBWSw4QkFBR25DLE9BQU8sQ0FBQ2dDLFdBQVIsQ0FBb0JaLFFBQVEsQ0FBQ1MsYUFBVCxDQUF1QixJQUF2QixDQUFwQixDQUFILENBQWxCO0FBZFU7QUFlVk0sSUFBQUEsWUFBWSxDQUFDTCxZQUFiLENBQTBCLElBQTFCLEVBQWdDLGdCQUFoQztBQWZVO0FBZ0JWSyxJQUFBQSxZQUFZLENBQUNELFNBQWIsR0FBeUIsMEJBQXpCLENBaEJVLENBaUJWOztBQUNBLFVBQU1FLE9BQU8sOEJBQUdwQyxPQUFPLENBQUNnQyxXQUFSLENBQW9CWixRQUFRLENBQUNTLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBcEIsQ0FBSCxDQUFiO0FBbEJVO0FBbUJWTyxJQUFBQSxPQUFPLENBQUNOLFlBQVIsQ0FBcUIsSUFBckIsRUFBMkIsU0FBM0IsRUFuQlUsQ0FvQlY7O0FBQ0EsVUFBTU8sV0FBVyw4QkFBR0QsT0FBTyxDQUFDSixXQUFSLENBQW9CWixRQUFRLENBQUNTLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBcEIsQ0FBSCxDQUFqQjtBQXJCVTtBQXNCVlEsSUFBQUEsV0FBVyxDQUFDUCxZQUFaLENBQXlCLE9BQXpCLEVBQWtDLGdCQUFsQztBQUNBLFVBQU1RLFNBQVMsOEJBQUdELFdBQVcsQ0FBQ0wsV0FBWixDQUF3QlosUUFBUSxDQUFDUyxhQUFULENBQXVCLE9BQXZCLENBQXhCLENBQUgsQ0FBZjtBQXZCVTtBQXdCVlMsSUFBQUEsU0FBUyxDQUFDUixZQUFWLENBQXVCLEtBQXZCLEVBQThCLE1BQTlCO0FBeEJVO0FBeUJWUSxJQUFBQSxTQUFTLENBQUNKLFNBQVYsR0FBc0IsVUFBdEI7QUFDQSxVQUFNSyxTQUFTLDhCQUFHRixXQUFXLENBQUNMLFdBQVosQ0FBd0JaLFFBQVEsQ0FBQ1MsYUFBVCxDQUF1QixPQUF2QixDQUF4QixDQUFILENBQWY7QUExQlU7QUEyQlZVLElBQUFBLFNBQVMsQ0FBQ1QsWUFBVixDQUF1QixNQUF2QixFQUErQixRQUEvQjtBQTNCVTtBQTRCVlMsSUFBQUEsU0FBUyxDQUFDVCxZQUFWLENBQXVCLElBQXZCLEVBQTZCLG1CQUE3QjtBQTVCVTtBQTZCVlMsSUFBQUEsU0FBUyxDQUFDVCxZQUFWLENBQXVCLE9BQXZCLEVBQWdDdkIsUUFBUSxDQUFDSSxZQUFZLENBQUNNLE9BQWIsQ0FBcUIsYUFBckIsQ0FBRCxFQUFzQyxFQUF0QyxDQUF4QztBQTdCVTtBQThCVnNCLElBQUFBLFNBQVMsQ0FBQ1QsWUFBVixDQUF1QixLQUF2QixFQUE4QixDQUE5QixFQTlCVSxDQThCd0I7O0FBOUJ4QjtBQStCVlMsSUFBQUEsU0FBUyxDQUFDVCxZQUFWLENBQXVCLEtBQXZCLEVBQThCLEVBQTlCLEVBL0JVLENBK0J5Qjs7QUEvQnpCO0FBZ0NWUyxJQUFBQSxTQUFTLENBQUNULFlBQVYsQ0FBdUIsU0FBdkIsRUFBa0MsNkJBQWxDO0FBQ0EsVUFBTVUsaUJBQWlCLDhCQUFHSixPQUFPLENBQUNKLFdBQVIsQ0FBb0JaLFFBQVEsQ0FBQ1MsYUFBVCxDQUF1QixLQUF2QixDQUFwQixDQUFILENBQXZCO0FBakNVO0FBa0NWVyxJQUFBQSxpQkFBaUIsQ0FBQ1YsWUFBbEIsQ0FBK0IsT0FBL0IsRUFBd0MsZ0JBQXhDO0FBQ0EsVUFBTVcsZUFBZSw4QkFBR0QsaUJBQWlCLENBQUNSLFdBQWxCLENBQThCWixRQUFRLENBQUNTLGFBQVQsQ0FBdUIsT0FBdkIsQ0FBOUIsQ0FBSCxDQUFyQjtBQW5DVTtBQW9DVlksSUFBQUEsZUFBZSxDQUFDWCxZQUFoQixDQUE2QixLQUE3QixFQUFvQyxhQUFwQztBQXBDVTtBQXFDVlcsSUFBQUEsZUFBZSxDQUFDUCxTQUFoQixHQUE0QixhQUE1QjtBQUNBLFVBQU1RLGVBQWUsOEJBQUdGLGlCQUFpQixDQUFDUixXQUFsQixDQUE4QlosUUFBUSxDQUFDUyxhQUFULENBQXVCLE9BQXZCLENBQTlCLENBQUgsQ0FBckI7QUF0Q1U7QUF1Q1ZhLElBQUFBLGVBQWUsQ0FBQ1osWUFBaEIsQ0FBNkIsTUFBN0IsRUFBcUMsUUFBckM7QUF2Q1U7QUF3Q1ZZLElBQUFBLGVBQWUsQ0FBQ1osWUFBaEIsQ0FBNkIsSUFBN0IsRUFBbUMsbUJBQW5DO0FBeENVO0FBeUNWWSxJQUFBQSxlQUFlLENBQUNaLFlBQWhCLENBQTZCLE9BQTdCLEVBQXNDdkIsUUFBUSxDQUFDSSxZQUFZLENBQUNNLE9BQWIsQ0FBcUIsb0JBQXJCLENBQUQsRUFBNkMsRUFBN0MsQ0FBOUM7QUF6Q1U7QUEwQ1Z5QixJQUFBQSxlQUFlLENBQUNaLFlBQWhCLENBQTZCLEtBQTdCLEVBQW9DLENBQXBDLEVBMUNVLENBMEM4Qjs7QUExQzlCO0FBMkNWWSxJQUFBQSxlQUFlLENBQUNaLFlBQWhCLENBQTZCLEtBQTdCLEVBQW9DLEVBQXBDLEVBM0NVLENBMkMrQjs7QUEzQy9CO0FBNENWWSxJQUFBQSxlQUFlLENBQUNaLFlBQWhCLENBQTZCLFNBQTdCLEVBQXdDLDZCQUF4QztBQUNBLFVBQU1hLGdCQUFnQiw4QkFBR1AsT0FBTyxDQUFDSixXQUFSLENBQW9CWixRQUFRLENBQUNTLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBcEIsQ0FBSCxDQUF0QjtBQTdDVTtBQThDVmMsSUFBQUEsZ0JBQWdCLENBQUNiLFlBQWpCLENBQThCLE9BQTlCLEVBQXVDLGdCQUF2QztBQUNBLFVBQU1jLGNBQWMsOEJBQUdELGdCQUFnQixDQUFDWCxXQUFqQixDQUE2QlosUUFBUSxDQUFDUyxhQUFULENBQXVCLE9BQXZCLENBQTdCLENBQUgsQ0FBcEI7QUEvQ1U7QUFnRFZlLElBQUFBLGNBQWMsQ0FBQ2QsWUFBZixDQUE0QixLQUE1QixFQUFtQyxZQUFuQztBQWhEVTtBQWlEVmMsSUFBQUEsY0FBYyxDQUFDVixTQUFmLEdBQTJCLFlBQTNCO0FBQ0EsVUFBTVcsY0FBYyw4QkFBR0YsZ0JBQWdCLENBQUNYLFdBQWpCLENBQTZCWixRQUFRLENBQUNTLGFBQVQsQ0FBdUIsT0FBdkIsQ0FBN0IsQ0FBSCxDQUFwQjtBQWxEVTtBQW1EVmdCLElBQUFBLGNBQWMsQ0FBQ2YsWUFBZixDQUE0QixNQUE1QixFQUFvQyxRQUFwQztBQW5EVTtBQW9EVmUsSUFBQUEsY0FBYyxDQUFDZixZQUFmLENBQTRCLElBQTVCLEVBQWtDLGtCQUFsQztBQXBEVTtBQXFEVmUsSUFBQUEsY0FBYyxDQUFDZixZQUFmLENBQTRCLE9BQTVCLEVBQXFDdkIsUUFBUSxDQUFDSSxZQUFZLENBQUNNLE9BQWIsQ0FBcUIsbUJBQXJCLENBQUQsRUFBNEMsRUFBNUMsQ0FBN0M7QUFyRFU7QUFzRFY0QixJQUFBQSxjQUFjLENBQUNmLFlBQWYsQ0FBNEIsS0FBNUIsRUFBbUMsQ0FBbkMsRUF0RFUsQ0FzRDZCOztBQXREN0I7QUF1RFZlLElBQUFBLGNBQWMsQ0FBQ2YsWUFBZixDQUE0QixLQUE1QixFQUFtQyxFQUFuQyxFQXZEVSxDQXVEOEI7O0FBdkQ5QjtBQXdEVmUsSUFBQUEsY0FBYyxDQUFDZixZQUFmLENBQTRCLFNBQTVCLEVBQXVDLDZCQUF2QyxFQXhEVSxDQXlEVjs7QUFDQSxVQUFNZ0IsV0FBVyw4QkFBRzlDLE9BQU8sQ0FBQ2dDLFdBQVIsQ0FBb0JaLFFBQVEsQ0FBQ1MsYUFBVCxDQUF1QixLQUF2QixDQUFwQixDQUFILENBQWpCO0FBMURVO0FBMkRWaUIsSUFBQUEsV0FBVyxDQUFDaEIsWUFBWixDQUF5QixJQUF6QixFQUErQixXQUEvQjtBQUNBLFVBQU1pQixhQUFhLDhCQUFHRCxXQUFXLENBQUNkLFdBQVosQ0FBd0JaLFFBQVEsQ0FBQ1MsYUFBVCxDQUF1QixJQUF2QixDQUF4QixDQUFILENBQW5CO0FBNURVO0FBNkRWa0IsSUFBQUEsYUFBYSxDQUFDakIsWUFBZCxDQUEyQixJQUEzQixFQUFpQyxrQkFBakM7QUE3RFU7QUE4RFZpQixJQUFBQSxhQUFhLENBQUNiLFNBQWQsR0FBMEIsbUJBQTFCO0FBQ0EsVUFBTWMsVUFBVSw4QkFBR0YsV0FBVyxDQUFDZCxXQUFaLENBQXdCWixRQUFRLENBQUNTLGFBQVQsQ0FBdUIsT0FBdkIsQ0FBeEIsQ0FBSCxDQUFoQjtBQS9EVTtBQWdFVm1CLElBQUFBLFVBQVUsQ0FBQ2xCLFlBQVgsQ0FBd0IsT0FBeEIsRUFBaUMsUUFBakM7QUFDQSxVQUFNbUIsYUFBYSw4QkFBR0QsVUFBVSxDQUFDaEIsV0FBWCxDQUF1QlosUUFBUSxDQUFDUyxhQUFULENBQXVCLE9BQXZCLENBQXZCLENBQUgsQ0FBbkI7QUFqRVU7QUFrRVZvQixJQUFBQSxhQUFhLENBQUNuQixZQUFkLENBQTJCLE1BQTNCLEVBQW1DLFVBQW5DO0FBbEVVOztBQW1FVixRQUFJbkIsWUFBWSxDQUFDTSxPQUFiLENBQXFCLE9BQXJCLE1BQWtDLE1BQXRDLEVBQThDO0FBQUE7QUFBQTtBQUMxQ2dDLE1BQUFBLGFBQWEsQ0FBQ0MsT0FBZCxHQUF3QixTQUF4QjtBQUNILEtBRkQ7QUFBQTtBQUFBOztBQUdBLFVBQU1DLE1BQU0sOEJBQUdILFVBQVUsQ0FBQ2hCLFdBQVgsQ0FBdUJaLFFBQVEsQ0FBQ1MsYUFBVCxDQUF1QixNQUF2QixDQUF2QixDQUFILENBQVo7QUF0RVU7QUF1RVZzQixJQUFBQSxNQUFNLENBQUNyQixZQUFQLENBQW9CLE9BQXBCLEVBQTZCLFFBQTdCLEVBdkVVLENBd0VWOztBQXhFVTtBQXlFVnFCLElBQUFBLE1BQU0sQ0FBQ0MsZ0JBQVAsQ0FBd0IsT0FBeEIsRUFBaUMsS0FBS2pDLFVBQUwsQ0FBZ0JrQyxJQUFoQixDQUFxQixJQUFyQixDQUFqQyxFQXpFVSxDQTBFVjs7QUFDQSxVQUFNQyxTQUFTLDhCQUFHdEQsT0FBTyxDQUFDZ0MsV0FBUixDQUFvQlosUUFBUSxDQUFDUyxhQUFULENBQXVCLEtBQXZCLENBQXBCLENBQUgsQ0FBZjtBQTNFVTtBQTRFVnlCLElBQUFBLFNBQVMsQ0FBQ3hCLFlBQVYsQ0FBdUIsSUFBdkIsRUFBNkIsWUFBN0I7QUFDQSxVQUFNeUIsV0FBVyw4QkFBR0QsU0FBUyxDQUFDdEIsV0FBVixDQUFzQlosUUFBUSxDQUFDUyxhQUFULENBQXVCLElBQXZCLENBQXRCLENBQUgsQ0FBakI7QUE3RVU7QUE4RVYwQixJQUFBQSxXQUFXLENBQUN6QixZQUFaLENBQXlCLElBQXpCLEVBQStCLGNBQS9CO0FBOUVVO0FBK0VWeUIsSUFBQUEsV0FBVyxDQUFDckIsU0FBWixHQUF3QixjQUF4QjtBQUNBLFVBQU1zQixJQUFJLDhCQUFHRixTQUFTLENBQUN0QixXQUFWLENBQXNCWixRQUFRLENBQUNTLGFBQVQsQ0FBdUIsR0FBdkIsQ0FBdEIsQ0FBSCxDQUFWO0FBQ0EsVUFBTTRCLE9BQU8sOEJBQUdELElBQUksQ0FBQ3hCLFdBQUwsQ0FBaUJaLFFBQVEsQ0FBQ1MsYUFBVCxDQUF1QixNQUF2QixDQUFqQixDQUFILENBQWI7QUFqRlU7QUFrRlY0QixJQUFBQSxPQUFPLENBQUMzQixZQUFSLENBQXFCLElBQXJCLEVBQTJCLGVBQTNCO0FBQ0EsVUFBTTRCLFNBQVMsOEJBQUdKLFNBQVMsQ0FBQ3RCLFdBQVYsQ0FBc0JaLFFBQVEsQ0FBQ1MsYUFBVCxDQUF1QixLQUF2QixDQUF0QixDQUFILENBQWY7QUFuRlU7QUFvRlY2QixJQUFBQSxTQUFTLENBQUM1QixZQUFWLENBQXVCLE9BQXZCLEVBQWdDLFlBQWhDO0FBQ0EsVUFBTTZCLFVBQVUsOEJBQUdELFNBQVMsQ0FBQzFCLFdBQVYsQ0FBc0JaLFFBQVEsQ0FBQ1MsYUFBVCxDQUF1QixPQUF2QixDQUF0QixDQUFILENBQWhCO0FBckZVO0FBc0ZWOEIsSUFBQUEsVUFBVSxDQUFDN0IsWUFBWCxDQUF3QixNQUF4QixFQUFnQyxPQUFoQztBQXRGVTtBQXVGVjZCLElBQUFBLFVBQVUsQ0FBQzdCLFlBQVgsQ0FBd0IsS0FBeEIsRUFBK0IsQ0FBL0I7QUF2RlU7QUF3RlY2QixJQUFBQSxVQUFVLENBQUM3QixZQUFYLENBQXdCLEtBQXhCLEVBQStCLEdBQS9CO0FBeEZVO0FBeUZWNkIsSUFBQUEsVUFBVSxDQUFDN0IsWUFBWCxDQUF3QixPQUF4QixFQUFpQ3ZCLFFBQVEsQ0FBQ0ksWUFBWSxDQUFDTSxPQUFiLENBQXFCLFFBQXJCLENBQUQsRUFBaUMsRUFBakMsQ0FBekM7QUF6RlU7QUEwRlYwQyxJQUFBQSxVQUFVLENBQUM3QixZQUFYLENBQXdCLE9BQXhCLEVBQWlDLFlBQWpDO0FBMUZVO0FBMkZWNkIsSUFBQUEsVUFBVSxDQUFDN0IsWUFBWCxDQUF3QixJQUF4QixFQUE4QixPQUE5QixFQTNGVSxDQTRGVjs7QUFDQSxVQUFNOEIsTUFBTSwrQkFBRzVELE9BQU8sQ0FBQ2dDLFdBQVIsQ0FBb0JaLFFBQVEsQ0FBQ1MsYUFBVCxDQUF1QixLQUF2QixDQUFwQixDQUFILENBQVo7QUE3RlU7QUE4RlYrQixJQUFBQSxNQUFNLENBQUM5QixZQUFQLENBQW9CLE9BQXBCLEVBQTZCLGVBQTdCO0FBQ0EsVUFBTStCLFVBQVUsK0JBQUdELE1BQU0sQ0FBQzVCLFdBQVAsQ0FBbUJaLFFBQVEsQ0FBQ1MsYUFBVCxDQUF1QixRQUF2QixDQUFuQixDQUFILENBQWhCO0FBL0ZVO0FBZ0dWZ0MsSUFBQUEsVUFBVSxDQUFDL0IsWUFBWCxDQUF3QixPQUF4QixFQUFpQyxxQkFBakM7QUFoR1U7QUFpR1YrQixJQUFBQSxVQUFVLENBQUMvQixZQUFYLENBQXdCLElBQXhCLEVBQThCLHNCQUE5QjtBQWpHVTtBQWtHVitCLElBQUFBLFVBQVUsQ0FBQzNCLFNBQVgsR0FBdUIsU0FBdkIsQ0FsR1UsQ0FtR1Y7O0FBbkdVO0FBb0dWMkIsSUFBQUEsVUFBVSxDQUFDVCxnQkFBWCxDQUE0QixPQUE1QixFQUFxQyxLQUFLL0MsZUFBTCxDQUFxQmdELElBQXJCLENBQTBCLElBQTFCLENBQXJDO0FBcEdVO0FBcUdWdEIsSUFBQUEsS0FBSyxDQUFDcUIsZ0JBQU4sQ0FBdUIsT0FBdkIsRUFBZ0MsS0FBS3JELFVBQUwsQ0FBZ0JzRCxJQUFoQixDQUFxQixJQUFyQixDQUFoQyxFQXJHVSxDQXNHVjs7QUF0R1U7QUF1R1ZNLElBQUFBLFVBQVUsQ0FBQ1AsZ0JBQVgsQ0FBNEIsUUFBNUIsRUFBc0MsS0FBSzVCLFNBQUwsQ0FBZTZCLElBQWYsQ0FBb0IsSUFBcEIsQ0FBdEM7QUF2R1U7QUF3R1ZJLElBQUFBLE9BQU8sQ0FBQ3ZCLFNBQVIsR0FBb0J5QixVQUFVLENBQUNuRCxLQUEvQixDQXhHVSxDQXlHVjs7QUF6R1U7QUEwR1ZtRCxJQUFBQSxVQUFVLENBQUNQLGdCQUFYLENBQTRCLE9BQTVCLEVBQXFDLFlBQVk7QUFBQTtBQUFBO0FBQzdDSyxNQUFBQSxPQUFPLENBQUN2QixTQUFSLEdBQW9CLEtBQUsxQixLQUF6QjtBQUNILEtBRkQsRUExR1UsQ0E2R1Y7O0FBN0dVO0FBOEdWUixJQUFBQSxPQUFPLENBQUM4QixZQUFSLENBQXFCLE1BQXJCLEVBQTZCLHdCQUE3QjtBQTlHVTtBQStHVkMsSUFBQUEsS0FBSyxDQUFDRCxZQUFOLENBQW1CLE1BQW5CLEVBQTJCLFlBQTNCO0FBL0dVO0FBZ0hWRyxJQUFBQSxLQUFLLENBQUNILFlBQU4sQ0FBbUIsTUFBbkIsRUFBMkIsYUFBM0I7QUFoSFU7QUFpSFZLLElBQUFBLFlBQVksQ0FBQ0wsWUFBYixDQUEwQixNQUExQixFQUFrQyxnQkFBbEM7QUFqSFU7QUFrSFZRLElBQUFBLFNBQVMsQ0FBQ1IsWUFBVixDQUF1QixNQUF2QixFQUErQixnQkFBL0I7QUFsSFU7QUFtSFZTLElBQUFBLFNBQVMsQ0FBQ1QsWUFBVixDQUF1QixNQUF2QixFQUErQixlQUEvQjtBQW5IVTtBQW9IVlcsSUFBQUEsZUFBZSxDQUFDWCxZQUFoQixDQUE2QixNQUE3QixFQUFxQyxnQkFBckM7QUFwSFU7QUFxSFZZLElBQUFBLGVBQWUsQ0FBQ1osWUFBaEIsQ0FBNkIsTUFBN0IsRUFBcUMsZUFBckM7QUFySFU7QUFzSFZjLElBQUFBLGNBQWMsQ0FBQ2QsWUFBZixDQUE0QixNQUE1QixFQUFvQyxnQkFBcEM7QUF0SFU7QUF1SFZlLElBQUFBLGNBQWMsQ0FBQ2YsWUFBZixDQUE0QixNQUE1QixFQUFvQyxlQUFwQztBQXZIVTtBQXdIVmlCLElBQUFBLGFBQWEsQ0FBQ2pCLFlBQWQsQ0FBMkIsTUFBM0IsRUFBbUMsa0JBQW5DO0FBeEhVO0FBeUhWeUIsSUFBQUEsV0FBVyxDQUFDekIsWUFBWixDQUF5QixNQUF6QixFQUFpQyxjQUFqQztBQXpIVTtBQTBIVjJCLElBQUFBLE9BQU8sQ0FBQzNCLFlBQVIsQ0FBcUIsTUFBckIsRUFBNkIsZUFBN0I7QUExSFU7QUEySFY2QixJQUFBQSxVQUFVLENBQUM3QixZQUFYLENBQXdCLE1BQXhCLEVBQWdDLGNBQWhDO0FBM0hVO0FBNEhWOEIsSUFBQUEsTUFBTSxDQUFDOUIsWUFBUCxDQUFvQixNQUFwQixFQUE0QixZQUE1QjtBQTVIVTtBQTZIVitCLElBQUFBLFVBQVUsQ0FBQy9CLFlBQVgsQ0FBd0IsTUFBeEIsRUFBZ0MsYUFBaEM7QUFDQSxVQUFNM0IsS0FBSywrQkFBR2lCLFFBQVEsQ0FBQ1MsYUFBVCxDQUF1QixPQUF2QixDQUFILENBQVg7QUE5SFU7QUErSFYxQixJQUFBQSxLQUFLLENBQUMyRCxXQUFOLEdBQXFCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUE1T1E7QUEvSFU7QUE0V1ZwQyxJQUFBQSxNQUFNLENBQUNNLFdBQVAsQ0FBbUJoQyxPQUFuQjtBQTVXVTtBQTZXVjBCLElBQUFBLE1BQU0sQ0FBQ00sV0FBUCxDQUFtQjdCLEtBQW5CO0FBQ0g7O0FBalptQzs7O0FBbVp4QzRELGNBQWMsQ0FBQ0MsTUFBZixDQUFzQixnQkFBdEIsRUFBd0NuRSxhQUF4Qzs7QUFFQW9FLE1BQU0sQ0FBQ2IsZ0JBQVAsQ0FBd0IsTUFBeEIsRUFBZ0MsTUFBTTtBQUFBO0FBQ2xDLFFBQU1jLGNBQWMsK0JBQUc5QyxRQUFRLENBQUNsQixjQUFULENBQXdCLGdCQUF4QixDQUFILENBQXBCO0FBQ0EsUUFBTWlFLGFBQWEsK0JBQUcvQyxRQUFRLENBQUNTLGFBQVQsQ0FBdUIsZ0JBQXZCLENBQUgsQ0FBbkI7QUFGa0M7QUFHbENzQyxFQUFBQSxhQUFhLENBQUNyQyxZQUFkLENBQTJCLE9BQTNCLEVBQW9DLE9BQXBDO0FBSGtDO0FBSWxDVixFQUFBQSxRQUFRLENBQUNDLElBQVQsQ0FBY1csV0FBZCxDQUEwQm1DLGFBQTFCO0FBSmtDO0FBS2xDRCxFQUFBQSxjQUFjLENBQUNkLGdCQUFmLENBQWdDLE9BQWhDLEVBQXlDLE1BQU07QUFBQTtBQUMzQyxVQUFNdEMsUUFBUSwrQkFBRyxJQUFJQyxLQUFKLENBQVUsc0JBQVYsQ0FBSCxDQUFkO0FBRDJDO0FBRTNDRCxJQUFBQSxRQUFRLENBQUNFLE1BQVQsR0FBa0IsT0FBT1QsUUFBUSxDQUFDSSxZQUFZLENBQUNNLE9BQWIsQ0FBcUIsUUFBckIsQ0FBRCxFQUFpQyxFQUFqQyxDQUFqQztBQUYyQztBQUczQ0gsSUFBQUEsUUFBUSxDQUFDSSxJQUFULEdBSDJDLENBSTNDOztBQUNBLFVBQU1rRCxNQUFNLCtCQUFHQyxLQUFLLENBQUNDLElBQU4sQ0FBV2xELFFBQVEsQ0FBQ21ELHNCQUFULENBQWdDLE9BQWhDLENBQVgsQ0FBSCxDQUFaO0FBTDJDOztBQU0zQyxTQUFLLElBQUlDLENBQUMsK0JBQUcsQ0FBSCxDQUFWLEVBQWdCQSxDQUFDLEdBQUdKLE1BQU0sQ0FBQ0ssTUFBM0IsRUFBbUNELENBQUMsSUFBSSxDQUF4QyxFQUEyQztBQUFBO0FBQ3ZDSixNQUFBQSxNQUFNLENBQUNJLENBQUQsQ0FBTixDQUFVekUsVUFBVjtBQUNIOztBQVIwQztBQVMzQ29FLElBQUFBLGFBQWEsQ0FBQ2xFLFVBQWQsQ0FBeUJDLGNBQXpCLENBQXdDLHdCQUF4QyxFQUFrRTRCLFlBQWxFLENBQStFLE9BQS9FLEVBQXdGLGVBQXhGO0FBQ0gsR0FWRDtBQVdILENBaEJELEUsQ0FrQkEiLCJzb3VyY2VzQ29udGVudCI6WyJjbGFzcyBTZXR0aW5nc1BvcFVwIGV4dGVuZHMgSFRNTEVsZW1lbnQge1xyXG4gICAgY2xvc2VQb3BVcCgpIHtcclxuICAgICAgICBjb25zdCB3cmFwcGVyID0gdGhpcy5zaGFkb3dSb290LmdldEVsZW1lbnRCeUlkKCdzZXR0aW5ncy1jb25maXJtLXBvcHVwJyk7XHJcbiAgICAgICAgd3JhcHBlci5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbmZpcm1TZXR0aW5ncygpIHtcclxuICAgICAgICBjb25zdCBwb21vTGVuZ3RoID0gcGFyc2VJbnQodGhpcy5zaGFkb3dSb290LmdldEVsZW1lbnRCeUlkKCdwb21vLWxlbmd0aC1pbnB1dCcpLnZhbHVlLCAxMCk7XHJcbiAgICAgICAgY29uc3Qgc2hvcnRCcmVhayA9IHBhcnNlSW50KHRoaXMuc2hhZG93Um9vdC5nZXRFbGVtZW50QnlJZCgnc2hvcnQtYnJlYWstaW5wdXQnKS52YWx1ZSwgMTApO1xyXG4gICAgICAgIGNvbnN0IGxvbmdCcmVhayA9IHBhcnNlSW50KHRoaXMuc2hhZG93Um9vdC5nZXRFbGVtZW50QnlJZCgnbG9uZy1icmVhay1pbnB1dCcpLnZhbHVlLCAxMCk7XHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3BvbW8tbGVuZ3RoJywgU3RyaW5nKHBvbW9MZW5ndGgpKTtcclxuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnc2hvcnQtYnJlYWstbGVuZ3RoJywgU3RyaW5nKHNob3J0QnJlYWspKTtcclxuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnbG9uZy1icmVhay1sZW5ndGgnLCBTdHJpbmcobG9uZ0JyZWFrKSk7XHJcbiAgICAgICAgY29uc3QgYnRuU291bmQgPSBuZXcgQXVkaW8oJy4vaWNvbnMvYnRuQ2xpY2subXAzJyk7XHJcbiAgICAgICAgYnRuU291bmQudm9sdW1lID0gMC4wMSAqIHBhcnNlSW50KGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd2b2x1bWUnKSwgMTApO1xyXG4gICAgICAgIGJ0blNvdW5kLnBsYXkoKTtcclxuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnc3RvcCcsICd0cnVlJyk7XHJcbiAgICAgICAgdGhpcy5jbG9zZVBvcFVwKCk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbGluZVxyXG4gICAgdG9nZ2xlTW9kZSgpIHtcclxuICAgICAgICBpZiAobG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3RoZW1lJykgPT09ICdsaWdodCcpIHtcclxuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3RoZW1lJywgJ2RhcmsnKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgndGhlbWUnLCAnbGlnaHQnKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QudG9nZ2xlKCdkYXJrLXRoZW1lJyk7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0Vm9sdW1lKCkge1xyXG4gICAgICAgIGNvbnN0IHZvbHVtZSA9IHRoaXMuc2hhZG93Um9vdC5nZXRFbGVtZW50QnlJZCgncmFuZ2UnKS52YWx1ZTtcclxuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgndm9sdW1lJywgYCR7dm9sdW1lfWApO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgICAgIHN1cGVyKCk7XHJcbiAgICAgICAgY29uc3Qgc2hhZG93ID0gdGhpcy5hdHRhY2hTaGFkb3coeyBtb2RlOiAnb3BlbicgfSk7XHJcbiAgICAgICAgLy8gdXNlIGRpdiBhcyB3cmFwcGVyXHJcbiAgICAgICAgY29uc3Qgd3JhcHBlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgICAgIHdyYXBwZXIuc2V0QXR0cmlidXRlKCdpZCcsICdzZXR0aW5ncy1jb25maXJtLXBvcHVwJyk7XHJcbiAgICAgICAgLy8gY2xvc2UgaWNvblxyXG4gICAgICAgIGNvbnN0IGNsb3NlID0gd3JhcHBlci5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdpbWcnKSk7XHJcbiAgICAgICAgY2xvc2Uuc2V0QXR0cmlidXRlKCdzcmMnLCAnaWNvbnMvY2xvc2Uuc3ZnJyk7XHJcbiAgICAgICAgY2xvc2Uuc2V0QXR0cmlidXRlKCdpZCcsICdjbG9zZS1pY29uJyk7XHJcbiAgICAgICAgLy8gdGl0bGVcclxuICAgICAgICBjb25zdCB0aXRsZSA9IHdyYXBwZXIuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaDMnKSk7XHJcbiAgICAgICAgdGl0bGUuaW5uZXJIVE1MID0gJ1NldHRpbmdzJztcclxuICAgICAgICAvLyBzZXNzaW9uIHRpdGxlXHJcbiAgICAgICAgY29uc3Qgc2Vzc2lvblRpdGxlID0gd3JhcHBlci5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdoNCcpKTtcclxuICAgICAgICBzZXNzaW9uVGl0bGUuc2V0QXR0cmlidXRlKCdpZCcsICd0aW1lci1zZXR0aW5ncycpO1xyXG4gICAgICAgIHNlc3Npb25UaXRsZS5pbm5lckhUTUwgPSAnU2Vzc2lvbiBMZW5ndGggKG1pbnV0ZXMpJztcclxuICAgICAgICAvLyBzZXNzaW9uIGRpdlxyXG4gICAgICAgIGNvbnN0IHNlc3Npb24gPSB3cmFwcGVyLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpKTtcclxuICAgICAgICBzZXNzaW9uLnNldEF0dHJpYnV0ZSgnaWQnLCAnc2Vzc2lvbicpO1xyXG4gICAgICAgIC8vIGFwcGVuZCBpbnB1dCBmb3Jtc1xyXG4gICAgICAgIGNvbnN0IHBvbW9XcmFwcGVyID0gc2Vzc2lvbi5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKSk7XHJcbiAgICAgICAgcG9tb1dyYXBwZXIuc2V0QXR0cmlidXRlKCdjbGFzcycsICdzZXNzaW9uLWlucHV0cycpO1xyXG4gICAgICAgIGNvbnN0IHBvbW9MYWJlbCA9IHBvbW9XcmFwcGVyLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xhYmVsJykpO1xyXG4gICAgICAgIHBvbW9MYWJlbC5zZXRBdHRyaWJ1dGUoJ2ZvcicsICdwb21vJyk7XHJcbiAgICAgICAgcG9tb0xhYmVsLmlubmVySFRNTCA9ICdQb21vZG9ybyc7XHJcbiAgICAgICAgY29uc3QgcG9tb0lucHV0ID0gcG9tb1dyYXBwZXIuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaW5wdXQnKSk7XHJcbiAgICAgICAgcG9tb0lucHV0LnNldEF0dHJpYnV0ZSgndHlwZScsICdudW1iZXInKTtcclxuICAgICAgICBwb21vSW5wdXQuc2V0QXR0cmlidXRlKCdpZCcsICdwb21vLWxlbmd0aC1pbnB1dCcpO1xyXG4gICAgICAgIHBvbW9JbnB1dC5zZXRBdHRyaWJ1dGUoJ3ZhbHVlJywgcGFyc2VJbnQobG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3BvbW8tbGVuZ3RoJyksIDEwKSk7XHJcbiAgICAgICAgcG9tb0lucHV0LnNldEF0dHJpYnV0ZSgnbWluJywgMSk7IC8vIHZhbHVlcyBzdWJqLiB0byBjaGFuZ2VcclxuICAgICAgICBwb21vSW5wdXQuc2V0QXR0cmlidXRlKCdtYXgnLCA2MCk7IC8vIHZhbHVlcyBzdWJqLiB0byBjaGFuZ2VcclxuICAgICAgICBwb21vSW5wdXQuc2V0QXR0cmlidXRlKCdvbmlucHV0JywgXCJ2YWxpZGl0eS52YWxpZHx8KHZhbHVlPScnKTtcIik7XHJcbiAgICAgICAgY29uc3Qgc2hvcnRCcmVha1dyYXBwZXIgPSBzZXNzaW9uLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpKTtcclxuICAgICAgICBzaG9ydEJyZWFrV3JhcHBlci5zZXRBdHRyaWJ1dGUoJ2NsYXNzJywgJ3Nlc3Npb24taW5wdXRzJyk7XHJcbiAgICAgICAgY29uc3Qgc2hvcnRCcmVha0xhYmVsID0gc2hvcnRCcmVha1dyYXBwZXIuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGFiZWwnKSk7XHJcbiAgICAgICAgc2hvcnRCcmVha0xhYmVsLnNldEF0dHJpYnV0ZSgnZm9yJywgJ3Nob3J0LWJyZWFrJyk7XHJcbiAgICAgICAgc2hvcnRCcmVha0xhYmVsLmlubmVySFRNTCA9ICdTaG9ydCBCcmVhayc7XHJcbiAgICAgICAgY29uc3Qgc2hvcnRCcmVha0lucHV0ID0gc2hvcnRCcmVha1dyYXBwZXIuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaW5wdXQnKSk7XHJcbiAgICAgICAgc2hvcnRCcmVha0lucHV0LnNldEF0dHJpYnV0ZSgndHlwZScsICdudW1iZXInKTtcclxuICAgICAgICBzaG9ydEJyZWFrSW5wdXQuc2V0QXR0cmlidXRlKCdpZCcsICdzaG9ydC1icmVhay1pbnB1dCcpO1xyXG4gICAgICAgIHNob3J0QnJlYWtJbnB1dC5zZXRBdHRyaWJ1dGUoJ3ZhbHVlJywgcGFyc2VJbnQobG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3Nob3J0LWJyZWFrLWxlbmd0aCcpLCAxMCkpO1xyXG4gICAgICAgIHNob3J0QnJlYWtJbnB1dC5zZXRBdHRyaWJ1dGUoJ21pbicsIDEpOyAvLyB2YWx1ZXMgc3Viai4gdG8gY2hhbmdlXHJcbiAgICAgICAgc2hvcnRCcmVha0lucHV0LnNldEF0dHJpYnV0ZSgnbWF4JywgNjApOyAvLyB2YWx1ZXMgc3Viai4gdG8gY2hhbmdlXHJcbiAgICAgICAgc2hvcnRCcmVha0lucHV0LnNldEF0dHJpYnV0ZSgnb25pbnB1dCcsIFwidmFsaWRpdHkudmFsaWR8fCh2YWx1ZT0nJyk7XCIpO1xyXG4gICAgICAgIGNvbnN0IGxvbmdCcmVha1dyYXBwZXIgPSBzZXNzaW9uLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpKTtcclxuICAgICAgICBsb25nQnJlYWtXcmFwcGVyLnNldEF0dHJpYnV0ZSgnY2xhc3MnLCAnc2Vzc2lvbi1pbnB1dHMnKTtcclxuICAgICAgICBjb25zdCBsb25nQnJlYWtMYWJlbCA9IGxvbmdCcmVha1dyYXBwZXIuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGFiZWwnKSk7XHJcbiAgICAgICAgbG9uZ0JyZWFrTGFiZWwuc2V0QXR0cmlidXRlKCdmb3InLCAnbG9uZy1icmVhaycpO1xyXG4gICAgICAgIGxvbmdCcmVha0xhYmVsLmlubmVySFRNTCA9ICdMb25nIEJyZWFrJztcclxuICAgICAgICBjb25zdCBsb25nQnJlYWtJbnB1dCA9IGxvbmdCcmVha1dyYXBwZXIuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaW5wdXQnKSk7XHJcbiAgICAgICAgbG9uZ0JyZWFrSW5wdXQuc2V0QXR0cmlidXRlKCd0eXBlJywgJ251bWJlcicpO1xyXG4gICAgICAgIGxvbmdCcmVha0lucHV0LnNldEF0dHJpYnV0ZSgnaWQnLCAnbG9uZy1icmVhay1pbnB1dCcpO1xyXG4gICAgICAgIGxvbmdCcmVha0lucHV0LnNldEF0dHJpYnV0ZSgndmFsdWUnLCBwYXJzZUludChsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbG9uZy1icmVhay1sZW5ndGgnKSwgMTApKTtcclxuICAgICAgICBsb25nQnJlYWtJbnB1dC5zZXRBdHRyaWJ1dGUoJ21pbicsIDEpOyAvLyB2YWx1ZXMgc3Viai4gdG8gY2hhbmdlXHJcbiAgICAgICAgbG9uZ0JyZWFrSW5wdXQuc2V0QXR0cmlidXRlKCdtYXgnLCA2MCk7IC8vIHZhbHVlcyBzdWJqLiB0byBjaGFuZ2VcclxuICAgICAgICBsb25nQnJlYWtJbnB1dC5zZXRBdHRyaWJ1dGUoJ29uaW5wdXQnLCBcInZhbGlkaXR5LnZhbGlkfHwodmFsdWU9JycpO1wiKTtcclxuICAgICAgICAvLyBzZXBhcmF0ZSBkaXYgZm9yIGRhcmsgbW9kZSBzZXR0aW5nXHJcbiAgICAgICAgY29uc3QgZGFya01vZGVEaXYgPSB3cmFwcGVyLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpKTtcclxuICAgICAgICBkYXJrTW9kZURpdi5zZXRBdHRyaWJ1dGUoJ2lkJywgJ2RhcmstbW9kZScpO1xyXG4gICAgICAgIGNvbnN0IGRhcmtNb2RlVGl0bGUgPSBkYXJrTW9kZURpdi5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdoNCcpKTtcclxuICAgICAgICBkYXJrTW9kZVRpdGxlLnNldEF0dHJpYnV0ZSgnaWQnLCAnZW5hYmxlLWRhcmstbW9kZScpO1xyXG4gICAgICAgIGRhcmtNb2RlVGl0bGUuaW5uZXJIVE1MID0gJ0VuYWJsZSBEYXJrIE1vZGU/JztcclxuICAgICAgICBjb25zdCBtb2RlU3dpdGNoID0gZGFya01vZGVEaXYuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGFiZWwnKSk7XHJcbiAgICAgICAgbW9kZVN3aXRjaC5zZXRBdHRyaWJ1dGUoJ2NsYXNzJywgJ3N3aXRjaCcpO1xyXG4gICAgICAgIGNvbnN0IGNoZWNrYm94SW5wdXQgPSBtb2RlU3dpdGNoLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2lucHV0JykpO1xyXG4gICAgICAgIGNoZWNrYm94SW5wdXQuc2V0QXR0cmlidXRlKCd0eXBlJywgJ2NoZWNrYm94Jyk7XHJcbiAgICAgICAgaWYgKGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd0aGVtZScpID09PSAnZGFyaycpIHtcclxuICAgICAgICAgICAgY2hlY2tib3hJbnB1dC5jaGVja2VkID0gJ2NoZWNrZWQnO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBzbGlkZXIgPSBtb2RlU3dpdGNoLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKSk7XHJcbiAgICAgICAgc2xpZGVyLnNldEF0dHJpYnV0ZSgnY2xhc3MnLCAnc2xpZGVyJyk7XHJcbiAgICAgICAgLy8gYWRkIGV2ZW50IGxpc3RlbmVyIHRvIHRvZ2dsZSBkYXJrIG1vZGVcclxuICAgICAgICBzbGlkZXIuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCB0aGlzLnRvZ2dsZU1vZGUuYmluZCh0aGlzKSk7XHJcbiAgICAgICAgLy8gc2VwYXJhdGUgZGl2IGZvciB2b2x1bWVcclxuICAgICAgICBjb25zdCB2b2x1bWVEaXYgPSB3cmFwcGVyLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpKTtcclxuICAgICAgICB2b2x1bWVEaXYuc2V0QXR0cmlidXRlKCdpZCcsICd2b2x1bWUtZGl2Jyk7XHJcbiAgICAgICAgY29uc3Qgdm9sdW1lVGl0bGUgPSB2b2x1bWVEaXYuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaDQnKSk7XHJcbiAgICAgICAgdm9sdW1lVGl0bGUuc2V0QXR0cmlidXRlKCdpZCcsICdzb3VuZC12b2x1bWUnKTtcclxuICAgICAgICB2b2x1bWVUaXRsZS5pbm5lckhUTUwgPSAnQXVkaW8gVm9sdW1lJztcclxuICAgICAgICBjb25zdCB2b2xQID0gdm9sdW1lRGl2LmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3AnKSk7XHJcbiAgICAgICAgY29uc3Qgdm9sU3BhbiA9IHZvbFAuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpKTtcclxuICAgICAgICB2b2xTcGFuLnNldEF0dHJpYnV0ZSgnaWQnLCAndm9sdW1lLW51bWJlcicpO1xyXG4gICAgICAgIGNvbnN0IHNsaWRlckRpdiA9IHZvbHVtZURpdi5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKSk7XHJcbiAgICAgICAgc2xpZGVyRGl2LnNldEF0dHJpYnV0ZSgnY2xhc3MnLCAnc2xpZGVyLWRpdicpO1xyXG4gICAgICAgIGNvbnN0IHJhbmdlSW5wdXQgPSBzbGlkZXJEaXYuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaW5wdXQnKSk7XHJcbiAgICAgICAgcmFuZ2VJbnB1dC5zZXRBdHRyaWJ1dGUoJ3R5cGUnLCAncmFuZ2UnKTtcclxuICAgICAgICByYW5nZUlucHV0LnNldEF0dHJpYnV0ZSgnbWluJywgMCk7XHJcbiAgICAgICAgcmFuZ2VJbnB1dC5zZXRBdHRyaWJ1dGUoJ21heCcsIDEwMCk7XHJcbiAgICAgICAgcmFuZ2VJbnB1dC5zZXRBdHRyaWJ1dGUoJ3ZhbHVlJywgcGFyc2VJbnQobG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3ZvbHVtZScpLCAxMCkpO1xyXG4gICAgICAgIHJhbmdlSW5wdXQuc2V0QXR0cmlidXRlKCdjbGFzcycsICd2b2wtc2xpZGVyJyk7XHJcbiAgICAgICAgcmFuZ2VJbnB1dC5zZXRBdHRyaWJ1dGUoJ2lkJywgJ3JhbmdlJyk7XHJcbiAgICAgICAgLy8gYXBwZW5kIGNvbmZpcm0gYnRuIGluIGZvb3RlclxyXG4gICAgICAgIGNvbnN0IGZvb3RlciA9IHdyYXBwZXIuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JykpO1xyXG4gICAgICAgIGZvb3Rlci5zZXRBdHRyaWJ1dGUoJ2NsYXNzJywgJ2J1dHRvbi1mb290ZXInKTtcclxuICAgICAgICBjb25zdCBjb25maXJtQnRuID0gZm9vdGVyLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpKTtcclxuICAgICAgICBjb25maXJtQnRuLnNldEF0dHJpYnV0ZSgnY2xhc3MnLCAnc2V0dGluZ3MtcG9wdXAtYnRucycpO1xyXG4gICAgICAgIGNvbmZpcm1CdG4uc2V0QXR0cmlidXRlKCdpZCcsICdjb25maXJtLXNldHRpbmdzLWJ0bicpO1xyXG4gICAgICAgIGNvbmZpcm1CdG4uaW5uZXJIVE1MID0gJ0NvbmZpcm0nO1xyXG4gICAgICAgIC8vIGV2ZW50IGxpc3RlbmVycyBmb3IgY29uZmlybSBidG4gYW5kIGNsb3NlIGljb25cclxuICAgICAgICBjb25maXJtQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgdGhpcy5jb25maXJtU2V0dGluZ3MuYmluZCh0aGlzKSk7XHJcbiAgICAgICAgY2xvc2UuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCB0aGlzLmNsb3NlUG9wVXAuYmluZCh0aGlzKSk7XHJcbiAgICAgICAgLy8gZXZlbnQgbGlzdGVuZXIgdG8gc2V0IHZvbHVtZSBpbiBsb2NhbCBzdG9yYWdlXHJcbiAgICAgICAgcmFuZ2VJbnB1dC5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCB0aGlzLnNldFZvbHVtZS5iaW5kKHRoaXMpKTtcclxuICAgICAgICB2b2xTcGFuLmlubmVySFRNTCA9IHJhbmdlSW5wdXQudmFsdWU7XHJcbiAgICAgICAgLy8gZXZlbnQgbGlzdGVuZXIgdG8gZHluYW1pY2FsbHkgZGlzcGxheSB2b2x1bWVcclxuICAgICAgICByYW5nZUlucHV0LmFkZEV2ZW50TGlzdGVuZXIoJ2lucHV0JywgZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICB2b2xTcGFuLmlubmVySFRNTCA9IHRoaXMudmFsdWU7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgLy8gdXNlIDo6cGFydCBwc2V1ZG8tZWxlbWVudCB0byBzdHlsZSBlbGVtZW50IG91dHNpZGUgb2Ygc2hhZG93IHRyZWUgLS0gZm9yIGRhcmsgbW9kZVxyXG4gICAgICAgIHdyYXBwZXIuc2V0QXR0cmlidXRlKCdwYXJ0JywgJ3NldHRpbmdzLWNvbmZpcm0tcG9wdXAnKTtcclxuICAgICAgICBjbG9zZS5zZXRBdHRyaWJ1dGUoJ3BhcnQnLCAnY2xvc2UtaWNvbicpO1xyXG4gICAgICAgIHRpdGxlLnNldEF0dHJpYnV0ZSgncGFydCcsICdzZXR0aW5ncy1oMycpO1xyXG4gICAgICAgIHNlc3Npb25UaXRsZS5zZXRBdHRyaWJ1dGUoJ3BhcnQnLCAndGltZXItc2V0dGluZ3MnKTtcclxuICAgICAgICBwb21vTGFiZWwuc2V0QXR0cmlidXRlKCdwYXJ0JywgJ3Nlc3Npb24tbGFiZWxzJyk7XHJcbiAgICAgICAgcG9tb0lucHV0LnNldEF0dHJpYnV0ZSgncGFydCcsICdsZW5ndGgtaW5wdXRzJyk7XHJcbiAgICAgICAgc2hvcnRCcmVha0xhYmVsLnNldEF0dHJpYnV0ZSgncGFydCcsICdzZXNzaW9uLWxhYmVscycpO1xyXG4gICAgICAgIHNob3J0QnJlYWtJbnB1dC5zZXRBdHRyaWJ1dGUoJ3BhcnQnLCAnbGVuZ3RoLWlucHV0cycpO1xyXG4gICAgICAgIGxvbmdCcmVha0xhYmVsLnNldEF0dHJpYnV0ZSgncGFydCcsICdzZXNzaW9uLWxhYmVscycpO1xyXG4gICAgICAgIGxvbmdCcmVha0lucHV0LnNldEF0dHJpYnV0ZSgncGFydCcsICdsZW5ndGgtaW5wdXRzJyk7XHJcbiAgICAgICAgZGFya01vZGVUaXRsZS5zZXRBdHRyaWJ1dGUoJ3BhcnQnLCAnZW5hYmxlLWRhcmstbW9kZScpO1xyXG4gICAgICAgIHZvbHVtZVRpdGxlLnNldEF0dHJpYnV0ZSgncGFydCcsICdzb3VuZC12b2x1bWUnKTtcclxuICAgICAgICB2b2xTcGFuLnNldEF0dHJpYnV0ZSgncGFydCcsICd2b2x1bWUtbnVtYmVyJyk7XHJcbiAgICAgICAgcmFuZ2VJbnB1dC5zZXRBdHRyaWJ1dGUoJ3BhcnQnLCAncmFuZ2Utc2xpZGVyJyk7XHJcbiAgICAgICAgZm9vdGVyLnNldEF0dHJpYnV0ZSgncGFydCcsICdidG4tZm9vdGVyJyk7XHJcbiAgICAgICAgY29uZmlybUJ0bi5zZXRBdHRyaWJ1dGUoJ3BhcnQnLCAnY29uZmlybS1idG4nKTtcclxuICAgICAgICBjb25zdCBzdHlsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0eWxlJyk7XHJcbiAgICAgICAgc3R5bGUudGV4dENvbnRlbnQgPSBgXHJcbiAgICAgICAgaDQge1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxLjE1dnc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHAge1xyXG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICN2b2x1bWUtbnVtYmVyIHtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMS4wOTM3NXZ3O1xyXG4gICAgICAgICAgICAgICAgZm9udC1mYW1pbHk6IEFyaWFsO1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IHJnYig4NSwgODUsIDg1KTtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxLjU2MjV2dztcclxuICAgICAgICB9XHJcbiAgICAgICAgLnZvbC1zbGlkZXIge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2NjYztcclxuICAgICAgICAgICAgICAgIC13ZWJraXQtYXBwZWFyYW5jZTogbm9uZTtcclxuICAgICAgICAgICAgICAgIGFwcGVhcmFuY2U6IG5vbmU7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAzLjkwNjI1dnc7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDAuNTQ2ODc1dnc7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAuMzkwNjI1dnc7XHJcbiAgICAgICAgICAgICAgICBvdXRsaW5lOiBub25lO1xyXG4gICAgICAgICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICAgICAgICAgICAgb3BhY2l0eTogMC43O1xyXG4gICAgICAgICAgICAgICAgLXdlYmtpdC10cmFuc2l0aW9uOiAuMXM7XHJcbiAgICAgICAgICAgICAgICB0cmFuc2l0aW9uOiBvcGFjaXR5IC4xcztcclxuICAgICAgICB9XHJcbiAgICAgICAgLnZvbC1zbGlkZXI6aG92ZXIge1xyXG4gICAgICAgICAgICAgICAgb3BhY2l0eTogMTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLnZvbC1zbGlkZXI6Oi13ZWJraXQtc2xpZGVyLXRodW1iIHtcclxuICAgICAgICAgICAgICAgIC13ZWJraXQtYXBwZWFyYW5jZTogbm9uZTtcclxuICAgICAgICAgICAgICAgIGFwcGVhcmFuY2U6IG5vbmU7XHJcbiAgICAgICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMS41NjI1dnc7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDEuNTYyNXZ3O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI2U2ZTVlNTtcclxuICAgICAgICAgICAgICAgIGJveC1zaGFkb3c6IDAgMCAzcHggMXB4IHJnYmEoMCwwLDAsMC4yKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLnZvbC1zbGlkZXI6Oi1tb3otcmFuZ2UtdGh1bWIge1xyXG4gICAgICAgICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDEuNTYyNXZ3O1xyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAxLjU2MjV2dztcclxuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6ICNlNmU1ZTU7XHJcbiAgICAgICAgICAgICAgICBib3gtc2hhZG93OiAwIDAgM3B4IDFweCByZ2JhKDAsMCwwLDAuMik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICN2b2x1bWUtZGl2IHtcclxuICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogODUlO1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luOiAxLjU2MjV2dyBhdXRvIDAuNzgxMjV2dyBhdXRvO1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDEuNTYyNXZ3O1xyXG4gICAgICAgIH1cclxuICAgICAgICAuc2xpZGVyLWRpdiB7XHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcclxuICAgICAgICAgICAgICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgIH1cclxuICAgICAgICAjc291bmQtdm9sdW1lIHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiByZ2IoODUsIDg1LCA4NSk7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICNlbmFibGUtZGFyay1tb2RlIHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiByZ2IoODUsIDg1LCA4NSk7XHJcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICNkYXJrLW1vZGUge1xyXG4gICAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiA4NSU7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IDEuNTYyNXZ3IGF1dG8gMC43ODEyNXZ3IGF1dG87XHJcbiAgICAgICAgICAgICAgICBib3JkZXItYm90dG9tOiBzb2xpZCAxcHggI2QyZDJkMjtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOiAxLjU2MjV2dztcclxuICAgICAgICB9XHJcbiAgICAgICAgLnN3aXRjaCB7XHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiA0LjY4NzV2dztcclxuICAgICAgICAgICAgICAgIGhlaWdodDogMi42NTYyNXZ3O1xyXG4gICAgICAgIH1cclxuICAgICAgICAuc3dpdGNoIGlucHV0W3R5cGU9J2NoZWNrYm94J10geyBcclxuICAgICAgICAgICAgICAgIG9wYWNpdHk6IDA7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMDtcclxuICAgICAgICAgICAgICAgIGhlaWdodDogMDtcclxuICAgICAgICB9XHJcbiAgICAgICAgLnNsaWRlciB7XHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgICAgICAgICB0b3A6IDA7XHJcbiAgICAgICAgICAgICAgICBsZWZ0OiAwO1xyXG4gICAgICAgICAgICAgICAgcmlnaHQ6IDA7XHJcbiAgICAgICAgICAgICAgICBib3R0b206IDA7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjY2NjO1xyXG4gICAgICAgICAgICAgICAgLXdlYmtpdC10cmFuc2l0aW9uOiAuNHM7XHJcbiAgICAgICAgICAgICAgICB0cmFuc2l0aW9uOiAuNHM7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAyLjY1NjI1dnc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5zbGlkZXI6YmVmb3JlIHtcclxuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICAgICAgICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDIuMDMxMjV2dztcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAyLjAzMTI1dnc7XHJcbiAgICAgICAgICAgICAgICBsZWZ0OiAwLjMxMjV2dztcclxuICAgICAgICAgICAgICAgIGJvdHRvbTogMC4zMTI1dnc7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgICAgICAgICAgICAgIC13ZWJraXQtdHJhbnNpdGlvbjogMC4ycztcclxuICAgICAgICAgICAgICAgIHRyYW5zaXRpb246IDAuMnM7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlucHV0W3R5cGU9J2NoZWNrYm94J106Y2hlY2tlZCArIC5zbGlkZXIge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDE2MyAyNDMgNjcgLyA4OCUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpbnB1dFt0eXBlPSdjaGVja2JveCddOmNoZWNrZWQgKyAuc2xpZGVyOmJlZm9yZSB7XHJcbiAgICAgICAgICAgICAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWCgyLjAzMTI1dncpO1xyXG4gICAgICAgICAgICAgICAgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlWCgyLjAzMTI1dncpO1xyXG4gICAgICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKDIuMDMxMjV2dyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICNzZXNzaW9uIHtcclxuICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogODUlO1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luOiAwLjc4MTI1dncgYXV0byAwLjc4MTI1dncgYXV0bztcclxuICAgICAgICAgICAgICAgIGJvcmRlci1ib3R0b206IHNvbGlkIDFweCAjZDJkMmQyO1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDEuNTYyNXZ3O1xyXG4gICAgICAgIH1cclxuICAgICAgICBsYWJlbCB7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMC45Mzc1dnc7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogcmdiKDg1LCA4NSwgODUpO1xyXG4gICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICB9XHJcbiAgICAgICAgaW5wdXRbdHlwZT0nbnVtYmVyJ10ge1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxLjA5Mzc1dnc7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogcmdiKDg1LCA4NSwgODUpO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyOiBub25lO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMC4zMTI1dnc7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjM0IDIzNCAyMzQpO1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZzogMC43ODEyNXZ3O1xyXG4gICAgICAgICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgb3V0bGluZTogbm9uZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLmJ1dHRvbi1mb290ZXIge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDIzNCAyMzQgMjM0KTtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDEuMDkzNzV2dyAxLjU2MjV2dztcclxuICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgICAgICAgICAgYm90dG9tOiAwO1xyXG4gICAgICAgICAgICAgICAgcmlnaHQ6IDA7XHJcbiAgICAgICAgICAgICAgICBsZWZ0OiAwO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMC4zMTI1dnc7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMC4zMTI1dnc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICN0aW1lci1zZXR0aW5ncyB7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogcmdiKDg1LCA4NSwgODUpO1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDg1JTtcclxuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IDEuNTYyNXZ3IGF1dG8gMC43ODEyNXZ3IGF1dG87XHJcbiAgICAgICAgfVxyXG4gICAgICAgICNjbG9zZS1pY29uIHtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAxLjE3MTg3NXZ3O1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMC43ODEyNXZ3O1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAwLjc4MTI1dnc7XHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjphYnNvbHV0ZTtcclxuICAgICAgICAgICAgICAgIHRvcDowO1xyXG4gICAgICAgICAgICAgICAgcmlnaHQ6MDtcclxuICAgICAgICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgICAgICAgICAgIG9wYWNpdHk6IDAuMzM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICNjbG9zZS1pY29uOmhvdmVyIHtcclxuICAgICAgICAgICAgICAgIG9wYWNpdHk6IDE7XHJcbiAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEuMSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICNzZXR0aW5ncy1jb25maXJtLXBvcHVwIHtcclxuICAgICAgICAgICAgICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMjkuMjk2ODc1dnc7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDMwLjQ2ODc1dnc7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAwLjMxMjV2dztcclxuICAgICAgICAgICAgICAgIHRvcDoyMCU7XHJcbiAgICAgICAgICAgICAgICBsZWZ0OiAzNCU7XHJcbiAgICAgICAgICAgICAgICB6LWluZGV4OiA5OTk7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZXNtb2tlO1xyXG4gICAgICAgICAgICAgICAgYm94LXNoYWRvdzogMCA0cHggOHB4IDAgcmdiYSgwLDAsMCwwLjIpLDAgNnB4IDIwcHggMCByZ2JhKDAsMCwwLDAuMTkpO1xyXG4gICAgICAgICAgICAgICAgLXdlYmtpdC1hbmltYXRpb24tbmFtZTogYW5pbWF0ZXRvcDsgXHJcbiAgICAgICAgICAgICAgICAtd2Via2l0LWFuaW1hdGlvbi1kdXJhdGlvbjogMC4zcztcclxuICAgICAgICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBhbmltYXRldG9wO1xyXG4gICAgICAgICAgICAgICAgYW5pbWF0aW9uLWR1cmF0aW9uOiAwLjNzXHJcbiAgICAgICAgfVxyXG4gICAgICAgIEAtd2Via2l0LWtleWZyYW1lcyBhbmltYXRldG9wIHtcclxuICAgICAgICAgICAgICAgIGZyb20ge3RvcDotMjAwcHg7IG9wYWNpdHk6MH0gXHJcbiAgICAgICAgICAgICAgICB0byB7dG9wOjcwOyBvcGFjaXR5OjF9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIEBrZXlmcmFtZXMgYW5pbWF0ZXRvcCB7XHJcbiAgICAgICAgICAgICAgICBmcm9tIHt0b3A6LTIwMHB4OyBvcGFjaXR5OjB9XHJcbiAgICAgICAgICAgICAgICB0byB7dG9wOjcwOyBvcGFjaXR5OjF9XHJcbiAgICAgICAgfVxyXG4gICAgICAgICNzZXR0aW5ncy1jb25maXJtLXBvcHVwID4gaDMge1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxLjZ2dztcclxuICAgICAgICAgICAgICAgIGNvbG9yOiAjZjM2MDYwO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogc29saWQgMXB4ICNkMmQyZDI7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nLWJvdHRvbTogMC4zOTA2MjV2dztcclxuICAgICAgICAgICAgICAgIHdpZHRoOiA4NSU7XHJcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luOiAxLjU2MjV2dyBhdXRvIDAuNzgxMjV2dyBhdXRvO1xyXG4gICAgICAgIH1cclxuICAgICAgICAuc2V0dGluZ3MtcG9wdXAtYnRucyB7XHJcbiAgICAgICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItc3R5bGU6IG5vbmU7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAwLjMxMjV2dztcclxuICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6I2YzNjA2MDtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiNmZmY7XHJcbiAgICAgICAgICAgICAgICBmb250LWZhbWlseTogJ1F1aWNrc2FuZCcsIHNhbnMtc2VyaWY7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDE3JTtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAyNyU7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEuMjV2dztcclxuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgICAgICAgICBvdXRsaW5lOiBub25lO1xyXG4gICAgICAgIH1cclxuICAgICAgICAuc2V0dGluZ3MtcG9wdXAtYnRuczpob3ZlciB7XHJcbiAgICAgICAgICAgICAgICBmaWx0ZXI6IGJyaWdodG5lc3MoMTA1JSk7XHJcbiAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEuMSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICNjb25maXJtLXNldHRpbmdzLWJ0biB7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwLjYyNXZ3IDAuOTM3NXZ3O1xyXG4gICAgICAgIH1gO1xyXG4gICAgICAgIHNoYWRvdy5hcHBlbmRDaGlsZCh3cmFwcGVyKTtcclxuICAgICAgICBzaGFkb3cuYXBwZW5kQ2hpbGQoc3R5bGUpO1xyXG4gICAgfVxyXG59XHJcbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgnc2V0dGluZ3MtcG9wdXAnLCBTZXR0aW5nc1BvcFVwKTtcclxuXHJcbndpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdsb2FkJywgKCkgPT4ge1xyXG4gICAgY29uc3Qgc2V0dGluZ3NCdXR0b24gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc2V0dGluZy1idXR0b24nKTtcclxuICAgIGNvbnN0IHNldHRpbmdzUG9wVXAgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzZXR0aW5ncy1wb3B1cCcpO1xyXG4gICAgc2V0dGluZ3NQb3BVcC5zZXRBdHRyaWJ1dGUoJ2NsYXNzJywgJ3BvcHVwJyk7XHJcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHNldHRpbmdzUG9wVXApO1xyXG4gICAgc2V0dGluZ3NCdXR0b24uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgYnRuU291bmQgPSBuZXcgQXVkaW8oJy4vaWNvbnMvYnRuQ2xpY2subXAzJyk7XHJcbiAgICAgICAgYnRuU291bmQudm9sdW1lID0gMC4wMSAqIHBhcnNlSW50KGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd2b2x1bWUnKSwgMTApO1xyXG4gICAgICAgIGJ0blNvdW5kLnBsYXkoKTtcclxuICAgICAgICAvLyBtYWtlIHN1cmUgYWxsIHBvcHVwcyBhcmUgY2xvc2VkIGJlZm9yZSBvcGVuaW5nIGFub3RoZXIgb25lXHJcbiAgICAgICAgY29uc3QgcG9wdXBzID0gQXJyYXkuZnJvbShkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKCdwb3B1cCcpKTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHBvcHVwcy5sZW5ndGg7IGkgKz0gMSkge1xyXG4gICAgICAgICAgICBwb3B1cHNbaV0uY2xvc2VQb3BVcCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBzZXR0aW5nc1BvcFVwLnNoYWRvd1Jvb3QuZ2V0RWxlbWVudEJ5SWQoJ3NldHRpbmdzLWNvbmZpcm0tcG9wdXAnKS5zZXRBdHRyaWJ1dGUoJ3N0eWxlJywgJ2Rpc3BsYXk6YmxvY2snKTtcclxuICAgIH0pO1xyXG59KTtcclxuXHJcbi8vIG1vZHVsZS5leHBvcnRzID0gU2V0dGluZ3NQb3BVcDtcclxuIl19
function cov_wqxgpcwj7() {
  var path = "D:\\\u5B66\u4E60\\21WI\\CSE110\\cse110-w21-group13\\source\\src\\components\\HelpPopUp.js";
  var hash = "cddd387a1529e64b59143d4efd92685d49286eba";
  var global = new Function("return this")();
  var gcv = "__coverage__";
  var coverageData = {
    path: "D:\\\u5B66\u4E60\\21WI\\CSE110\\cse110-w21-group13\\source\\src\\components\\HelpPopUp.js",
    statementMap: {
      "0": {
        start: {
          line: 3,
          column: 24
        },
        end: {
          line: 3,
          column: 68
        }
      },
      "1": {
        start: {
          line: 4,
          column: 8
        },
        end: {
          line: 4,
          column: 39
        }
      },
      "2": {
        start: {
          line: 8,
          column: 8
        },
        end: {
          line: 8,
          column: 16
        }
      },
      "3": {
        start: {
          line: 9,
          column: 23
        },
        end: {
          line: 9,
          column: 58
        }
      },
      "4": {
        start: {
          line: 10,
          column: 24
        },
        end: {
          line: 10,
          column: 53
        }
      },
      "5": {
        start: {
          line: 11,
          column: 8
        },
        end: {
          line: 11,
          column: 49
        }
      },
      "6": {
        start: {
          line: 12,
          column: 22
        },
        end: {
          line: 12,
          column: 72
        }
      },
      "7": {
        start: {
          line: 13,
          column: 8
        },
        end: {
          line: 13,
          column: 53
        }
      },
      "8": {
        start: {
          line: 14,
          column: 8
        },
        end: {
          line: 14,
          column: 47
        }
      },
      "9": {
        start: {
          line: 15,
          column: 22
        },
        end: {
          line: 15,
          column: 71
        }
      },
      "10": {
        start: {
          line: 16,
          column: 8
        },
        end: {
          line: 16,
          column: 33
        }
      },
      "11": {
        start: {
          line: 17,
          column: 8
        },
        end: {
          line: 17,
          column: 68
        }
      },
      "12": {
        start: {
          line: 18,
          column: 30
        },
        end: {
          line: 18,
          column: 80
        }
      },
      "13": {
        start: {
          line: 19,
          column: 8
        },
        end: {
          line: 19,
          column: 59
        }
      },
      "14": {
        start: {
          line: 20,
          column: 32
        },
        end: {
          line: 20,
          column: 88
        }
      },
      "15": {
        start: {
          line: 21,
          column: 8
        },
        end: {
          line: 21,
          column: 53
        }
      },
      "16": {
        start: {
          line: 22,
          column: 22
        },
        end: {
          line: 22,
          column: 79
        }
      },
      "17": {
        start: {
          line: 23,
          column: 8
        },
        end: {
          line: 23,
          column: 58
        }
      },
      "18": {
        start: {
          line: 24,
          column: 29
        },
        end: {
          line: 24,
          column: 86
        }
      },
      "19": {
        start: {
          line: 25,
          column: 8
        },
        end: {
          line: 25,
          column: 58
        }
      },
      "20": {
        start: {
          line: 26,
          column: 22
        },
        end: {
          line: 26,
          column: 76
        }
      },
      "21": {
        start: {
          line: 27,
          column: 8
        },
        end: {
          line: 27,
          column: 59
        }
      },
      "22": {
        start: {
          line: 28,
          column: 22
        },
        end: {
          line: 28,
          column: 76
        }
      },
      "23": {
        start: {
          line: 29,
          column: 8
        },
        end: {
          line: 29,
          column: 103
        }
      },
      "24": {
        start: {
          line: 30,
          column: 22
        },
        end: {
          line: 30,
          column: 76
        }
      },
      "25": {
        start: {
          line: 31,
          column: 8
        },
        end: {
          line: 31,
          column: 86
        }
      },
      "26": {
        start: {
          line: 32,
          column: 22
        },
        end: {
          line: 32,
          column: 76
        }
      },
      "27": {
        start: {
          line: 33,
          column: 8
        },
        end: {
          line: 33,
          column: 63
        }
      },
      "28": {
        start: {
          line: 34,
          column: 22
        },
        end: {
          line: 34,
          column: 76
        }
      },
      "29": {
        start: {
          line: 35,
          column: 8
        },
        end: {
          line: 35,
          column: 62
        }
      },
      "30": {
        start: {
          line: 36,
          column: 22
        },
        end: {
          line: 36,
          column: 76
        }
      },
      "31": {
        start: {
          line: 37,
          column: 8
        },
        end: {
          line: 37,
          column: 61
        }
      },
      "32": {
        start: {
          line: 39,
          column: 28
        },
        end: {
          line: 39,
          column: 84
        }
      },
      "33": {
        start: {
          line: 40,
          column: 8
        },
        end: {
          line: 40,
          column: 51
        }
      },
      "34": {
        start: {
          line: 41,
          column: 30
        },
        end: {
          line: 41,
          column: 83
        }
      },
      "35": {
        start: {
          line: 42,
          column: 8
        },
        end: {
          line: 42,
          column: 45
        }
      },
      "36": {
        start: {
          line: 43,
          column: 32
        },
        end: {
          line: 43,
          column: 85
        }
      },
      "37": {
        start: {
          line: 44,
          column: 8
        },
        end: {
          line: 44,
          column: 63
        }
      },
      "38": {
        start: {
          line: 45,
          column: 25
        },
        end: {
          line: 45,
          column: 82
        }
      },
      "39": {
        start: {
          line: 46,
          column: 8
        },
        end: {
          line: 46,
          column: 76
        }
      },
      "40": {
        start: {
          line: 47,
          column: 25
        },
        end: {
          line: 47,
          column: 82
        }
      },
      "41": {
        start: {
          line: 48,
          column: 8
        },
        end: {
          line: 48,
          column: 79
        }
      },
      "42": {
        start: {
          line: 49,
          column: 25
        },
        end: {
          line: 49,
          column: 82
        }
      },
      "43": {
        start: {
          line: 50,
          column: 8
        },
        end: {
          line: 50,
          column: 73
        }
      },
      "44": {
        start: {
          line: 51,
          column: 25
        },
        end: {
          line: 51,
          column: 82
        }
      },
      "45": {
        start: {
          line: 52,
          column: 8
        },
        end: {
          line: 52,
          column: 85
        }
      },
      "46": {
        start: {
          line: 53,
          column: 25
        },
        end: {
          line: 53,
          column: 82
        }
      },
      "47": {
        start: {
          line: 54,
          column: 8
        },
        end: {
          line: 54,
          column: 117
        }
      },
      "48": {
        start: {
          line: 56,
          column: 33
        },
        end: {
          line: 56,
          column: 89
        }
      },
      "49": {
        start: {
          line: 57,
          column: 8
        },
        end: {
          line: 57,
          column: 61
        }
      },
      "50": {
        start: {
          line: 58,
          column: 35
        },
        end: {
          line: 58,
          column: 93
        }
      },
      "51": {
        start: {
          line: 59,
          column: 8
        },
        end: {
          line: 59,
          column: 60
        }
      },
      "52": {
        start: {
          line: 60,
          column: 37
        },
        end: {
          line: 60,
          column: 95
        }
      },
      "53": {
        start: {
          line: 61,
          column: 8
        },
        end: {
          line: 61,
          column: 73
        }
      },
      "54": {
        start: {
          line: 62,
          column: 26
        },
        end: {
          line: 62,
          column: 88
        }
      },
      "55": {
        start: {
          line: 63,
          column: 8
        },
        end: {
          line: 63,
          column: 55
        }
      },
      "56": {
        start: {
          line: 64,
          column: 26
        },
        end: {
          line: 64,
          column: 88
        }
      },
      "57": {
        start: {
          line: 65,
          column: 8
        },
        end: {
          line: 65,
          column: 54
        }
      },
      "58": {
        start: {
          line: 66,
          column: 26
        },
        end: {
          line: 66,
          column: 88
        }
      },
      "59": {
        start: {
          line: 67,
          column: 8
        },
        end: {
          line: 67,
          column: 51
        }
      },
      "60": {
        start: {
          line: 68,
          column: 26
        },
        end: {
          line: 68,
          column: 88
        }
      },
      "61": {
        start: {
          line: 69,
          column: 8
        },
        end: {
          line: 69,
          column: 49
        }
      },
      "62": {
        start: {
          line: 70,
          column: 26
        },
        end: {
          line: 70,
          column: 88
        }
      },
      "63": {
        start: {
          line: 71,
          column: 8
        },
        end: {
          line: 71,
          column: 49
        }
      },
      "64": {
        start: {
          line: 72,
          column: 26
        },
        end: {
          line: 72,
          column: 88
        }
      },
      "65": {
        start: {
          line: 73,
          column: 8
        },
        end: {
          line: 73,
          column: 47
        }
      },
      "66": {
        start: {
          line: 74,
          column: 26
        },
        end: {
          line: 74,
          column: 88
        }
      },
      "67": {
        start: {
          line: 75,
          column: 8
        },
        end: {
          line: 75,
          column: 54
        }
      },
      "68": {
        start: {
          line: 76,
          column: 26
        },
        end: {
          line: 76,
          column: 88
        }
      },
      "69": {
        start: {
          line: 77,
          column: 8
        },
        end: {
          line: 77,
          column: 53
        }
      },
      "70": {
        start: {
          line: 80,
          column: 8
        },
        end: {
          line: 80,
          column: 54
        }
      },
      "71": {
        start: {
          line: 81,
          column: 8
        },
        end: {
          line: 81,
          column: 49
        }
      },
      "72": {
        start: {
          line: 82,
          column: 8
        },
        end: {
          line: 82,
          column: 46
        }
      },
      "73": {
        start: {
          line: 83,
          column: 8
        },
        end: {
          line: 83,
          column: 61
        }
      },
      "74": {
        start: {
          line: 84,
          column: 8
        },
        end: {
          line: 84,
          column: 53
        }
      },
      "75": {
        start: {
          line: 85,
          column: 8
        },
        end: {
          line: 85,
          column: 63
        }
      },
      "76": {
        start: {
          line: 86,
          column: 8
        },
        end: {
          line: 86,
          column: 41
        }
      },
      "77": {
        start: {
          line: 87,
          column: 8
        },
        end: {
          line: 87,
          column: 49
        }
      },
      "78": {
        start: {
          line: 88,
          column: 8
        },
        end: {
          line: 88,
          column: 54
        }
      },
      "79": {
        start: {
          line: 91,
          column: 22
        },
        end: {
          line: 91,
          column: 53
        }
      },
      "80": {
        start: {
          line: 92,
          column: 8
        },
        end: {
          line: 197,
          column: 11
        }
      },
      "81": {
        start: {
          line: 198,
          column: 8
        },
        end: {
          line: 198,
          column: 36
        }
      },
      "82": {
        start: {
          line: 199,
          column: 8
        },
        end: {
          line: 199,
          column: 34
        }
      },
      "83": {
        start: {
          line: 202,
          column: 0
        },
        end: {
          line: 202,
          column: 47
        }
      },
      "84": {
        start: {
          line: 204,
          column: 0
        },
        end: {
          line: 220,
          column: 3
        }
      },
      "85": {
        start: {
          line: 205,
          column: 22
        },
        end: {
          line: 205,
          column: 58
        }
      },
      "86": {
        start: {
          line: 206,
          column: 4
        },
        end: {
          line: 206,
          column: 45
        }
      },
      "87": {
        start: {
          line: 207,
          column: 4
        },
        end: {
          line: 207,
          column: 41
        }
      },
      "88": {
        start: {
          line: 208,
          column: 20
        },
        end: {
          line: 208,
          column: 58
        }
      },
      "89": {
        start: {
          line: 209,
          column: 4
        },
        end: {
          line: 219,
          column: 7
        }
      },
      "90": {
        start: {
          line: 210,
          column: 25
        },
        end: {
          line: 210,
          column: 58
        }
      },
      "91": {
        start: {
          line: 211,
          column: 8
        },
        end: {
          line: 211,
          column: 78
        }
      },
      "92": {
        start: {
          line: 212,
          column: 8
        },
        end: {
          line: 212,
          column: 24
        }
      },
      "93": {
        start: {
          line: 214,
          column: 23
        },
        end: {
          line: 214,
          column: 75
        }
      },
      "94": {
        start: {
          line: 215,
          column: 8
        },
        end: {
          line: 217,
          column: 9
        }
      },
      "95": {
        start: {
          line: 215,
          column: 21
        },
        end: {
          line: 215,
          column: 22
        }
      },
      "96": {
        start: {
          line: 216,
          column: 12
        },
        end: {
          line: 216,
          column: 35
        }
      },
      "97": {
        start: {
          line: 218,
          column: 8
        },
        end: {
          line: 218,
          column: 97
        }
      }
    },
    fnMap: {
      "0": {
        name: "(anonymous_0)",
        decl: {
          start: {
            line: 2,
            column: 4
          },
          end: {
            line: 2,
            column: 5
          }
        },
        loc: {
          start: {
            line: 2,
            column: 17
          },
          end: {
            line: 5,
            column: 5
          }
        },
        line: 2
      },
      "1": {
        name: "(anonymous_1)",
        decl: {
          start: {
            line: 7,
            column: 4
          },
          end: {
            line: 7,
            column: 5
          }
        },
        loc: {
          start: {
            line: 7,
            column: 18
          },
          end: {
            line: 200,
            column: 5
          }
        },
        line: 7
      },
      "2": {
        name: "(anonymous_2)",
        decl: {
          start: {
            line: 204,
            column: 32
          },
          end: {
            line: 204,
            column: 33
          }
        },
        loc: {
          start: {
            line: 204,
            column: 38
          },
          end: {
            line: 220,
            column: 1
          }
        },
        line: 204
      },
      "3": {
        name: "(anonymous_3)",
        decl: {
          start: {
            line: 209,
            column: 38
          },
          end: {
            line: 209,
            column: 39
          }
        },
        loc: {
          start: {
            line: 209,
            column: 44
          },
          end: {
            line: 219,
            column: 5
          }
        },
        line: 209
      }
    },
    branchMap: {},
    s: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0,
      "11": 0,
      "12": 0,
      "13": 0,
      "14": 0,
      "15": 0,
      "16": 0,
      "17": 0,
      "18": 0,
      "19": 0,
      "20": 0,
      "21": 0,
      "22": 0,
      "23": 0,
      "24": 0,
      "25": 0,
      "26": 0,
      "27": 0,
      "28": 0,
      "29": 0,
      "30": 0,
      "31": 0,
      "32": 0,
      "33": 0,
      "34": 0,
      "35": 0,
      "36": 0,
      "37": 0,
      "38": 0,
      "39": 0,
      "40": 0,
      "41": 0,
      "42": 0,
      "43": 0,
      "44": 0,
      "45": 0,
      "46": 0,
      "47": 0,
      "48": 0,
      "49": 0,
      "50": 0,
      "51": 0,
      "52": 0,
      "53": 0,
      "54": 0,
      "55": 0,
      "56": 0,
      "57": 0,
      "58": 0,
      "59": 0,
      "60": 0,
      "61": 0,
      "62": 0,
      "63": 0,
      "64": 0,
      "65": 0,
      "66": 0,
      "67": 0,
      "68": 0,
      "69": 0,
      "70": 0,
      "71": 0,
      "72": 0,
      "73": 0,
      "74": 0,
      "75": 0,
      "76": 0,
      "77": 0,
      "78": 0,
      "79": 0,
      "80": 0,
      "81": 0,
      "82": 0,
      "83": 0,
      "84": 0,
      "85": 0,
      "86": 0,
      "87": 0,
      "88": 0,
      "89": 0,
      "90": 0,
      "91": 0,
      "92": 0,
      "93": 0,
      "94": 0,
      "95": 0,
      "96": 0,
      "97": 0
    },
    f: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0
    },
    b: {},
    _coverageSchema: "1a1c01bbd47fc00a2c39e90264f33305004495a9",
    hash: "cddd387a1529e64b59143d4efd92685d49286eba"
  };
  var coverage = global[gcv] || (global[gcv] = {});

  if (!coverage[path] || coverage[path].hash !== hash) {
    coverage[path] = coverageData;
  }

  var actualCoverage = coverage[path];
  {
    // @ts-ignore
    cov_wqxgpcwj7 = function () {
      return actualCoverage;
    };
  }
  return actualCoverage;
}

cov_wqxgpcwj7();

class HelpPopUp extends HTMLElement {
  closePopUp() {
    cov_wqxgpcwj7().f[0]++;
    const wrapper = (cov_wqxgpcwj7().s[0]++, this.shadowRoot.getElementById('help-popup'));
    cov_wqxgpcwj7().s[1]++;
    wrapper.style.display = 'none';
  }

  constructor() {
    cov_wqxgpcwj7().f[1]++;
    cov_wqxgpcwj7().s[2]++;
    super();
    const shadow = (cov_wqxgpcwj7().s[3]++, this.attachShadow({
      mode: 'open'
    }));
    const wrapper = (cov_wqxgpcwj7().s[4]++, document.createElement('div'));
    cov_wqxgpcwj7().s[5]++;
    wrapper.setAttribute('id', 'help-popup');
    const close = (cov_wqxgpcwj7().s[6]++, wrapper.appendChild(document.createElement('img')));
    cov_wqxgpcwj7().s[7]++;
    close.setAttribute('src', 'icons/close.svg');
    cov_wqxgpcwj7().s[8]++;
    close.setAttribute('id', 'close-icon');
    const title = (cov_wqxgpcwj7().s[9]++, wrapper.appendChild(document.createElement('h3')));
    cov_wqxgpcwj7().s[10]++;
    title.innerHTML = 'Help';
    cov_wqxgpcwj7().s[11]++;
    close.addEventListener('click', this.closePopUp.bind(this));
    const helpContainer = (cov_wqxgpcwj7().s[12]++, wrapper.appendChild(document.createElement('div')));
    cov_wqxgpcwj7().s[13]++;
    helpContainer.setAttribute('id', 'help-container');
    const instructionsDiv = (cov_wqxgpcwj7().s[14]++, helpContainer.appendChild(document.createElement('div')));
    cov_wqxgpcwj7().s[15]++;
    instructionsDiv.setAttribute('id', 'how-to');
    const howTo = (cov_wqxgpcwj7().s[16]++, instructionsDiv.appendChild(document.createElement('h4')));
    cov_wqxgpcwj7().s[17]++;
    howTo.innerHTML = 'How to use the Pomodoro Timer';
    const howToContent = (cov_wqxgpcwj7().s[18]++, instructionsDiv.appendChild(document.createElement('ol')));
    cov_wqxgpcwj7().s[19]++;
    howToContent.setAttribute('id', 'how-to-content');
    const step1 = (cov_wqxgpcwj7().s[20]++, howToContent.appendChild(document.createElement('li')));
    cov_wqxgpcwj7().s[21]++;
    step1.innerHTML = "Add tasks using the '+' button";
    const step2 = (cov_wqxgpcwj7().s[22]++, howToContent.appendChild(document.createElement('li')));
    cov_wqxgpcwj7().s[23]++;
    step2.innerHTML = 'Set pomodoro and break lengths in the settings (or use the default values)';
    const step3 = (cov_wqxgpcwj7().s[24]++, howToContent.appendChild(document.createElement('li')));
    cov_wqxgpcwj7().s[25]++;
    step3.innerHTML = 'Select a task to focus on using the magnifying glass icon';
    const step4 = (cov_wqxgpcwj7().s[26]++, howToContent.appendChild(document.createElement('li')));
    cov_wqxgpcwj7().s[27]++;
    step4.innerHTML = 'Start the timer and be productive!';
    const step5 = (cov_wqxgpcwj7().s[28]++, howToContent.appendChild(document.createElement('li')));
    cov_wqxgpcwj7().s[29]++;
    step5.innerHTML = 'Take a break when the alarm rings';
    const step6 = (cov_wqxgpcwj7().s[30]++, howToContent.appendChild(document.createElement('li')));
    cov_wqxgpcwj7().s[31]++;
    step6.innerHTML = 'Repeat steps 3-5 to satisfaction';
    const featuresDiv = (cov_wqxgpcwj7().s[32]++, helpContainer.appendChild(document.createElement('div')));
    cov_wqxgpcwj7().s[33]++;
    featuresDiv.setAttribute('id', 'features');
    const featuresTitle = (cov_wqxgpcwj7().s[34]++, featuresDiv.appendChild(document.createElement('h4')));
    cov_wqxgpcwj7().s[35]++;
    featuresTitle.innerHTML = 'Features';
    const featuresContent = (cov_wqxgpcwj7().s[36]++, featuresDiv.appendChild(document.createElement('ul')));
    cov_wqxgpcwj7().s[37]++;
    featuresContent.setAttribute('id', 'features-content');
    const feature1 = (cov_wqxgpcwj7().s[38]++, featuresContent.appendChild(document.createElement('li')));
    cov_wqxgpcwj7().s[39]++;
    feature1.innerHTML = 'Dark mode theme for late night work sessions';
    const feature2 = (cov_wqxgpcwj7().s[40]++, featuresContent.appendChild(document.createElement('li')));
    cov_wqxgpcwj7().s[41]++;
    feature2.innerHTML = 'Audio notifications at end of pomodoro sessions';
    const feature3 = (cov_wqxgpcwj7().s[42]++, featuresContent.appendChild(document.createElement('li')));
    cov_wqxgpcwj7().s[43]++;
    feature3.innerHTML = 'Customizable pomodoro and break intervals';
    const feature4 = (cov_wqxgpcwj7().s[44]++, featuresContent.appendChild(document.createElement('li')));
    cov_wqxgpcwj7().s[45]++;
    feature4.innerHTML = 'Ability to focus, mark as completed, and delete tasks';
    const feature5 = (cov_wqxgpcwj7().s[46]++, featuresContent.appendChild(document.createElement('li')));
    cov_wqxgpcwj7().s[47]++;
    feature5.innerHTML = 'Focus mode to eliminate page distractions and allow for greater focus on current task';
    const accessibilityDiv = (cov_wqxgpcwj7().s[48]++, helpContainer.appendChild(document.createElement('div')));
    cov_wqxgpcwj7().s[49]++;
    accessibilityDiv.setAttribute('id', 'accessibility');
    const accessibilityTitle = (cov_wqxgpcwj7().s[50]++, accessibilityDiv.appendChild(document.createElement('h4')));
    cov_wqxgpcwj7().s[51]++;
    accessibilityTitle.innerHTML = 'Keyboard Shortcuts';
    const accessibilityContent = (cov_wqxgpcwj7().s[52]++, accessibilityDiv.appendChild(document.createElement('ul')));
    cov_wqxgpcwj7().s[53]++;
    accessibilityContent.setAttribute('id', 'accessibility-content');
    const shortcut1 = (cov_wqxgpcwj7().s[54]++, accessibilityContent.appendChild(document.createElement('li')));
    cov_wqxgpcwj7().s[55]++;
    shortcut1.innerHTML = "'h' - Help page pop up";
    const shortcut2 = (cov_wqxgpcwj7().s[56]++, accessibilityContent.appendChild(document.createElement('li')));
    cov_wqxgpcwj7().s[57]++;
    shortcut2.innerHTML = "';' - Settings pop up";
    const shortcut3 = (cov_wqxgpcwj7().s[58]++, accessibilityContent.appendChild(document.createElement('li')));
    cov_wqxgpcwj7().s[59]++;
    shortcut3.innerHTML = "'r' - Reset pop up";
    const shortcut4 = (cov_wqxgpcwj7().s[60]++, accessibilityContent.appendChild(document.createElement('li')));
    cov_wqxgpcwj7().s[61]++;
    shortcut4.innerHTML = "'f' - Focus mode";
    const shortcut5 = (cov_wqxgpcwj7().s[62]++, accessibilityContent.appendChild(document.createElement('li')));
    cov_wqxgpcwj7().s[63]++;
    shortcut5.innerHTML = "'s' - Start/stop";
    const shortcut6 = (cov_wqxgpcwj7().s[64]++, accessibilityContent.appendChild(document.createElement('li')));
    cov_wqxgpcwj7().s[65]++;
    shortcut6.innerHTML = "'a' - Add task";
    const shortcut7 = (cov_wqxgpcwj7().s[66]++, accessibilityContent.appendChild(document.createElement('li')));
    cov_wqxgpcwj7().s[67]++;
    shortcut7.innerHTML = "'Enter' - Confirm/Add";
    const shortcut8 = (cov_wqxgpcwj7().s[68]++, accessibilityContent.appendChild(document.createElement('li')));
    cov_wqxgpcwj7().s[69]++;
    shortcut8.innerHTML = "'Esc' - Cancel/Close"; // use ::part pseudo-element to style element outside of shadow tree -- for dark mode

    cov_wqxgpcwj7().s[70]++;
    wrapper.setAttribute('part', 'popup-wrapper');
    cov_wqxgpcwj7().s[71]++;
    close.setAttribute('part', 'close-icon');
    cov_wqxgpcwj7().s[72]++;
    title.setAttribute('part', 'help-h3');
    cov_wqxgpcwj7().s[73]++;
    instructionsDiv.setAttribute('part', 'instructions');
    cov_wqxgpcwj7().s[74]++;
    featuresDiv.setAttribute('part', 'features');
    cov_wqxgpcwj7().s[75]++;
    accessibilityDiv.setAttribute('part', 'accessibility');
    cov_wqxgpcwj7().s[76]++;
    howTo.setAttribute('part', 'h4');
    cov_wqxgpcwj7().s[77]++;
    featuresTitle.setAttribute('part', 'h4');
    cov_wqxgpcwj7().s[78]++;
    accessibilityTitle.setAttribute('part', 'h4'); // CSS styling

    const style = (cov_wqxgpcwj7().s[79]++, document.createElement('style'));
    cov_wqxgpcwj7().s[80]++;
    style.textContent = `
        #accessibility-content li{
            margin-bottom: 0.390625vw;
        }
        #accessibility-content {
            padding: 0;
            margin-left: 1.875vw;
            font-size: 1vw;
        }
        #accessibility {
            font-weight: 500;
            color: rgb(85, 85, 85);
        }
        #features-content li {
            margin-bottom: 0.390625vw;
        }
        #features-content {
            padding: 0;
            margin-left: 1.875vw;
            font-size: 1vw;
        }
        #features {
            font-weight: 500;
            color: rgb(85, 85, 85);
        }
        #how-to-content li {
            margin-bottom: 0.390625vw;
        }
        #how-to-content {
            padding: 0;
            margin-left: 1.875vw;
            font-size: 1vw;
        }
        #how-to {
            font-weight: 500;
            color: rgb(85, 85, 85);
        }
        h4 {
            font-size: 1.15vw;
            color: rgb(85, 85, 85);
            font-weight: 500;
        }
        #help-container {
            width: 85%;
            margin: 0 auto;
            // height: 80%;
            height: 28.125vw;
            overflow: auto;
        }
        #close-icon {
            // width: 15px;
            width: 1.171875vw;
            // margin-top: 10px;
            // margin-right: 10px;
            margin-top: 0.78125vw;
            margin-right: 0.78125vw;
            position:absolute;
            top:0;
            right:0;
            cursor: pointer;
            opacity: 0.33;
        }
        #close-icon:hover {
            opacity: 1;
            transform: scale(1.1);
        }
        #help-popup {
            display: none;
            position: fixed;
            // width: 30%;
            // width: 52%;
            width: 51.953125vw;
            // height: 30%;
            height: 35.15625vw;
            // border-radius: 4px;
            border-radius: 0.3125vw;
            top:18%;
            // left: 34%;
            left: 24%;
            z-index: 999;
            background-color: whitesmoke;
            box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
            -webkit-animation-name: animatetop; 
            -webkit-animation-duration: 0.3s;
            animation-name: animatetop;
            animation-duration: 0.3s
        }
        @-webkit-keyframes animatetop {
            from {top:-200px; opacity:0} 
            to {top:70; opacity:1}
        }
        @keyframes animatetop {
            from {top:-200px; opacity:0}
            to {top:70; opacity:1}
        }
        #help-popup > h3{
            font-size: 1.6vw;
            color: #f36060;
            border-bottom: solid 1px #d2d2d2;
            // padding-bottom: 5px;
            padding-bottom: 0.390625vw;
            width: 85%;
            font-weight: 500;
            // margin: 20px auto 10px auto;
            margin: 1.5625vw auto 0.78125vw auto;
        }`;
    cov_wqxgpcwj7().s[81]++;
    shadow.appendChild(wrapper);
    cov_wqxgpcwj7().s[82]++;
    shadow.appendChild(style);
  }

}

cov_wqxgpcwj7().s[83]++;
customElements.define('help-popup', HelpPopUp);
cov_wqxgpcwj7().s[84]++;
window.addEventListener('load', () => {
  cov_wqxgpcwj7().f[2]++;
  const helpPopUp = (cov_wqxgpcwj7().s[85]++, document.createElement('help-popup'));
  cov_wqxgpcwj7().s[86]++;
  helpPopUp.setAttribute('class', 'popup');
  cov_wqxgpcwj7().s[87]++;
  document.body.appendChild(helpPopUp);
  const helpBtn = (cov_wqxgpcwj7().s[88]++, document.getElementById('help-button'));
  cov_wqxgpcwj7().s[89]++;
  helpBtn.addEventListener('click', () => {
    cov_wqxgpcwj7().f[3]++;
    const btnSound = (cov_wqxgpcwj7().s[90]++, new Audio('./icons/btnClick.mp3'));
    cov_wqxgpcwj7().s[91]++;
    btnSound.volume = 0.01 * parseInt(localStorage.getItem('volume'), 10);
    cov_wqxgpcwj7().s[92]++;
    btnSound.play(); // this makes sure any popup is closed before opening current popup

    const popups = (cov_wqxgpcwj7().s[93]++, Array.from(document.getElementsByClassName('popup')));
    cov_wqxgpcwj7().s[94]++;

    for (let i = (cov_wqxgpcwj7().s[95]++, 0); i < popups.length; i += 1) {
      cov_wqxgpcwj7().s[96]++;
      popups[i].closePopUp();
    }

    cov_wqxgpcwj7().s[97]++;
    helpPopUp.shadowRoot.getElementById('help-popup').setAttribute('style', 'display:block');
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkhlbHBQb3BVcC5qcyJdLCJuYW1lcyI6WyJIZWxwUG9wVXAiLCJIVE1MRWxlbWVudCIsImNsb3NlUG9wVXAiLCJ3cmFwcGVyIiwic2hhZG93Um9vdCIsImdldEVsZW1lbnRCeUlkIiwic3R5bGUiLCJkaXNwbGF5IiwiY29uc3RydWN0b3IiLCJzaGFkb3ciLCJhdHRhY2hTaGFkb3ciLCJtb2RlIiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50Iiwic2V0QXR0cmlidXRlIiwiY2xvc2UiLCJhcHBlbmRDaGlsZCIsInRpdGxlIiwiaW5uZXJIVE1MIiwiYWRkRXZlbnRMaXN0ZW5lciIsImJpbmQiLCJoZWxwQ29udGFpbmVyIiwiaW5zdHJ1Y3Rpb25zRGl2IiwiaG93VG8iLCJob3dUb0NvbnRlbnQiLCJzdGVwMSIsInN0ZXAyIiwic3RlcDMiLCJzdGVwNCIsInN0ZXA1Iiwic3RlcDYiLCJmZWF0dXJlc0RpdiIsImZlYXR1cmVzVGl0bGUiLCJmZWF0dXJlc0NvbnRlbnQiLCJmZWF0dXJlMSIsImZlYXR1cmUyIiwiZmVhdHVyZTMiLCJmZWF0dXJlNCIsImZlYXR1cmU1IiwiYWNjZXNzaWJpbGl0eURpdiIsImFjY2Vzc2liaWxpdHlUaXRsZSIsImFjY2Vzc2liaWxpdHlDb250ZW50Iiwic2hvcnRjdXQxIiwic2hvcnRjdXQyIiwic2hvcnRjdXQzIiwic2hvcnRjdXQ0Iiwic2hvcnRjdXQ1Iiwic2hvcnRjdXQ2Iiwic2hvcnRjdXQ3Iiwic2hvcnRjdXQ4IiwidGV4dENvbnRlbnQiLCJjdXN0b21FbGVtZW50cyIsImRlZmluZSIsIndpbmRvdyIsImhlbHBQb3BVcCIsImJvZHkiLCJoZWxwQnRuIiwiYnRuU291bmQiLCJBdWRpbyIsInZvbHVtZSIsInBhcnNlSW50IiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInBsYXkiLCJwb3B1cHMiLCJBcnJheSIsImZyb20iLCJnZXRFbGVtZW50c0J5Q2xhc3NOYW1lIiwiaSIsImxlbmd0aCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBZVk7Ozs7Ozs7Ozs7QUFmWixNQUFNQSxTQUFOLFNBQXdCQyxXQUF4QixDQUFvQztBQUNoQ0MsRUFBQUEsVUFBVSxHQUFHO0FBQUE7QUFDVCxVQUFNQyxPQUFPLDRCQUFHLEtBQUtDLFVBQUwsQ0FBZ0JDLGNBQWhCLENBQStCLFlBQS9CLENBQUgsQ0FBYjtBQURTO0FBRVRGLElBQUFBLE9BQU8sQ0FBQ0csS0FBUixDQUFjQyxPQUFkLEdBQXdCLE1BQXhCO0FBQ0g7O0FBRURDLEVBQUFBLFdBQVcsR0FBRztBQUFBO0FBQUE7QUFDVjtBQUNBLFVBQU1DLE1BQU0sNEJBQUcsS0FBS0MsWUFBTCxDQUFrQjtBQUFFQyxNQUFBQSxJQUFJLEVBQUU7QUFBUixLQUFsQixDQUFILENBQVo7QUFDQSxVQUFNUixPQUFPLDRCQUFHUyxRQUFRLENBQUNDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBSCxDQUFiO0FBSFU7QUFJVlYsSUFBQUEsT0FBTyxDQUFDVyxZQUFSLENBQXFCLElBQXJCLEVBQTJCLFlBQTNCO0FBQ0EsVUFBTUMsS0FBSyw0QkFBR1osT0FBTyxDQUFDYSxXQUFSLENBQW9CSixRQUFRLENBQUNDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBcEIsQ0FBSCxDQUFYO0FBTFU7QUFNVkUsSUFBQUEsS0FBSyxDQUFDRCxZQUFOLENBQW1CLEtBQW5CLEVBQTBCLGlCQUExQjtBQU5VO0FBT1ZDLElBQUFBLEtBQUssQ0FBQ0QsWUFBTixDQUFtQixJQUFuQixFQUF5QixZQUF6QjtBQUNBLFVBQU1HLEtBQUssNEJBQUdkLE9BQU8sQ0FBQ2EsV0FBUixDQUFvQkosUUFBUSxDQUFDQyxhQUFULENBQXVCLElBQXZCLENBQXBCLENBQUgsQ0FBWDtBQVJVO0FBU1ZJLElBQUFBLEtBQUssQ0FBQ0MsU0FBTixHQUFrQixNQUFsQjtBQVRVO0FBVVZILElBQUFBLEtBQUssQ0FBQ0ksZ0JBQU4sQ0FBdUIsT0FBdkIsRUFBZ0MsS0FBS2pCLFVBQUwsQ0FBZ0JrQixJQUFoQixDQUFxQixJQUFyQixDQUFoQztBQUNBLFVBQU1DLGFBQWEsNkJBQUdsQixPQUFPLENBQUNhLFdBQVIsQ0FBb0JKLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixLQUF2QixDQUFwQixDQUFILENBQW5CO0FBWFU7QUFZVlEsSUFBQUEsYUFBYSxDQUFDUCxZQUFkLENBQTJCLElBQTNCLEVBQWlDLGdCQUFqQztBQUNBLFVBQU1RLGVBQWUsNkJBQUdELGFBQWEsQ0FBQ0wsV0FBZCxDQUEwQkosUUFBUSxDQUFDQyxhQUFULENBQXVCLEtBQXZCLENBQTFCLENBQUgsQ0FBckI7QUFiVTtBQWNWUyxJQUFBQSxlQUFlLENBQUNSLFlBQWhCLENBQTZCLElBQTdCLEVBQW1DLFFBQW5DO0FBQ0EsVUFBTVMsS0FBSyw2QkFBR0QsZUFBZSxDQUFDTixXQUFoQixDQUE0QkosUUFBUSxDQUFDQyxhQUFULENBQXVCLElBQXZCLENBQTVCLENBQUgsQ0FBWDtBQWZVO0FBZ0JWVSxJQUFBQSxLQUFLLENBQUNMLFNBQU4sR0FBa0IsK0JBQWxCO0FBQ0EsVUFBTU0sWUFBWSw2QkFBR0YsZUFBZSxDQUFDTixXQUFoQixDQUE0QkosUUFBUSxDQUFDQyxhQUFULENBQXVCLElBQXZCLENBQTVCLENBQUgsQ0FBbEI7QUFqQlU7QUFrQlZXLElBQUFBLFlBQVksQ0FBQ1YsWUFBYixDQUEwQixJQUExQixFQUFnQyxnQkFBaEM7QUFDQSxVQUFNVyxLQUFLLDZCQUFHRCxZQUFZLENBQUNSLFdBQWIsQ0FBeUJKLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixJQUF2QixDQUF6QixDQUFILENBQVg7QUFuQlU7QUFvQlZZLElBQUFBLEtBQUssQ0FBQ1AsU0FBTixHQUFrQixnQ0FBbEI7QUFDQSxVQUFNUSxLQUFLLDZCQUFHRixZQUFZLENBQUNSLFdBQWIsQ0FBeUJKLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixJQUF2QixDQUF6QixDQUFILENBQVg7QUFyQlU7QUFzQlZhLElBQUFBLEtBQUssQ0FBQ1IsU0FBTixHQUFrQiw0RUFBbEI7QUFDQSxVQUFNUyxLQUFLLDZCQUFHSCxZQUFZLENBQUNSLFdBQWIsQ0FBeUJKLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixJQUF2QixDQUF6QixDQUFILENBQVg7QUF2QlU7QUF3QlZjLElBQUFBLEtBQUssQ0FBQ1QsU0FBTixHQUFrQiwyREFBbEI7QUFDQSxVQUFNVSxLQUFLLDZCQUFHSixZQUFZLENBQUNSLFdBQWIsQ0FBeUJKLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixJQUF2QixDQUF6QixDQUFILENBQVg7QUF6QlU7QUEwQlZlLElBQUFBLEtBQUssQ0FBQ1YsU0FBTixHQUFrQixvQ0FBbEI7QUFDQSxVQUFNVyxLQUFLLDZCQUFHTCxZQUFZLENBQUNSLFdBQWIsQ0FBeUJKLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixJQUF2QixDQUF6QixDQUFILENBQVg7QUEzQlU7QUE0QlZnQixJQUFBQSxLQUFLLENBQUNYLFNBQU4sR0FBa0IsbUNBQWxCO0FBQ0EsVUFBTVksS0FBSyw2QkFBR04sWUFBWSxDQUFDUixXQUFiLENBQXlCSixRQUFRLENBQUNDLGFBQVQsQ0FBdUIsSUFBdkIsQ0FBekIsQ0FBSCxDQUFYO0FBN0JVO0FBOEJWaUIsSUFBQUEsS0FBSyxDQUFDWixTQUFOLEdBQWtCLGtDQUFsQjtBQUVBLFVBQU1hLFdBQVcsNkJBQUdWLGFBQWEsQ0FBQ0wsV0FBZCxDQUEwQkosUUFBUSxDQUFDQyxhQUFULENBQXVCLEtBQXZCLENBQTFCLENBQUgsQ0FBakI7QUFoQ1U7QUFpQ1ZrQixJQUFBQSxXQUFXLENBQUNqQixZQUFaLENBQXlCLElBQXpCLEVBQStCLFVBQS9CO0FBQ0EsVUFBTWtCLGFBQWEsNkJBQUdELFdBQVcsQ0FBQ2YsV0FBWixDQUF3QkosUUFBUSxDQUFDQyxhQUFULENBQXVCLElBQXZCLENBQXhCLENBQUgsQ0FBbkI7QUFsQ1U7QUFtQ1ZtQixJQUFBQSxhQUFhLENBQUNkLFNBQWQsR0FBMEIsVUFBMUI7QUFDQSxVQUFNZSxlQUFlLDZCQUFHRixXQUFXLENBQUNmLFdBQVosQ0FBd0JKLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixJQUF2QixDQUF4QixDQUFILENBQXJCO0FBcENVO0FBcUNWb0IsSUFBQUEsZUFBZSxDQUFDbkIsWUFBaEIsQ0FBNkIsSUFBN0IsRUFBbUMsa0JBQW5DO0FBQ0EsVUFBTW9CLFFBQVEsNkJBQUdELGVBQWUsQ0FBQ2pCLFdBQWhCLENBQTRCSixRQUFRLENBQUNDLGFBQVQsQ0FBdUIsSUFBdkIsQ0FBNUIsQ0FBSCxDQUFkO0FBdENVO0FBdUNWcUIsSUFBQUEsUUFBUSxDQUFDaEIsU0FBVCxHQUFxQiw4Q0FBckI7QUFDQSxVQUFNaUIsUUFBUSw2QkFBR0YsZUFBZSxDQUFDakIsV0FBaEIsQ0FBNEJKLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixJQUF2QixDQUE1QixDQUFILENBQWQ7QUF4Q1U7QUF5Q1ZzQixJQUFBQSxRQUFRLENBQUNqQixTQUFULEdBQXFCLGlEQUFyQjtBQUNBLFVBQU1rQixRQUFRLDZCQUFHSCxlQUFlLENBQUNqQixXQUFoQixDQUE0QkosUUFBUSxDQUFDQyxhQUFULENBQXVCLElBQXZCLENBQTVCLENBQUgsQ0FBZDtBQTFDVTtBQTJDVnVCLElBQUFBLFFBQVEsQ0FBQ2xCLFNBQVQsR0FBcUIsMkNBQXJCO0FBQ0EsVUFBTW1CLFFBQVEsNkJBQUdKLGVBQWUsQ0FBQ2pCLFdBQWhCLENBQTRCSixRQUFRLENBQUNDLGFBQVQsQ0FBdUIsSUFBdkIsQ0FBNUIsQ0FBSCxDQUFkO0FBNUNVO0FBNkNWd0IsSUFBQUEsUUFBUSxDQUFDbkIsU0FBVCxHQUFxQix1REFBckI7QUFDQSxVQUFNb0IsUUFBUSw2QkFBR0wsZUFBZSxDQUFDakIsV0FBaEIsQ0FBNEJKLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixJQUF2QixDQUE1QixDQUFILENBQWQ7QUE5Q1U7QUErQ1Z5QixJQUFBQSxRQUFRLENBQUNwQixTQUFULEdBQXFCLHVGQUFyQjtBQUVBLFVBQU1xQixnQkFBZ0IsNkJBQUdsQixhQUFhLENBQUNMLFdBQWQsQ0FBMEJKLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixLQUF2QixDQUExQixDQUFILENBQXRCO0FBakRVO0FBa0RWMEIsSUFBQUEsZ0JBQWdCLENBQUN6QixZQUFqQixDQUE4QixJQUE5QixFQUFvQyxlQUFwQztBQUNBLFVBQU0wQixrQkFBa0IsNkJBQUdELGdCQUFnQixDQUFDdkIsV0FBakIsQ0FBNkJKLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixJQUF2QixDQUE3QixDQUFILENBQXhCO0FBbkRVO0FBb0RWMkIsSUFBQUEsa0JBQWtCLENBQUN0QixTQUFuQixHQUErQixvQkFBL0I7QUFDQSxVQUFNdUIsb0JBQW9CLDZCQUFHRixnQkFBZ0IsQ0FBQ3ZCLFdBQWpCLENBQTZCSixRQUFRLENBQUNDLGFBQVQsQ0FBdUIsSUFBdkIsQ0FBN0IsQ0FBSCxDQUExQjtBQXJEVTtBQXNEVjRCLElBQUFBLG9CQUFvQixDQUFDM0IsWUFBckIsQ0FBa0MsSUFBbEMsRUFBd0MsdUJBQXhDO0FBQ0EsVUFBTTRCLFNBQVMsNkJBQUdELG9CQUFvQixDQUFDekIsV0FBckIsQ0FBaUNKLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixJQUF2QixDQUFqQyxDQUFILENBQWY7QUF2RFU7QUF3RFY2QixJQUFBQSxTQUFTLENBQUN4QixTQUFWLEdBQXNCLHdCQUF0QjtBQUNBLFVBQU15QixTQUFTLDZCQUFHRixvQkFBb0IsQ0FBQ3pCLFdBQXJCLENBQWlDSixRQUFRLENBQUNDLGFBQVQsQ0FBdUIsSUFBdkIsQ0FBakMsQ0FBSCxDQUFmO0FBekRVO0FBMERWOEIsSUFBQUEsU0FBUyxDQUFDekIsU0FBVixHQUFzQix1QkFBdEI7QUFDQSxVQUFNMEIsU0FBUyw2QkFBR0gsb0JBQW9CLENBQUN6QixXQUFyQixDQUFpQ0osUUFBUSxDQUFDQyxhQUFULENBQXVCLElBQXZCLENBQWpDLENBQUgsQ0FBZjtBQTNEVTtBQTREVitCLElBQUFBLFNBQVMsQ0FBQzFCLFNBQVYsR0FBc0Isb0JBQXRCO0FBQ0EsVUFBTTJCLFNBQVMsNkJBQUdKLG9CQUFvQixDQUFDekIsV0FBckIsQ0FBaUNKLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixJQUF2QixDQUFqQyxDQUFILENBQWY7QUE3RFU7QUE4RFZnQyxJQUFBQSxTQUFTLENBQUMzQixTQUFWLEdBQXNCLGtCQUF0QjtBQUNBLFVBQU00QixTQUFTLDZCQUFHTCxvQkFBb0IsQ0FBQ3pCLFdBQXJCLENBQWlDSixRQUFRLENBQUNDLGFBQVQsQ0FBdUIsSUFBdkIsQ0FBakMsQ0FBSCxDQUFmO0FBL0RVO0FBZ0VWaUMsSUFBQUEsU0FBUyxDQUFDNUIsU0FBVixHQUFzQixrQkFBdEI7QUFDQSxVQUFNNkIsU0FBUyw2QkFBR04sb0JBQW9CLENBQUN6QixXQUFyQixDQUFpQ0osUUFBUSxDQUFDQyxhQUFULENBQXVCLElBQXZCLENBQWpDLENBQUgsQ0FBZjtBQWpFVTtBQWtFVmtDLElBQUFBLFNBQVMsQ0FBQzdCLFNBQVYsR0FBc0IsZ0JBQXRCO0FBQ0EsVUFBTThCLFNBQVMsNkJBQUdQLG9CQUFvQixDQUFDekIsV0FBckIsQ0FBaUNKLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixJQUF2QixDQUFqQyxDQUFILENBQWY7QUFuRVU7QUFvRVZtQyxJQUFBQSxTQUFTLENBQUM5QixTQUFWLEdBQXNCLHVCQUF0QjtBQUNBLFVBQU0rQixTQUFTLDZCQUFHUixvQkFBb0IsQ0FBQ3pCLFdBQXJCLENBQWlDSixRQUFRLENBQUNDLGFBQVQsQ0FBdUIsSUFBdkIsQ0FBakMsQ0FBSCxDQUFmO0FBckVVO0FBc0VWb0MsSUFBQUEsU0FBUyxDQUFDL0IsU0FBVixHQUFzQixzQkFBdEIsQ0F0RVUsQ0F3RVY7O0FBeEVVO0FBeUVWZixJQUFBQSxPQUFPLENBQUNXLFlBQVIsQ0FBcUIsTUFBckIsRUFBNkIsZUFBN0I7QUF6RVU7QUEwRVZDLElBQUFBLEtBQUssQ0FBQ0QsWUFBTixDQUFtQixNQUFuQixFQUEyQixZQUEzQjtBQTFFVTtBQTJFVkcsSUFBQUEsS0FBSyxDQUFDSCxZQUFOLENBQW1CLE1BQW5CLEVBQTJCLFNBQTNCO0FBM0VVO0FBNEVWUSxJQUFBQSxlQUFlLENBQUNSLFlBQWhCLENBQTZCLE1BQTdCLEVBQXFDLGNBQXJDO0FBNUVVO0FBNkVWaUIsSUFBQUEsV0FBVyxDQUFDakIsWUFBWixDQUF5QixNQUF6QixFQUFpQyxVQUFqQztBQTdFVTtBQThFVnlCLElBQUFBLGdCQUFnQixDQUFDekIsWUFBakIsQ0FBOEIsTUFBOUIsRUFBc0MsZUFBdEM7QUE5RVU7QUErRVZTLElBQUFBLEtBQUssQ0FBQ1QsWUFBTixDQUFtQixNQUFuQixFQUEyQixJQUEzQjtBQS9FVTtBQWdGVmtCLElBQUFBLGFBQWEsQ0FBQ2xCLFlBQWQsQ0FBMkIsTUFBM0IsRUFBbUMsSUFBbkM7QUFoRlU7QUFpRlYwQixJQUFBQSxrQkFBa0IsQ0FBQzFCLFlBQW5CLENBQWdDLE1BQWhDLEVBQXdDLElBQXhDLEVBakZVLENBbUZWOztBQUNBLFVBQU1SLEtBQUssNkJBQUdNLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixPQUF2QixDQUFILENBQVg7QUFwRlU7QUFxRlZQLElBQUFBLEtBQUssQ0FBQzRDLFdBQU4sR0FBcUI7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBekdRO0FBckZVO0FBK0xWekMsSUFBQUEsTUFBTSxDQUFDTyxXQUFQLENBQW1CYixPQUFuQjtBQS9MVTtBQWdNVk0sSUFBQUEsTUFBTSxDQUFDTyxXQUFQLENBQW1CVixLQUFuQjtBQUNIOztBQXZNK0I7OztBQXlNcEM2QyxjQUFjLENBQUNDLE1BQWYsQ0FBc0IsWUFBdEIsRUFBb0NwRCxTQUFwQzs7QUFFQXFELE1BQU0sQ0FBQ2xDLGdCQUFQLENBQXdCLE1BQXhCLEVBQWdDLE1BQU07QUFBQTtBQUNsQyxRQUFNbUMsU0FBUyw2QkFBRzFDLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixZQUF2QixDQUFILENBQWY7QUFEa0M7QUFFbEN5QyxFQUFBQSxTQUFTLENBQUN4QyxZQUFWLENBQXVCLE9BQXZCLEVBQWdDLE9BQWhDO0FBRmtDO0FBR2xDRixFQUFBQSxRQUFRLENBQUMyQyxJQUFULENBQWN2QyxXQUFkLENBQTBCc0MsU0FBMUI7QUFDQSxRQUFNRSxPQUFPLDZCQUFHNUMsUUFBUSxDQUFDUCxjQUFULENBQXdCLGFBQXhCLENBQUgsQ0FBYjtBQUprQztBQUtsQ21ELEVBQUFBLE9BQU8sQ0FBQ3JDLGdCQUFSLENBQXlCLE9BQXpCLEVBQWtDLE1BQU07QUFBQTtBQUNwQyxVQUFNc0MsUUFBUSw2QkFBRyxJQUFJQyxLQUFKLENBQVUsc0JBQVYsQ0FBSCxDQUFkO0FBRG9DO0FBRXBDRCxJQUFBQSxRQUFRLENBQUNFLE1BQVQsR0FBa0IsT0FBT0MsUUFBUSxDQUFDQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsUUFBckIsQ0FBRCxFQUFpQyxFQUFqQyxDQUFqQztBQUZvQztBQUdwQ0wsSUFBQUEsUUFBUSxDQUFDTSxJQUFULEdBSG9DLENBSXBDOztBQUNBLFVBQU1DLE1BQU0sNkJBQUdDLEtBQUssQ0FBQ0MsSUFBTixDQUFXdEQsUUFBUSxDQUFDdUQsc0JBQVQsQ0FBZ0MsT0FBaEMsQ0FBWCxDQUFILENBQVo7QUFMb0M7O0FBTXBDLFNBQUssSUFBSUMsQ0FBQyw2QkFBRyxDQUFILENBQVYsRUFBZ0JBLENBQUMsR0FBR0osTUFBTSxDQUFDSyxNQUEzQixFQUFtQ0QsQ0FBQyxJQUFJLENBQXhDLEVBQTJDO0FBQUE7QUFDdkNKLE1BQUFBLE1BQU0sQ0FBQ0ksQ0FBRCxDQUFOLENBQVVsRSxVQUFWO0FBQ0g7O0FBUm1DO0FBU3BDb0QsSUFBQUEsU0FBUyxDQUFDbEQsVUFBVixDQUFxQkMsY0FBckIsQ0FBb0MsWUFBcEMsRUFBa0RTLFlBQWxELENBQStELE9BQS9ELEVBQXdFLGVBQXhFO0FBQ0gsR0FWRDtBQVdILENBaEJEIiwic291cmNlc0NvbnRlbnQiOlsiY2xhc3MgSGVscFBvcFVwIGV4dGVuZHMgSFRNTEVsZW1lbnQge1xyXG4gICAgY2xvc2VQb3BVcCgpIHtcclxuICAgICAgICBjb25zdCB3cmFwcGVyID0gdGhpcy5zaGFkb3dSb290LmdldEVsZW1lbnRCeUlkKCdoZWxwLXBvcHVwJyk7XHJcbiAgICAgICAgd3JhcHBlci5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgICAgIHN1cGVyKCk7XHJcbiAgICAgICAgY29uc3Qgc2hhZG93ID0gdGhpcy5hdHRhY2hTaGFkb3coeyBtb2RlOiAnb3BlbicgfSk7XHJcbiAgICAgICAgY29uc3Qgd3JhcHBlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgICAgIHdyYXBwZXIuc2V0QXR0cmlidXRlKCdpZCcsICdoZWxwLXBvcHVwJyk7XHJcbiAgICAgICAgY29uc3QgY2xvc2UgPSB3cmFwcGVyLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2ltZycpKTtcclxuICAgICAgICBjbG9zZS5zZXRBdHRyaWJ1dGUoJ3NyYycsICdpY29ucy9jbG9zZS5zdmcnKTtcclxuICAgICAgICBjbG9zZS5zZXRBdHRyaWJ1dGUoJ2lkJywgJ2Nsb3NlLWljb24nKTtcclxuICAgICAgICBjb25zdCB0aXRsZSA9IHdyYXBwZXIuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaDMnKSk7XHJcbiAgICAgICAgdGl0bGUuaW5uZXJIVE1MID0gJ0hlbHAnO1xyXG4gICAgICAgIGNsb3NlLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgdGhpcy5jbG9zZVBvcFVwLmJpbmQodGhpcykpO1xyXG4gICAgICAgIGNvbnN0IGhlbHBDb250YWluZXIgPSB3cmFwcGVyLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpKTtcclxuICAgICAgICBoZWxwQ29udGFpbmVyLnNldEF0dHJpYnV0ZSgnaWQnLCAnaGVscC1jb250YWluZXInKTtcclxuICAgICAgICBjb25zdCBpbnN0cnVjdGlvbnNEaXYgPSBoZWxwQ29udGFpbmVyLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpKTtcclxuICAgICAgICBpbnN0cnVjdGlvbnNEaXYuc2V0QXR0cmlidXRlKCdpZCcsICdob3ctdG8nKTtcclxuICAgICAgICBjb25zdCBob3dUbyA9IGluc3RydWN0aW9uc0Rpdi5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdoNCcpKTtcclxuICAgICAgICBob3dUby5pbm5lckhUTUwgPSAnSG93IHRvIHVzZSB0aGUgUG9tb2Rvcm8gVGltZXInO1xyXG4gICAgICAgIGNvbnN0IGhvd1RvQ29udGVudCA9IGluc3RydWN0aW9uc0Rpdi5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdvbCcpKTtcclxuICAgICAgICBob3dUb0NvbnRlbnQuc2V0QXR0cmlidXRlKCdpZCcsICdob3ctdG8tY29udGVudCcpO1xyXG4gICAgICAgIGNvbnN0IHN0ZXAxID0gaG93VG9Db250ZW50LmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJykpO1xyXG4gICAgICAgIHN0ZXAxLmlubmVySFRNTCA9IFwiQWRkIHRhc2tzIHVzaW5nIHRoZSAnKycgYnV0dG9uXCI7XHJcbiAgICAgICAgY29uc3Qgc3RlcDIgPSBob3dUb0NvbnRlbnQuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKSk7XHJcbiAgICAgICAgc3RlcDIuaW5uZXJIVE1MID0gJ1NldCBwb21vZG9ybyBhbmQgYnJlYWsgbGVuZ3RocyBpbiB0aGUgc2V0dGluZ3MgKG9yIHVzZSB0aGUgZGVmYXVsdCB2YWx1ZXMpJztcclxuICAgICAgICBjb25zdCBzdGVwMyA9IGhvd1RvQ29udGVudC5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpKTtcclxuICAgICAgICBzdGVwMy5pbm5lckhUTUwgPSAnU2VsZWN0IGEgdGFzayB0byBmb2N1cyBvbiB1c2luZyB0aGUgbWFnbmlmeWluZyBnbGFzcyBpY29uJztcclxuICAgICAgICBjb25zdCBzdGVwNCA9IGhvd1RvQ29udGVudC5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpKTtcclxuICAgICAgICBzdGVwNC5pbm5lckhUTUwgPSAnU3RhcnQgdGhlIHRpbWVyIGFuZCBiZSBwcm9kdWN0aXZlISc7XHJcbiAgICAgICAgY29uc3Qgc3RlcDUgPSBob3dUb0NvbnRlbnQuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKSk7XHJcbiAgICAgICAgc3RlcDUuaW5uZXJIVE1MID0gJ1Rha2UgYSBicmVhayB3aGVuIHRoZSBhbGFybSByaW5ncyc7XHJcbiAgICAgICAgY29uc3Qgc3RlcDYgPSBob3dUb0NvbnRlbnQuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKSk7XHJcbiAgICAgICAgc3RlcDYuaW5uZXJIVE1MID0gJ1JlcGVhdCBzdGVwcyAzLTUgdG8gc2F0aXNmYWN0aW9uJztcclxuXHJcbiAgICAgICAgY29uc3QgZmVhdHVyZXNEaXYgPSBoZWxwQ29udGFpbmVyLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpKTtcclxuICAgICAgICBmZWF0dXJlc0Rpdi5zZXRBdHRyaWJ1dGUoJ2lkJywgJ2ZlYXR1cmVzJyk7XHJcbiAgICAgICAgY29uc3QgZmVhdHVyZXNUaXRsZSA9IGZlYXR1cmVzRGl2LmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2g0JykpO1xyXG4gICAgICAgIGZlYXR1cmVzVGl0bGUuaW5uZXJIVE1MID0gJ0ZlYXR1cmVzJztcclxuICAgICAgICBjb25zdCBmZWF0dXJlc0NvbnRlbnQgPSBmZWF0dXJlc0Rpdi5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KCd1bCcpKTtcclxuICAgICAgICBmZWF0dXJlc0NvbnRlbnQuc2V0QXR0cmlidXRlKCdpZCcsICdmZWF0dXJlcy1jb250ZW50Jyk7XHJcbiAgICAgICAgY29uc3QgZmVhdHVyZTEgPSBmZWF0dXJlc0NvbnRlbnQuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKSk7XHJcbiAgICAgICAgZmVhdHVyZTEuaW5uZXJIVE1MID0gJ0RhcmsgbW9kZSB0aGVtZSBmb3IgbGF0ZSBuaWdodCB3b3JrIHNlc3Npb25zJztcclxuICAgICAgICBjb25zdCBmZWF0dXJlMiA9IGZlYXR1cmVzQ29udGVudC5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpKTtcclxuICAgICAgICBmZWF0dXJlMi5pbm5lckhUTUwgPSAnQXVkaW8gbm90aWZpY2F0aW9ucyBhdCBlbmQgb2YgcG9tb2Rvcm8gc2Vzc2lvbnMnO1xyXG4gICAgICAgIGNvbnN0IGZlYXR1cmUzID0gZmVhdHVyZXNDb250ZW50LmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJykpO1xyXG4gICAgICAgIGZlYXR1cmUzLmlubmVySFRNTCA9ICdDdXN0b21pemFibGUgcG9tb2Rvcm8gYW5kIGJyZWFrIGludGVydmFscyc7XHJcbiAgICAgICAgY29uc3QgZmVhdHVyZTQgPSBmZWF0dXJlc0NvbnRlbnQuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKSk7XHJcbiAgICAgICAgZmVhdHVyZTQuaW5uZXJIVE1MID0gJ0FiaWxpdHkgdG8gZm9jdXMsIG1hcmsgYXMgY29tcGxldGVkLCBhbmQgZGVsZXRlIHRhc2tzJztcclxuICAgICAgICBjb25zdCBmZWF0dXJlNSA9IGZlYXR1cmVzQ29udGVudC5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpKTtcclxuICAgICAgICBmZWF0dXJlNS5pbm5lckhUTUwgPSAnRm9jdXMgbW9kZSB0byBlbGltaW5hdGUgcGFnZSBkaXN0cmFjdGlvbnMgYW5kIGFsbG93IGZvciBncmVhdGVyIGZvY3VzIG9uIGN1cnJlbnQgdGFzayc7XHJcblxyXG4gICAgICAgIGNvbnN0IGFjY2Vzc2liaWxpdHlEaXYgPSBoZWxwQ29udGFpbmVyLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpKTtcclxuICAgICAgICBhY2Nlc3NpYmlsaXR5RGl2LnNldEF0dHJpYnV0ZSgnaWQnLCAnYWNjZXNzaWJpbGl0eScpO1xyXG4gICAgICAgIGNvbnN0IGFjY2Vzc2liaWxpdHlUaXRsZSA9IGFjY2Vzc2liaWxpdHlEaXYuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaDQnKSk7XHJcbiAgICAgICAgYWNjZXNzaWJpbGl0eVRpdGxlLmlubmVySFRNTCA9ICdLZXlib2FyZCBTaG9ydGN1dHMnO1xyXG4gICAgICAgIGNvbnN0IGFjY2Vzc2liaWxpdHlDb250ZW50ID0gYWNjZXNzaWJpbGl0eURpdi5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KCd1bCcpKTtcclxuICAgICAgICBhY2Nlc3NpYmlsaXR5Q29udGVudC5zZXRBdHRyaWJ1dGUoJ2lkJywgJ2FjY2Vzc2liaWxpdHktY29udGVudCcpO1xyXG4gICAgICAgIGNvbnN0IHNob3J0Y3V0MSA9IGFjY2Vzc2liaWxpdHlDb250ZW50LmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJykpO1xyXG4gICAgICAgIHNob3J0Y3V0MS5pbm5lckhUTUwgPSBcIidoJyAtIEhlbHAgcGFnZSBwb3AgdXBcIjtcclxuICAgICAgICBjb25zdCBzaG9ydGN1dDIgPSBhY2Nlc3NpYmlsaXR5Q29udGVudC5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpKTtcclxuICAgICAgICBzaG9ydGN1dDIuaW5uZXJIVE1MID0gXCInOycgLSBTZXR0aW5ncyBwb3AgdXBcIjtcclxuICAgICAgICBjb25zdCBzaG9ydGN1dDMgPSBhY2Nlc3NpYmlsaXR5Q29udGVudC5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpKTtcclxuICAgICAgICBzaG9ydGN1dDMuaW5uZXJIVE1MID0gXCIncicgLSBSZXNldCBwb3AgdXBcIjtcclxuICAgICAgICBjb25zdCBzaG9ydGN1dDQgPSBhY2Nlc3NpYmlsaXR5Q29udGVudC5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpKTtcclxuICAgICAgICBzaG9ydGN1dDQuaW5uZXJIVE1MID0gXCInZicgLSBGb2N1cyBtb2RlXCI7XHJcbiAgICAgICAgY29uc3Qgc2hvcnRjdXQ1ID0gYWNjZXNzaWJpbGl0eUNvbnRlbnQuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKSk7XHJcbiAgICAgICAgc2hvcnRjdXQ1LmlubmVySFRNTCA9IFwiJ3MnIC0gU3RhcnQvc3RvcFwiO1xyXG4gICAgICAgIGNvbnN0IHNob3J0Y3V0NiA9IGFjY2Vzc2liaWxpdHlDb250ZW50LmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJykpO1xyXG4gICAgICAgIHNob3J0Y3V0Ni5pbm5lckhUTUwgPSBcIidhJyAtIEFkZCB0YXNrXCI7XHJcbiAgICAgICAgY29uc3Qgc2hvcnRjdXQ3ID0gYWNjZXNzaWJpbGl0eUNvbnRlbnQuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKSk7XHJcbiAgICAgICAgc2hvcnRjdXQ3LmlubmVySFRNTCA9IFwiJ0VudGVyJyAtIENvbmZpcm0vQWRkXCI7XHJcbiAgICAgICAgY29uc3Qgc2hvcnRjdXQ4ID0gYWNjZXNzaWJpbGl0eUNvbnRlbnQuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKSk7XHJcbiAgICAgICAgc2hvcnRjdXQ4LmlubmVySFRNTCA9IFwiJ0VzYycgLSBDYW5jZWwvQ2xvc2VcIjtcclxuXHJcbiAgICAgICAgLy8gdXNlIDo6cGFydCBwc2V1ZG8tZWxlbWVudCB0byBzdHlsZSBlbGVtZW50IG91dHNpZGUgb2Ygc2hhZG93IHRyZWUgLS0gZm9yIGRhcmsgbW9kZVxyXG4gICAgICAgIHdyYXBwZXIuc2V0QXR0cmlidXRlKCdwYXJ0JywgJ3BvcHVwLXdyYXBwZXInKTtcclxuICAgICAgICBjbG9zZS5zZXRBdHRyaWJ1dGUoJ3BhcnQnLCAnY2xvc2UtaWNvbicpO1xyXG4gICAgICAgIHRpdGxlLnNldEF0dHJpYnV0ZSgncGFydCcsICdoZWxwLWgzJyk7XHJcbiAgICAgICAgaW5zdHJ1Y3Rpb25zRGl2LnNldEF0dHJpYnV0ZSgncGFydCcsICdpbnN0cnVjdGlvbnMnKTtcclxuICAgICAgICBmZWF0dXJlc0Rpdi5zZXRBdHRyaWJ1dGUoJ3BhcnQnLCAnZmVhdHVyZXMnKTtcclxuICAgICAgICBhY2Nlc3NpYmlsaXR5RGl2LnNldEF0dHJpYnV0ZSgncGFydCcsICdhY2Nlc3NpYmlsaXR5Jyk7XHJcbiAgICAgICAgaG93VG8uc2V0QXR0cmlidXRlKCdwYXJ0JywgJ2g0Jyk7XHJcbiAgICAgICAgZmVhdHVyZXNUaXRsZS5zZXRBdHRyaWJ1dGUoJ3BhcnQnLCAnaDQnKTtcclxuICAgICAgICBhY2Nlc3NpYmlsaXR5VGl0bGUuc2V0QXR0cmlidXRlKCdwYXJ0JywgJ2g0Jyk7XHJcblxyXG4gICAgICAgIC8vIENTUyBzdHlsaW5nXHJcbiAgICAgICAgY29uc3Qgc3R5bGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzdHlsZScpO1xyXG4gICAgICAgIHN0eWxlLnRleHRDb250ZW50ID0gYFxyXG4gICAgICAgICNhY2Nlc3NpYmlsaXR5LWNvbnRlbnQgbGl7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDAuMzkwNjI1dnc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICNhY2Nlc3NpYmlsaXR5LWNvbnRlbnQge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogMS44NzV2dztcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxdnc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICNhY2Nlc3NpYmlsaXR5IHtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICAgICAgY29sb3I6IHJnYig4NSwgODUsIDg1KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgI2ZlYXR1cmVzLWNvbnRlbnQgbGkge1xyXG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAwLjM5MDYyNXZ3O1xyXG4gICAgICAgIH1cclxuICAgICAgICAjZmVhdHVyZXMtY29udGVudCB7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDA7XHJcbiAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxLjg3NXZ3O1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDF2dztcclxuICAgICAgICB9XHJcbiAgICAgICAgI2ZlYXR1cmVzIHtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICAgICAgY29sb3I6IHJnYig4NSwgODUsIDg1KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgI2hvdy10by1jb250ZW50IGxpIHtcclxuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMC4zOTA2MjV2dztcclxuICAgICAgICB9XHJcbiAgICAgICAgI2hvdy10by1jb250ZW50IHtcclxuICAgICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDEuODc1dnc7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMXZ3O1xyXG4gICAgICAgIH1cclxuICAgICAgICAjaG93LXRvIHtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICAgICAgY29sb3I6IHJnYig4NSwgODUsIDg1KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaDQge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEuMTV2dztcclxuICAgICAgICAgICAgY29sb3I6IHJnYig4NSwgODUsIDg1KTtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICB9XHJcbiAgICAgICAgI2hlbHAtY29udGFpbmVyIHtcclxuICAgICAgICAgICAgd2lkdGg6IDg1JTtcclxuICAgICAgICAgICAgbWFyZ2luOiAwIGF1dG87XHJcbiAgICAgICAgICAgIC8vIGhlaWdodDogODAlO1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDI4LjEyNXZ3O1xyXG4gICAgICAgICAgICBvdmVyZmxvdzogYXV0bztcclxuICAgICAgICB9XHJcbiAgICAgICAgI2Nsb3NlLWljb24ge1xyXG4gICAgICAgICAgICAvLyB3aWR0aDogMTVweDtcclxuICAgICAgICAgICAgd2lkdGg6IDEuMTcxODc1dnc7XHJcbiAgICAgICAgICAgIC8vIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAgICAgICAgIC8vIG1hcmdpbi1yaWdodDogMTBweDtcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDogMC43ODEyNXZ3O1xyXG4gICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDAuNzgxMjV2dztcclxuICAgICAgICAgICAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgICAgICAgICAgIHRvcDowO1xyXG4gICAgICAgICAgICByaWdodDowO1xyXG4gICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgICAgIG9wYWNpdHk6IDAuMzM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICNjbG9zZS1pY29uOmhvdmVyIHtcclxuICAgICAgICAgICAgb3BhY2l0eTogMTtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxLjEpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAjaGVscC1wb3B1cCB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgICAgICAgICAgLy8gd2lkdGg6IDMwJTtcclxuICAgICAgICAgICAgLy8gd2lkdGg6IDUyJTtcclxuICAgICAgICAgICAgd2lkdGg6IDUxLjk1MzEyNXZ3O1xyXG4gICAgICAgICAgICAvLyBoZWlnaHQ6IDMwJTtcclxuICAgICAgICAgICAgaGVpZ2h0OiAzNS4xNTYyNXZ3O1xyXG4gICAgICAgICAgICAvLyBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDAuMzEyNXZ3O1xyXG4gICAgICAgICAgICB0b3A6MTglO1xyXG4gICAgICAgICAgICAvLyBsZWZ0OiAzNCU7XHJcbiAgICAgICAgICAgIGxlZnQ6IDI0JTtcclxuICAgICAgICAgICAgei1pbmRleDogOTk5O1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZXNtb2tlO1xyXG4gICAgICAgICAgICBib3gtc2hhZG93OiAwIDRweCA4cHggMCByZ2JhKDAsMCwwLDAuMiksMCA2cHggMjBweCAwIHJnYmEoMCwwLDAsMC4xOSk7XHJcbiAgICAgICAgICAgIC13ZWJraXQtYW5pbWF0aW9uLW5hbWU6IGFuaW1hdGV0b3A7IFxyXG4gICAgICAgICAgICAtd2Via2l0LWFuaW1hdGlvbi1kdXJhdGlvbjogMC4zcztcclxuICAgICAgICAgICAgYW5pbWF0aW9uLW5hbWU6IGFuaW1hdGV0b3A7XHJcbiAgICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogMC4zc1xyXG4gICAgICAgIH1cclxuICAgICAgICBALXdlYmtpdC1rZXlmcmFtZXMgYW5pbWF0ZXRvcCB7XHJcbiAgICAgICAgICAgIGZyb20ge3RvcDotMjAwcHg7IG9wYWNpdHk6MH0gXHJcbiAgICAgICAgICAgIHRvIHt0b3A6NzA7IG9wYWNpdHk6MX1cclxuICAgICAgICB9XHJcbiAgICAgICAgQGtleWZyYW1lcyBhbmltYXRldG9wIHtcclxuICAgICAgICAgICAgZnJvbSB7dG9wOi0yMDBweDsgb3BhY2l0eTowfVxyXG4gICAgICAgICAgICB0byB7dG9wOjcwOyBvcGFjaXR5OjF9XHJcbiAgICAgICAgfVxyXG4gICAgICAgICNoZWxwLXBvcHVwID4gaDN7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMS42dnc7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjZjM2MDYwO1xyXG4gICAgICAgICAgICBib3JkZXItYm90dG9tOiBzb2xpZCAxcHggI2QyZDJkMjtcclxuICAgICAgICAgICAgLy8gcGFkZGluZy1ib3R0b206IDVweDtcclxuICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDAuMzkwNjI1dnc7XHJcbiAgICAgICAgICAgIHdpZHRoOiA4NSU7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgICAgIC8vIG1hcmdpbjogMjBweCBhdXRvIDEwcHggYXV0bztcclxuICAgICAgICAgICAgbWFyZ2luOiAxLjU2MjV2dyBhdXRvIDAuNzgxMjV2dyBhdXRvO1xyXG4gICAgICAgIH1gO1xyXG4gICAgICAgIHNoYWRvdy5hcHBlbmRDaGlsZCh3cmFwcGVyKTtcclxuICAgICAgICBzaGFkb3cuYXBwZW5kQ2hpbGQoc3R5bGUpO1xyXG4gICAgfVxyXG59XHJcbmN1c3RvbUVsZW1lbnRzLmRlZmluZSgnaGVscC1wb3B1cCcsIEhlbHBQb3BVcCk7XHJcblxyXG53aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignbG9hZCcsICgpID0+IHtcclxuICAgIGNvbnN0IGhlbHBQb3BVcCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2hlbHAtcG9wdXAnKTtcclxuICAgIGhlbHBQb3BVcC5zZXRBdHRyaWJ1dGUoJ2NsYXNzJywgJ3BvcHVwJyk7XHJcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGhlbHBQb3BVcCk7XHJcbiAgICBjb25zdCBoZWxwQnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2hlbHAtYnV0dG9uJyk7XHJcbiAgICBoZWxwQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGJ0blNvdW5kID0gbmV3IEF1ZGlvKCcuL2ljb25zL2J0bkNsaWNrLm1wMycpO1xyXG4gICAgICAgIGJ0blNvdW5kLnZvbHVtZSA9IDAuMDEgKiBwYXJzZUludChsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndm9sdW1lJyksIDEwKTtcclxuICAgICAgICBidG5Tb3VuZC5wbGF5KCk7XHJcbiAgICAgICAgLy8gdGhpcyBtYWtlcyBzdXJlIGFueSBwb3B1cCBpcyBjbG9zZWQgYmVmb3JlIG9wZW5pbmcgY3VycmVudCBwb3B1cFxyXG4gICAgICAgIGNvbnN0IHBvcHVwcyA9IEFycmF5LmZyb20oZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZSgncG9wdXAnKSk7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwb3B1cHMubGVuZ3RoOyBpICs9IDEpIHtcclxuICAgICAgICAgICAgcG9wdXBzW2ldLmNsb3NlUG9wVXAoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaGVscFBvcFVwLnNoYWRvd1Jvb3QuZ2V0RWxlbWVudEJ5SWQoJ2hlbHAtcG9wdXAnKS5zZXRBdHRyaWJ1dGUoJ3N0eWxlJywgJ2Rpc3BsYXk6YmxvY2snKTtcclxuICAgIH0pO1xyXG59KTtcclxuIl19
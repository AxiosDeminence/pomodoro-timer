function cov_ew59zwzv7() {
  var path = "D:\\\u5B66\u4E60\\21WI\\CSE110\\cse110-w21-group13\\source\\src\\components\\TaskItem.js";
  var hash = "24a22dc8e7ce99cfe23b1f3b0637086adb87514b";
  var global = new Function("return this")();
  var gcv = "__coverage__";
  var coverageData = {
    path: "D:\\\u5B66\u4E60\\21WI\\CSE110\\cse110-w21-group13\\source\\src\\components\\TaskItem.js",
    statementMap: {
      "0": {
        start: {
          line: 5,
          column: 22
        },
        end: {
          line: 5,
          column: 63
        }
      },
      "1": {
        start: {
          line: 7,
          column: 24
        },
        end: {
          line: 7,
          column: 77
        }
      },
      "2": {
        start: {
          line: 8,
          column: 8
        },
        end: {
          line: 8,
          column: 47
        }
      },
      "3": {
        start: {
          line: 10,
          column: 21
        },
        end: {
          line: 10,
          column: 112
        }
      },
      "4": {
        start: {
          line: 10,
          column: 39
        },
        end: {
          line: 10,
          column: 111
        }
      },
      "5": {
        start: {
          line: 11,
          column: 8
        },
        end: {
          line: 14,
          column: 9
        }
      },
      "6": {
        start: {
          line: 12,
          column: 12
        },
        end: {
          line: 12,
          column: 41
        }
      },
      "7": {
        start: {
          line: 13,
          column: 12
        },
        end: {
          line: 13,
          column: 65
        }
      },
      "8": {
        start: {
          line: 19,
          column: 22
        },
        end: {
          line: 19,
          column: 63
        }
      },
      "9": {
        start: {
          line: 21,
          column: 8
        },
        end: {
          line: 21,
          column: 131
        }
      },
      "10": {
        start: {
          line: 21,
          column: 47
        },
        end: {
          line: 21,
          column: 125
        }
      },
      "11": {
        start: {
          line: 22,
          column: 8
        },
        end: {
          line: 22,
          column: 61
        }
      },
      "12": {
        start: {
          line: 24,
          column: 8
        },
        end: {
          line: 24,
          column: 42
        }
      },
      "13": {
        start: {
          line: 26,
          column: 25
        },
        end: {
          line: 26,
          column: 62
        }
      },
      "14": {
        start: {
          line: 27,
          column: 8
        },
        end: {
          line: 30,
          column: 9
        }
      },
      "15": {
        start: {
          line: 28,
          column: 26
        },
        end: {
          line: 28,
          column: 65
        }
      },
      "16": {
        start: {
          line: 29,
          column: 12
        },
        end: {
          line: 29,
          column: 33
        }
      },
      "17": {
        start: {
          line: 35,
          column: 8
        },
        end: {
          line: 35,
          column: 32
        }
      },
      "18": {
        start: {
          line: 37,
          column: 8
        },
        end: {
          line: 37,
          column: 42
        }
      },
      "19": {
        start: {
          line: 38,
          column: 22
        },
        end: {
          line: 38,
          column: 63
        }
      },
      "20": {
        start: {
          line: 39,
          column: 21
        },
        end: {
          line: 39,
          column: 112
        }
      },
      "21": {
        start: {
          line: 39,
          column: 39
        },
        end: {
          line: 39,
          column: 111
        }
      },
      "22": {
        start: {
          line: 40,
          column: 19
        },
        end: {
          line: 40,
          column: 64
        }
      },
      "23": {
        start: {
          line: 41,
          column: 22
        },
        end: {
          line: 41,
          column: 61
        }
      },
      "24": {
        start: {
          line: 42,
          column: 25
        },
        end: {
          line: 42,
          column: 62
        }
      },
      "25": {
        start: {
          line: 45,
          column: 8
        },
        end: {
          line: 99,
          column: 9
        }
      },
      "26": {
        start: {
          line: 47,
          column: 12
        },
        end: {
          line: 47,
          column: 33
        }
      },
      "27": {
        start: {
          line: 48,
          column: 12
        },
        end: {
          line: 48,
          column: 48
        }
      },
      "28": {
        start: {
          line: 50,
          column: 12
        },
        end: {
          line: 50,
          column: 33
        }
      },
      "29": {
        start: {
          line: 51,
          column: 12
        },
        end: {
          line: 51,
          column: 65
        }
      },
      "30": {
        start: {
          line: 53,
          column: 12
        },
        end: {
          line: 53,
          column: 33
        }
      },
      "31": {
        start: {
          line: 55,
          column: 12
        },
        end: {
          line: 77,
          column: 13
        }
      },
      "32": {
        start: {
          line: 56,
          column: 29
        },
        end: {
          line: 56,
          column: 77
        }
      },
      "33": {
        start: {
          line: 57,
          column: 30
        },
        end: {
          line: 57,
          column: 34
        }
      },
      "34": {
        start: {
          line: 58,
          column: 16
        },
        end: {
          line: 70,
          column: 17
        }
      },
      "35": {
        start: {
          line: 58,
          column: 29
        },
        end: {
          line: 58,
          column: 30
        }
      },
      "36": {
        start: {
          line: 60,
          column: 20
        },
        end: {
          line: 69,
          column: 21
        }
      },
      "37": {
        start: {
          line: 61,
          column: 24
        },
        end: {
          line: 61,
          column: 48
        }
      },
      "38": {
        start: {
          line: 62,
          column: 24
        },
        end: {
          line: 62,
          column: 54
        }
      },
      "39": {
        start: {
          line: 63,
          column: 24
        },
        end: {
          line: 63,
          column: 62
        }
      },
      "40": {
        start: {
          line: 64,
          column: 41
        },
        end: {
          line: 64,
          column: 138
        }
      },
      "41": {
        start: {
          line: 64,
          column: 59
        },
        end: {
          line: 64,
          column: 137
        }
      },
      "42": {
        start: {
          line: 65,
          column: 24
        },
        end: {
          line: 65,
          column: 48
        }
      },
      "43": {
        start: {
          line: 66,
          column: 24
        },
        end: {
          line: 66,
          column: 77
        }
      },
      "44": {
        start: {
          line: 67,
          column: 24
        },
        end: {
          line: 67,
          column: 40
        }
      },
      "45": {
        start: {
          line: 68,
          column: 24
        },
        end: {
          line: 68,
          column: 30
        }
      },
      "46": {
        start: {
          line: 72,
          column: 16
        },
        end: {
          line: 76,
          column: 17
        }
      },
      "47": {
        start: {
          line: 73,
          column: 20
        },
        end: {
          line: 73,
          column: 60
        }
      },
      "48": {
        start: {
          line: 75,
          column: 20
        },
        end: {
          line: 75,
          column: 53
        }
      },
      "49": {
        start: {
          line: 80,
          column: 12
        },
        end: {
          line: 80,
          column: 47
        }
      },
      "50": {
        start: {
          line: 81,
          column: 12
        },
        end: {
          line: 81,
          column: 32
        }
      },
      "51": {
        start: {
          line: 82,
          column: 12
        },
        end: {
          line: 82,
          column: 65
        }
      },
      "52": {
        start: {
          line: 83,
          column: 30
        },
        end: {
          line: 83,
          column: 65
        }
      },
      "53": {
        start: {
          line: 85,
          column: 12
        },
        end: {
          line: 96,
          column: 13
        }
      },
      "54": {
        start: {
          line: 86,
          column: 16
        },
        end: {
          line: 86,
          column: 43
        }
      },
      "55": {
        start: {
          line: 88,
          column: 16
        },
        end: {
          line: 88,
          column: 48
        }
      },
      "56": {
        start: {
          line: 89,
          column: 16
        },
        end: {
          line: 89,
          column: 42
        }
      },
      "57": {
        start: {
          line: 90,
          column: 16
        },
        end: {
          line: 90,
          column: 57
        }
      },
      "58": {
        start: {
          line: 91,
          column: 32
        },
        end: {
          line: 91,
          column: 133
        }
      },
      "59": {
        start: {
          line: 91,
          column: 50
        },
        end: {
          line: 91,
          column: 132
        }
      },
      "60": {
        start: {
          line: 92,
          column: 16
        },
        end: {
          line: 92,
          column: 40
        }
      },
      "61": {
        start: {
          line: 93,
          column: 16
        },
        end: {
          line: 93,
          column: 69
        }
      },
      "62": {
        start: {
          line: 95,
          column: 16
        },
        end: {
          line: 95,
          column: 43
        }
      },
      "63": {
        start: {
          line: 98,
          column: 12
        },
        end: {
          line: 98,
          column: 45
        }
      },
      "64": {
        start: {
          line: 104,
          column: 8
        },
        end: {
          line: 104,
          column: 16
        }
      },
      "65": {
        start: {
          line: 105,
          column: 23
        },
        end: {
          line: 105,
          column: 58
        }
      },
      "66": {
        start: {
          line: 111,
          column: 19
        },
        end: {
          line: 111,
          column: 47
        }
      },
      "67": {
        start: {
          line: 112,
          column: 8
        },
        end: {
          line: 112,
          column: 36
        }
      },
      "68": {
        start: {
          line: 113,
          column: 22
        },
        end: {
          line: 113,
          column: 51
        }
      },
      "69": {
        start: {
          line: 114,
          column: 8
        },
        end: {
          line: 114,
          column: 53
        }
      },
      "70": {
        start: {
          line: 115,
          column: 8
        },
        end: {
          line: 115,
          column: 50
        }
      },
      "71": {
        start: {
          line: 116,
          column: 8
        },
        end: {
          line: 116,
          column: 43
        }
      },
      "72": {
        start: {
          line: 117,
          column: 8
        },
        end: {
          line: 117,
          column: 30
        }
      },
      "73": {
        start: {
          line: 119,
          column: 8
        },
        end: {
          line: 119,
          column: 52
        }
      },
      "74": {
        start: {
          line: 120,
          column: 22
        },
        end: {
          line: 120,
          column: 51
        }
      },
      "75": {
        start: {
          line: 121,
          column: 8
        },
        end: {
          line: 121,
          column: 53
        }
      },
      "76": {
        start: {
          line: 122,
          column: 8
        },
        end: {
          line: 122,
          column: 50
        }
      },
      "77": {
        start: {
          line: 123,
          column: 8
        },
        end: {
          line: 123,
          column: 30
        }
      },
      "78": {
        start: {
          line: 125,
          column: 8
        },
        end: {
          line: 125,
          column: 63
        }
      },
      "79": {
        start: {
          line: 127,
          column: 22
        },
        end: {
          line: 127,
          column: 51
        }
      },
      "80": {
        start: {
          line: 128,
          column: 8
        },
        end: {
          line: 128,
          column: 54
        }
      },
      "81": {
        start: {
          line: 129,
          column: 8
        },
        end: {
          line: 129,
          column: 51
        }
      },
      "82": {
        start: {
          line: 130,
          column: 8
        },
        end: {
          line: 130,
          column: 30
        }
      },
      "83": {
        start: {
          line: 132,
          column: 8
        },
        end: {
          line: 132,
          column: 68
        }
      },
      "84": {
        start: {
          line: 134,
          column: 22
        },
        end: {
          line: 134,
          column: 53
        }
      },
      "85": {
        start: {
          line: 135,
          column: 8
        },
        end: {
          line: 225,
          column: 10
        }
      },
      "86": {
        start: {
          line: 226,
          column: 8
        },
        end: {
          line: 226,
          column: 31
        }
      },
      "87": {
        start: {
          line: 227,
          column: 8
        },
        end: {
          line: 227,
          column: 34
        }
      },
      "88": {
        start: {
          line: 231,
          column: 8
        },
        end: {
          line: 231,
          column: 24
        }
      },
      "89": {
        start: {
          line: 235,
          column: 23
        },
        end: {
          line: 235,
          column: 38
        }
      },
      "90": {
        start: {
          line: 236,
          column: 21
        },
        end: {
          line: 236,
          column: 52
        }
      },
      "91": {
        start: {
          line: 237,
          column: 8
        },
        end: {
          line: 237,
          column: 49
        }
      },
      "92": {
        start: {
          line: 241,
          column: 0
        },
        end: {
          line: 241,
          column: 45
        }
      }
    },
    fnMap: {
      "0": {
        name: "(anonymous_0)",
        decl: {
          start: {
            line: 4,
            column: 4
          },
          end: {
            line: 4,
            column: 5
          }
        },
        loc: {
          start: {
            line: 4,
            column: 13
          },
          end: {
            line: 15,
            column: 5
          }
        },
        line: 4
      },
      "1": {
        name: "(anonymous_1)",
        decl: {
          start: {
            line: 10,
            column: 32
          },
          end: {
            line: 10,
            column: 33
          }
        },
        loc: {
          start: {
            line: 10,
            column: 39
          },
          end: {
            line: 10,
            column: 111
          }
        },
        line: 10
      },
      "2": {
        name: "(anonymous_2)",
        decl: {
          start: {
            line: 18,
            column: 4
          },
          end: {
            line: 18,
            column: 5
          }
        },
        loc: {
          start: {
            line: 18,
            column: 17
          },
          end: {
            line: 31,
            column: 5
          }
        },
        line: 18
      },
      "3": {
        name: "(anonymous_3)",
        decl: {
          start: {
            line: 21,
            column: 37
          },
          end: {
            line: 21,
            column: 38
          }
        },
        loc: {
          start: {
            line: 21,
            column: 47
          },
          end: {
            line: 21,
            column: 125
          }
        },
        line: 21
      },
      "4": {
        name: "(anonymous_4)",
        decl: {
          start: {
            line: 34,
            column: 4
          },
          end: {
            line: 34,
            column: 5
          }
        },
        loc: {
          start: {
            line: 34,
            column: 17
          },
          end: {
            line: 100,
            column: 5
          }
        },
        line: 34
      },
      "5": {
        name: "(anonymous_5)",
        decl: {
          start: {
            line: 39,
            column: 32
          },
          end: {
            line: 39,
            column: 33
          }
        },
        loc: {
          start: {
            line: 39,
            column: 39
          },
          end: {
            line: 39,
            column: 111
          }
        },
        line: 39
      },
      "6": {
        name: "(anonymous_6)",
        decl: {
          start: {
            line: 64,
            column: 52
          },
          end: {
            line: 64,
            column: 53
          }
        },
        loc: {
          start: {
            line: 64,
            column: 59
          },
          end: {
            line: 64,
            column: 137
          }
        },
        line: 64
      },
      "7": {
        name: "(anonymous_7)",
        decl: {
          start: {
            line: 91,
            column: 43
          },
          end: {
            line: 91,
            column: 44
          }
        },
        loc: {
          start: {
            line: 91,
            column: 50
          },
          end: {
            line: 91,
            column: 132
          }
        },
        line: 91
      },
      "8": {
        name: "(anonymous_8)",
        decl: {
          start: {
            line: 103,
            column: 4
          },
          end: {
            line: 103,
            column: 5
          }
        },
        loc: {
          start: {
            line: 103,
            column: 18
          },
          end: {
            line: 228,
            column: 5
          }
        },
        line: 103
      },
      "9": {
        name: "(anonymous_9)",
        decl: {
          start: {
            line: 230,
            column: 4
          },
          end: {
            line: 230,
            column: 5
          }
        },
        loc: {
          start: {
            line: 230,
            column: 36
          },
          end: {
            line: 232,
            column: 5
          }
        },
        line: 230
      },
      "10": {
        name: "(anonymous_10)",
        decl: {
          start: {
            line: 234,
            column: 4
          },
          end: {
            line: 234,
            column: 5
          }
        },
        loc: {
          start: {
            line: 234,
            column: 55
          },
          end: {
            line: 238,
            column: 5
          }
        },
        line: 234
      }
    },
    branchMap: {
      "0": {
        loc: {
          start: {
            line: 10,
            column: 39
          },
          end: {
            line: 10,
            column: 111
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 10,
            column: 39
          },
          end: {
            line: 10,
            column: 71
          }
        }, {
          start: {
            line: 10,
            column: 75
          },
          end: {
            line: 10,
            column: 111
          }
        }],
        line: 10
      },
      "1": {
        loc: {
          start: {
            line: 11,
            column: 8
          },
          end: {
            line: 14,
            column: 9
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 11,
            column: 8
          },
          end: {
            line: 14,
            column: 9
          }
        }, {
          start: {
            line: 11,
            column: 8
          },
          end: {
            line: 14,
            column: 9
          }
        }],
        line: 11
      },
      "2": {
        loc: {
          start: {
            line: 21,
            column: 47
          },
          end: {
            line: 21,
            column: 125
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 21,
            column: 47
          },
          end: {
            line: 21,
            column: 82
          }
        }, {
          start: {
            line: 21,
            column: 86
          },
          end: {
            line: 21,
            column: 125
          }
        }],
        line: 21
      },
      "3": {
        loc: {
          start: {
            line: 27,
            column: 8
          },
          end: {
            line: 30,
            column: 9
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 27,
            column: 8
          },
          end: {
            line: 30,
            column: 9
          }
        }, {
          start: {
            line: 27,
            column: 8
          },
          end: {
            line: 30,
            column: 9
          }
        }],
        line: 27
      },
      "4": {
        loc: {
          start: {
            line: 39,
            column: 39
          },
          end: {
            line: 39,
            column: 111
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 39,
            column: 39
          },
          end: {
            line: 39,
            column: 71
          }
        }, {
          start: {
            line: 39,
            column: 75
          },
          end: {
            line: 39,
            column: 111
          }
        }],
        line: 39
      },
      "5": {
        loc: {
          start: {
            line: 45,
            column: 8
          },
          end: {
            line: 99,
            column: 9
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 45,
            column: 8
          },
          end: {
            line: 99,
            column: 9
          }
        }, {
          start: {
            line: 45,
            column: 8
          },
          end: {
            line: 99,
            column: 9
          }
        }],
        line: 45
      },
      "6": {
        loc: {
          start: {
            line: 55,
            column: 12
          },
          end: {
            line: 77,
            column: 13
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 55,
            column: 12
          },
          end: {
            line: 77,
            column: 13
          }
        }, {
          start: {
            line: 55,
            column: 12
          },
          end: {
            line: 77,
            column: 13
          }
        }],
        line: 55
      },
      "7": {
        loc: {
          start: {
            line: 60,
            column: 20
          },
          end: {
            line: 69,
            column: 21
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 60,
            column: 20
          },
          end: {
            line: 69,
            column: 21
          }
        }, {
          start: {
            line: 60,
            column: 20
          },
          end: {
            line: 69,
            column: 21
          }
        }],
        line: 60
      },
      "8": {
        loc: {
          start: {
            line: 64,
            column: 59
          },
          end: {
            line: 64,
            column: 137
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 64,
            column: 59
          },
          end: {
            line: 64,
            column: 94
          }
        }, {
          start: {
            line: 64,
            column: 98
          },
          end: {
            line: 64,
            column: 137
          }
        }],
        line: 64
      },
      "9": {
        loc: {
          start: {
            line: 72,
            column: 16
          },
          end: {
            line: 76,
            column: 17
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 72,
            column: 16
          },
          end: {
            line: 76,
            column: 17
          }
        }, {
          start: {
            line: 72,
            column: 16
          },
          end: {
            line: 76,
            column: 17
          }
        }],
        line: 72
      },
      "10": {
        loc: {
          start: {
            line: 85,
            column: 12
          },
          end: {
            line: 96,
            column: 13
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 85,
            column: 12
          },
          end: {
            line: 96,
            column: 13
          }
        }, {
          start: {
            line: 85,
            column: 12
          },
          end: {
            line: 96,
            column: 13
          }
        }],
        line: 85
      },
      "11": {
        loc: {
          start: {
            line: 91,
            column: 50
          },
          end: {
            line: 91,
            column: 132
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 91,
            column: 50
          },
          end: {
            line: 91,
            column: 87
          }
        }, {
          start: {
            line: 91,
            column: 91
          },
          end: {
            line: 91,
            column: 132
          }
        }],
        line: 91
      }
    },
    s: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0,
      "11": 0,
      "12": 0,
      "13": 0,
      "14": 0,
      "15": 0,
      "16": 0,
      "17": 0,
      "18": 0,
      "19": 0,
      "20": 0,
      "21": 0,
      "22": 0,
      "23": 0,
      "24": 0,
      "25": 0,
      "26": 0,
      "27": 0,
      "28": 0,
      "29": 0,
      "30": 0,
      "31": 0,
      "32": 0,
      "33": 0,
      "34": 0,
      "35": 0,
      "36": 0,
      "37": 0,
      "38": 0,
      "39": 0,
      "40": 0,
      "41": 0,
      "42": 0,
      "43": 0,
      "44": 0,
      "45": 0,
      "46": 0,
      "47": 0,
      "48": 0,
      "49": 0,
      "50": 0,
      "51": 0,
      "52": 0,
      "53": 0,
      "54": 0,
      "55": 0,
      "56": 0,
      "57": 0,
      "58": 0,
      "59": 0,
      "60": 0,
      "61": 0,
      "62": 0,
      "63": 0,
      "64": 0,
      "65": 0,
      "66": 0,
      "67": 0,
      "68": 0,
      "69": 0,
      "70": 0,
      "71": 0,
      "72": 0,
      "73": 0,
      "74": 0,
      "75": 0,
      "76": 0,
      "77": 0,
      "78": 0,
      "79": 0,
      "80": 0,
      "81": 0,
      "82": 0,
      "83": 0,
      "84": 0,
      "85": 0,
      "86": 0,
      "87": 0,
      "88": 0,
      "89": 0,
      "90": 0,
      "91": 0,
      "92": 0
    },
    f: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0
    },
    b: {
      "0": [0, 0],
      "1": [0, 0],
      "2": [0, 0],
      "3": [0, 0],
      "4": [0, 0],
      "5": [0, 0],
      "6": [0, 0],
      "7": [0, 0],
      "8": [0, 0],
      "9": [0, 0],
      "10": [0, 0],
      "11": [0, 0]
    },
    _coverageSchema: "1a1c01bbd47fc00a2c39e90264f33305004495a9",
    hash: "24a22dc8e7ce99cfe23b1f3b0637086adb87514b"
  };
  var coverage = global[gcv] || (global[gcv] = {});

  if (!coverage[path] || coverage[path].hash !== hash) {
    coverage[path] = coverageData;
  }

  var actualCoverage = coverage[path];
  {
    // @ts-ignore
    cov_ew59zwzv7 = function () {
      return actualCoverage;
    };
  }
  return actualCoverage;
}

cov_ew59zwzv7();

// creates a task list item
class TaskItem extends HTMLElement {
  // toggles custom attribute 'checked' for this element
  toggle() {
    cov_ew59zwzv7().f[0]++;
    const tasks = (cov_ew59zwzv7().s[0]++, JSON.parse(localStorage.getItem('tasks'))); // update checked attribute

    const checked = (cov_ew59zwzv7().s[1]++, this.getAttribute('checked').toLowerCase() === 'true');
    cov_ew59zwzv7().s[2]++;
    this.setAttribute('checked', !checked); // update task item in localStorage

    const task = (cov_ew59zwzv7().s[3]++, tasks.find(t => {
      cov_ew59zwzv7().f[1]++;
      cov_ew59zwzv7().s[4]++;
      return (cov_ew59zwzv7().b[0][0]++, t.id === this.getAttribute('id')) && (cov_ew59zwzv7().b[0][1]++, t.text === this.getAttribute('text'));
    }));
    cov_ew59zwzv7().s[5]++;

    if (typeof task !== 'undefined') {
      cov_ew59zwzv7().b[1][0]++;
      cov_ew59zwzv7().s[6]++;
      task.checked = !task.checked;
      cov_ew59zwzv7().s[7]++;
      localStorage.setItem('tasks', JSON.stringify(tasks));
    } else {
      cov_ew59zwzv7().b[1][1]++;
    }
  } // removes custom element from DOM and deletes task from localStorage


  removeTask() {
    cov_ew59zwzv7().f[2]++;
    const tasks = (cov_ew59zwzv7().s[8]++, JSON.parse(localStorage.getItem('tasks'))); // find and remove task from localStorage

    cov_ew59zwzv7().s[9]++;
    tasks.splice(tasks.findIndex(task => {
      cov_ew59zwzv7().f[3]++;
      cov_ew59zwzv7().s[10]++;
      return (cov_ew59zwzv7().b[2][0]++, task.id === this.getAttribute('id')) && (cov_ew59zwzv7().b[2][1]++, task.text === this.getAttribute('text'));
    }), 1);
    cov_ew59zwzv7().s[11]++;
    localStorage.setItem('tasks', JSON.stringify(tasks)); // remove this element from DOM

    cov_ew59zwzv7().s[12]++;
    this.parentNode.removeChild(this); // update focus task title if focus task no longer exists

    const focusDiv = (cov_ew59zwzv7().s[13]++, document.getElementById('focus-task'));
    cov_ew59zwzv7().s[14]++;

    if (focusDiv.querySelector('task-item') === null) {
      cov_ew59zwzv7().b[3][0]++;
      const title = (cov_ew59zwzv7().s[15]++, document.getElementById('select-focus'));
      cov_ew59zwzv7().s[16]++;
      title.innerHTML = '';
    } else {
      cov_ew59zwzv7().b[3][1]++;
    }
  } // allows user to focus on a task item


  focus(event) {
    cov_ew59zwzv7().f[4]++;
    cov_ew59zwzv7().s[17]++;
    event.stopPropagation(); // remove task item from parent

    cov_ew59zwzv7().s[18]++;
    this.parentNode.removeChild(this);
    const tasks = (cov_ew59zwzv7().s[19]++, JSON.parse(localStorage.getItem('tasks')));
    const task = (cov_ew59zwzv7().s[20]++, tasks.find(t => {
      cov_ew59zwzv7().f[5]++;
      cov_ew59zwzv7().s[21]++;
      return (cov_ew59zwzv7().b[4][0]++, t.id === this.getAttribute('id')) && (cov_ew59zwzv7().b[4][1]++, t.text === this.getAttribute('text'));
    }));
    const ul = (cov_ew59zwzv7().s[22]++, document.getElementById('task-list-elements'));
    const title = (cov_ew59zwzv7().s[23]++, document.getElementById('select-focus'));
    const focusDiv = (cov_ew59zwzv7().s[24]++, document.getElementById('focus-task')); // check if task is a current focus task item

    cov_ew59zwzv7().s[25]++;

    if (this.getAttribute('focused').toLowerCase() === 'true') {
      cov_ew59zwzv7().b[5][0]++;
      cov_ew59zwzv7().s[26]++;
      // append to end of list and set 'focused' to false
      ul.appendChild(this);
      cov_ew59zwzv7().s[27]++;
      this.setAttribute('focused', false); // update local storage

      cov_ew59zwzv7().s[28]++;
      task.focused = false;
      cov_ew59zwzv7().s[29]++;
      localStorage.setItem('tasks', JSON.stringify(tasks)); // remove title

      cov_ew59zwzv7().s[30]++;
      title.innerHTML = ''; // if in focus mode, queue in next task item

      cov_ew59zwzv7().s[31]++;

      if (localStorage.getItem('state') === 'focus') {
        cov_ew59zwzv7().b[6][0]++;
        const list = (cov_ew59zwzv7().s[32]++, Array.from(ul.getElementsByTagName('task-item')));
        let allDone = (cov_ew59zwzv7().s[33]++, true);
        cov_ew59zwzv7().s[34]++;

        for (let i = (cov_ew59zwzv7().s[35]++, 0); i < list.length; i += 1) {
          cov_ew59zwzv7().s[36]++;

          // if the next task item is unchecked, remove from task list and append to focus div
          if (list[i].getAttribute('checked').toLowerCase() === 'false') {
            cov_ew59zwzv7().b[7][0]++;
            cov_ew59zwzv7().s[37]++;
            ul.removeChild(list[i]);
            cov_ew59zwzv7().s[38]++;
            focusDiv.appendChild(list[i]);
            cov_ew59zwzv7().s[39]++;
            list[i].setAttribute('focused', true);
            const focusNow = (cov_ew59zwzv7().s[40]++, tasks.find(t => {
              cov_ew59zwzv7().f[6]++;
              cov_ew59zwzv7().s[41]++;
              return (cov_ew59zwzv7().b[8][0]++, t.id === list[i].getAttribute('id')) && (cov_ew59zwzv7().b[8][1]++, t.text === list[i].getAttribute('text'));
            }));
            cov_ew59zwzv7().s[42]++;
            focusNow.focused = true;
            cov_ew59zwzv7().s[43]++;
            localStorage.setItem('tasks', JSON.stringify(tasks));
            cov_ew59zwzv7().s[44]++;
            allDone = false;
            cov_ew59zwzv7().s[45]++;
            break;
          } else {
            cov_ew59zwzv7().b[7][1]++;
          }
        } // Notify user if all task items are checked


        cov_ew59zwzv7().s[46]++;

        if (allDone === true) {
          cov_ew59zwzv7().b[9][0]++;
          cov_ew59zwzv7().s[47]++;
          title.innerHTML = 'All tasks complete!';
        } else {
          cov_ew59zwzv7().b[9][1]++;
          cov_ew59zwzv7().s[48]++;
          title.innerHTML = 'Focusing on:';
        }
      } else {
        cov_ew59zwzv7().b[6][1]++;
      }
    } else {
      cov_ew59zwzv7().b[5][1]++;
      cov_ew59zwzv7().s[49]++;
      // update focused attribute
      this.setAttribute('focused', true);
      cov_ew59zwzv7().s[50]++;
      task.focused = true;
      cov_ew59zwzv7().s[51]++;
      localStorage.setItem('tasks', JSON.stringify(tasks));
      const focusTask = (cov_ew59zwzv7().s[52]++, focusDiv.querySelector('task-item')); // if there doesn't exist a focus task yet

      cov_ew59zwzv7().s[53]++;

      if (focusTask === null) {
        cov_ew59zwzv7().b[10][0]++;
        cov_ew59zwzv7().s[54]++;
        focusDiv.appendChild(this);
      } else {
        cov_ew59zwzv7().b[10][1]++;
        cov_ew59zwzv7().s[55]++;
        focusDiv.removeChild(focusTask);
        cov_ew59zwzv7().s[56]++;
        ul.appendChild(focusTask);
        cov_ew59zwzv7().s[57]++;
        focusTask.setAttribute('focused', false);
        const unfocus = (cov_ew59zwzv7().s[58]++, tasks.find(t => {
          cov_ew59zwzv7().f[7]++;
          cov_ew59zwzv7().s[59]++;
          return (cov_ew59zwzv7().b[11][0]++, t.id === focusTask.getAttribute('id')) && (cov_ew59zwzv7().b[11][1]++, t.text === focusTask.getAttribute('text'));
        }));
        cov_ew59zwzv7().s[60]++;
        unfocus.focused = false;
        cov_ew59zwzv7().s[61]++;
        localStorage.setItem('tasks', JSON.stringify(tasks)); // add 'this' task item to under clock display

        cov_ew59zwzv7().s[62]++;
        focusDiv.appendChild(this);
      } // update title


      cov_ew59zwzv7().s[63]++;
      title.innerHTML = 'Focusing on:';
    }
  }
  /* create task list item by building custom component */


  constructor() {
    cov_ew59zwzv7().f[8]++;
    cov_ew59zwzv7().s[64]++;
    super();
    const shadow = (cov_ew59zwzv7().s[65]++, this.attachShadow({
      mode: 'open'
    })); // set attributes
    // this.setAttribute('id', task.id);
    // this.setAttribute('checked', task.checked);
    // this.setAttribute('text', task.text);
    // create list node

    const li = (cov_ew59zwzv7().s[66]++, document.createElement('li'));
    cov_ew59zwzv7().s[67]++;
    li.setAttribute('id', 'li');
    const check = (cov_ew59zwzv7().s[68]++, document.createElement('img'));
    cov_ew59zwzv7().s[69]++;
    check.setAttribute('src', 'icons/check.svg');
    cov_ew59zwzv7().s[70]++;
    check.setAttribute('class', 'check-icon');
    cov_ew59zwzv7().s[71]++;
    check.setAttribute('part', 'test');
    cov_ew59zwzv7().s[72]++;
    li.appendChild(check); // add event listener such that clicking on element crosses out task

    cov_ew59zwzv7().s[73]++;
    this.addEventListener('click', this.toggle);
    const focus = (cov_ew59zwzv7().s[74]++, document.createElement('img'));
    cov_ew59zwzv7().s[75]++;
    focus.setAttribute('src', 'icons/focus.svg');
    cov_ew59zwzv7().s[76]++;
    focus.setAttribute('class', 'focus-icon');
    cov_ew59zwzv7().s[77]++;
    li.appendChild(focus); // add event listener to image to focus a task

    cov_ew59zwzv7().s[78]++;
    focus.addEventListener('click', this.focus.bind(this)); // create delete icon

    const trash = (cov_ew59zwzv7().s[79]++, document.createElement('img'));
    cov_ew59zwzv7().s[80]++;
    trash.setAttribute('src', 'icons/delete.svg');
    cov_ew59zwzv7().s[81]++;
    trash.setAttribute('class', 'delete-icon');
    cov_ew59zwzv7().s[82]++;
    li.appendChild(trash); // add event listener to image to remove task

    cov_ew59zwzv7().s[83]++;
    trash.addEventListener('click', this.removeTask.bind(this)); // CSS styling

    const style = (cov_ew59zwzv7().s[84]++, document.createElement('style'));
    cov_ew59zwzv7().s[85]++;
    style.textContent = `
        :host {
            cursor: pointer;
            //height: 50px;
            height: 3.90625vw;
            position: relative;
            // margin-bottom: 10px;
            // border-radius: 5px;
            border-radius: 0.390625vw;
            // margin-right: 20%;
            box-shadow: 0 4px 8px 0 rgb(0 0 0 / 20%);
            display: flex;
            align-items: center;
            // padding-left: 37px;
            padding-left: 2.890625vw;
            background-color: #f36060;
            color: white;
            // font-size: medium;
            font-size: 1.35vw;
            font-weight: 500;
            border-style:none;
            user-select: none;
            margin: 0 auto;
            // margin-bottom: 10px;
            margin-bottom: 0.78125vw;
        }
        :host(:hover) {
            box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
            transition: 0.3s;
        }
        :host([checked = 'true']) {
            background: #f3606060;
            text-decoration: line-through;
            -webkit-text-decoration: line-through;
        }
        :host([checked = 'true']) .check-icon {
            visibility: visible;
        }
        .check-icon {
            position: absolute;
            // left: 10px;
            left: 0.78125vw;
            vertical-align: middle;
            // width: 20px;
            // height: 20px;
            width: 1.5625vw;
            height: 1.5625vw;
            margin: 0;
            visibility: hidden;
        }
        :host(:hover) .delete-icon {
            visibility: visible;
        }
        .delete-icon {
            position: absolute;
            color: #fff;
            // right: 10px;
            right: 0.78125vw;
            vertical-align: middle;
            // width: 20px;
            // height: 20px;
            width: 1.5625vw;
            height: 1.5625vw;
            margin: 0;
            visibility: hidden;
        }
        .delete-icon:hover {
            transform: scale(1.3);
            filter:brightness(105%)
        }
        :host(:hover) .focus-icon {
            visibility: visible;
        }
        .focus-icon {
            position: absolute;
            color: #fff;
            // right: 40px;
            right: 3.125vw;
            vertical-align: middle;
            // width: 20px;
            // height: 20px;
            width: 1.5625vw;
            height: 1.5625vw;
            margin: 0;
            visibility: hidden;
        }
        .focus-icon:hover {
            transform: scale(1.3);
            filter:brightness(105%)
        }
        `;
    cov_ew59zwzv7().s[86]++;
    shadow.appendChild(li);
    cov_ew59zwzv7().s[87]++;
    shadow.appendChild(style);
  }

  static get observedAttributes() {
    cov_ew59zwzv7().f[9]++;
    cov_ew59zwzv7().s[88]++;
    return ['text'];
  }

  attributeChangedCallback(attrName, oldVal, newVal) {
    cov_ew59zwzv7().f[10]++;
    const shadow = (cov_ew59zwzv7().s[89]++, this.shadowRoot);
    const text = (cov_ew59zwzv7().s[90]++, document.createTextNode(newVal));
    cov_ew59zwzv7().s[91]++;
    shadow.getElementById('li').append(text);
  }

}

cov_ew59zwzv7().s[92]++;
customElements.define('task-item', TaskItem); // module.exports = TaskItem;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlRhc2tJdGVtLmpzIl0sIm5hbWVzIjpbIlRhc2tJdGVtIiwiSFRNTEVsZW1lbnQiLCJ0b2dnbGUiLCJ0YXNrcyIsIkpTT04iLCJwYXJzZSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJjaGVja2VkIiwiZ2V0QXR0cmlidXRlIiwidG9Mb3dlckNhc2UiLCJzZXRBdHRyaWJ1dGUiLCJ0YXNrIiwiZmluZCIsInQiLCJpZCIsInRleHQiLCJzZXRJdGVtIiwic3RyaW5naWZ5IiwicmVtb3ZlVGFzayIsInNwbGljZSIsImZpbmRJbmRleCIsInBhcmVudE5vZGUiLCJyZW1vdmVDaGlsZCIsImZvY3VzRGl2IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInF1ZXJ5U2VsZWN0b3IiLCJ0aXRsZSIsImlubmVySFRNTCIsImZvY3VzIiwiZXZlbnQiLCJzdG9wUHJvcGFnYXRpb24iLCJ1bCIsImFwcGVuZENoaWxkIiwiZm9jdXNlZCIsImxpc3QiLCJBcnJheSIsImZyb20iLCJnZXRFbGVtZW50c0J5VGFnTmFtZSIsImFsbERvbmUiLCJpIiwibGVuZ3RoIiwiZm9jdXNOb3ciLCJmb2N1c1Rhc2siLCJ1bmZvY3VzIiwiY29uc3RydWN0b3IiLCJzaGFkb3ciLCJhdHRhY2hTaGFkb3ciLCJtb2RlIiwibGkiLCJjcmVhdGVFbGVtZW50IiwiY2hlY2siLCJhZGRFdmVudExpc3RlbmVyIiwiYmluZCIsInRyYXNoIiwic3R5bGUiLCJ0ZXh0Q29udGVudCIsIm9ic2VydmVkQXR0cmlidXRlcyIsImF0dHJpYnV0ZUNoYW5nZWRDYWxsYmFjayIsImF0dHJOYW1lIiwib2xkVmFsIiwibmV3VmFsIiwic2hhZG93Um9vdCIsImNyZWF0ZVRleHROb2RlIiwiYXBwZW5kIiwiY3VzdG9tRWxlbWVudHMiLCJkZWZpbmUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBZVk7Ozs7Ozs7Ozs7QUFmWjtBQUNBLE1BQU1BLFFBQU4sU0FBdUJDLFdBQXZCLENBQW1DO0FBQy9CO0FBQ0FDLEVBQUFBLE1BQU0sR0FBRztBQUFBO0FBQ0wsVUFBTUMsS0FBSyw0QkFBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixPQUFyQixDQUFYLENBQUgsQ0FBWCxDQURLLENBRUw7O0FBQ0EsVUFBTUMsT0FBTyw0QkFBRyxLQUFLQyxZQUFMLENBQWtCLFNBQWxCLEVBQTZCQyxXQUE3QixPQUErQyxNQUFsRCxDQUFiO0FBSEs7QUFJTCxTQUFLQyxZQUFMLENBQWtCLFNBQWxCLEVBQTZCLENBQUNILE9BQTlCLEVBSkssQ0FLTDs7QUFDQSxVQUFNSSxJQUFJLDRCQUFHVCxLQUFLLENBQUNVLElBQU4sQ0FBWUMsQ0FBRCxJQUFPO0FBQUE7QUFBQTtBQUFBLHlDQUFBQSxDQUFDLENBQUNDLEVBQUYsS0FBUyxLQUFLTixZQUFMLENBQWtCLElBQWxCLENBQVQsaUNBQW9DSyxDQUFDLENBQUNFLElBQUYsS0FBVyxLQUFLUCxZQUFMLENBQWtCLE1BQWxCLENBQS9DO0FBQXdFLEtBQTFGLENBQUgsQ0FBVjtBQU5LOztBQU9MLFFBQUksT0FBT0csSUFBUCxLQUFnQixXQUFwQixFQUFpQztBQUFBO0FBQUE7QUFDN0JBLE1BQUFBLElBQUksQ0FBQ0osT0FBTCxHQUFlLENBQUNJLElBQUksQ0FBQ0osT0FBckI7QUFENkI7QUFFN0JGLE1BQUFBLFlBQVksQ0FBQ1csT0FBYixDQUFxQixPQUFyQixFQUE4QmIsSUFBSSxDQUFDYyxTQUFMLENBQWVmLEtBQWYsQ0FBOUI7QUFDSCxLQUhEO0FBQUE7QUFBQTtBQUlILEdBYjhCLENBZS9COzs7QUFDQWdCLEVBQUFBLFVBQVUsR0FBRztBQUFBO0FBQ1QsVUFBTWhCLEtBQUssNEJBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsT0FBckIsQ0FBWCxDQUFILENBQVgsQ0FEUyxDQUVUOztBQUZTO0FBR1RKLElBQUFBLEtBQUssQ0FBQ2lCLE1BQU4sQ0FBYWpCLEtBQUssQ0FBQ2tCLFNBQU4sQ0FBaUJULElBQUQsSUFBVTtBQUFBO0FBQUE7QUFBQSx5Q0FBQUEsSUFBSSxDQUFDRyxFQUFMLEtBQVksS0FBS04sWUFBTCxDQUFrQixJQUFsQixDQUFaLGlDQUF1Q0csSUFBSSxDQUFDSSxJQUFMLEtBQWMsS0FBS1AsWUFBTCxDQUFrQixNQUFsQixDQUFyRDtBQUE4RSxLQUF4RyxDQUFiLEVBQXdILENBQXhIO0FBSFM7QUFJVEgsSUFBQUEsWUFBWSxDQUFDVyxPQUFiLENBQXFCLE9BQXJCLEVBQThCYixJQUFJLENBQUNjLFNBQUwsQ0FBZWYsS0FBZixDQUE5QixFQUpTLENBS1Q7O0FBTFM7QUFNVCxTQUFLbUIsVUFBTCxDQUFnQkMsV0FBaEIsQ0FBNEIsSUFBNUIsRUFOUyxDQU9UOztBQUNBLFVBQU1DLFFBQVEsNkJBQUdDLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixZQUF4QixDQUFILENBQWQ7QUFSUzs7QUFTVCxRQUFJRixRQUFRLENBQUNHLGFBQVQsQ0FBdUIsV0FBdkIsTUFBd0MsSUFBNUMsRUFBa0Q7QUFBQTtBQUM5QyxZQUFNQyxLQUFLLDZCQUFHSCxRQUFRLENBQUNDLGNBQVQsQ0FBd0IsY0FBeEIsQ0FBSCxDQUFYO0FBRDhDO0FBRTlDRSxNQUFBQSxLQUFLLENBQUNDLFNBQU4sR0FBa0IsRUFBbEI7QUFDSCxLQUhEO0FBQUE7QUFBQTtBQUlILEdBN0I4QixDQStCL0I7OztBQUNBQyxFQUFBQSxLQUFLLENBQUNDLEtBQUQsRUFBUTtBQUFBO0FBQUE7QUFDVEEsSUFBQUEsS0FBSyxDQUFDQyxlQUFOLEdBRFMsQ0FFVDs7QUFGUztBQUdULFNBQUtWLFVBQUwsQ0FBZ0JDLFdBQWhCLENBQTRCLElBQTVCO0FBQ0EsVUFBTXBCLEtBQUssNkJBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsT0FBckIsQ0FBWCxDQUFILENBQVg7QUFDQSxVQUFNSyxJQUFJLDZCQUFHVCxLQUFLLENBQUNVLElBQU4sQ0FBWUMsQ0FBRCxJQUFPO0FBQUE7QUFBQTtBQUFBLHlDQUFBQSxDQUFDLENBQUNDLEVBQUYsS0FBUyxLQUFLTixZQUFMLENBQWtCLElBQWxCLENBQVQsaUNBQW9DSyxDQUFDLENBQUNFLElBQUYsS0FBVyxLQUFLUCxZQUFMLENBQWtCLE1BQWxCLENBQS9DO0FBQXdFLEtBQTFGLENBQUgsQ0FBVjtBQUNBLFVBQU13QixFQUFFLDZCQUFHUixRQUFRLENBQUNDLGNBQVQsQ0FBd0Isb0JBQXhCLENBQUgsQ0FBUjtBQUNBLFVBQU1FLEtBQUssNkJBQUdILFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixjQUF4QixDQUFILENBQVg7QUFDQSxVQUFNRixRQUFRLDZCQUFHQyxRQUFRLENBQUNDLGNBQVQsQ0FBd0IsWUFBeEIsQ0FBSCxDQUFkLENBUlMsQ0FVVDs7QUFWUzs7QUFXVCxRQUFJLEtBQUtqQixZQUFMLENBQWtCLFNBQWxCLEVBQTZCQyxXQUE3QixPQUErQyxNQUFuRCxFQUEyRDtBQUFBO0FBQUE7QUFDdkQ7QUFDQXVCLE1BQUFBLEVBQUUsQ0FBQ0MsV0FBSCxDQUFlLElBQWY7QUFGdUQ7QUFHdkQsV0FBS3ZCLFlBQUwsQ0FBa0IsU0FBbEIsRUFBNkIsS0FBN0IsRUFIdUQsQ0FJdkQ7O0FBSnVEO0FBS3ZEQyxNQUFBQSxJQUFJLENBQUN1QixPQUFMLEdBQWUsS0FBZjtBQUx1RDtBQU12RDdCLE1BQUFBLFlBQVksQ0FBQ1csT0FBYixDQUFxQixPQUFyQixFQUE4QmIsSUFBSSxDQUFDYyxTQUFMLENBQWVmLEtBQWYsQ0FBOUIsRUFOdUQsQ0FPdkQ7O0FBUHVEO0FBUXZEeUIsTUFBQUEsS0FBSyxDQUFDQyxTQUFOLEdBQWtCLEVBQWxCLENBUnVELENBU3ZEOztBQVR1RDs7QUFVdkQsVUFBSXZCLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixPQUFyQixNQUFrQyxPQUF0QyxFQUErQztBQUFBO0FBQzNDLGNBQU02QixJQUFJLDZCQUFHQyxLQUFLLENBQUNDLElBQU4sQ0FBV0wsRUFBRSxDQUFDTSxvQkFBSCxDQUF3QixXQUF4QixDQUFYLENBQUgsQ0FBVjtBQUNBLFlBQUlDLE9BQU8sNkJBQUcsSUFBSCxDQUFYO0FBRjJDOztBQUczQyxhQUFLLElBQUlDLENBQUMsNkJBQUcsQ0FBSCxDQUFWLEVBQWdCQSxDQUFDLEdBQUdMLElBQUksQ0FBQ00sTUFBekIsRUFBaUNELENBQUMsSUFBSSxDQUF0QyxFQUF5QztBQUFBOztBQUNyQztBQUNBLGNBQUlMLElBQUksQ0FBQ0ssQ0FBRCxDQUFKLENBQVFoQyxZQUFSLENBQXFCLFNBQXJCLEVBQWdDQyxXQUFoQyxPQUFrRCxPQUF0RCxFQUErRDtBQUFBO0FBQUE7QUFDM0R1QixZQUFBQSxFQUFFLENBQUNWLFdBQUgsQ0FBZWEsSUFBSSxDQUFDSyxDQUFELENBQW5CO0FBRDJEO0FBRTNEakIsWUFBQUEsUUFBUSxDQUFDVSxXQUFULENBQXFCRSxJQUFJLENBQUNLLENBQUQsQ0FBekI7QUFGMkQ7QUFHM0RMLFlBQUFBLElBQUksQ0FBQ0ssQ0FBRCxDQUFKLENBQVE5QixZQUFSLENBQXFCLFNBQXJCLEVBQWdDLElBQWhDO0FBQ0Esa0JBQU1nQyxRQUFRLDZCQUFHeEMsS0FBSyxDQUFDVSxJQUFOLENBQVlDLENBQUQsSUFBTztBQUFBO0FBQUE7QUFBQSxpREFBQUEsQ0FBQyxDQUFDQyxFQUFGLEtBQVNxQixJQUFJLENBQUNLLENBQUQsQ0FBSixDQUFRaEMsWUFBUixDQUFxQixJQUFyQixDQUFULGlDQUF1Q0ssQ0FBQyxDQUFDRSxJQUFGLEtBQVdvQixJQUFJLENBQUNLLENBQUQsQ0FBSixDQUFRaEMsWUFBUixDQUFxQixNQUFyQixDQUFsRDtBQUE4RSxhQUFoRyxDQUFILENBQWQ7QUFKMkQ7QUFLM0RrQyxZQUFBQSxRQUFRLENBQUNSLE9BQVQsR0FBbUIsSUFBbkI7QUFMMkQ7QUFNM0Q3QixZQUFBQSxZQUFZLENBQUNXLE9BQWIsQ0FBcUIsT0FBckIsRUFBOEJiLElBQUksQ0FBQ2MsU0FBTCxDQUFlZixLQUFmLENBQTlCO0FBTjJEO0FBTzNEcUMsWUFBQUEsT0FBTyxHQUFHLEtBQVY7QUFQMkQ7QUFRM0Q7QUFDSCxXQVREO0FBQUE7QUFBQTtBQVVILFNBZjBDLENBZ0IzQzs7O0FBaEIyQzs7QUFpQjNDLFlBQUlBLE9BQU8sS0FBSyxJQUFoQixFQUFzQjtBQUFBO0FBQUE7QUFDbEJaLFVBQUFBLEtBQUssQ0FBQ0MsU0FBTixHQUFrQixxQkFBbEI7QUFDSCxTQUZELE1BRU87QUFBQTtBQUFBO0FBQ0hELFVBQUFBLEtBQUssQ0FBQ0MsU0FBTixHQUFrQixjQUFsQjtBQUNIO0FBQ0osT0F0QkQ7QUFBQTtBQUFBO0FBdUJILEtBakNELE1BaUNPO0FBQUE7QUFBQTtBQUNIO0FBQ0EsV0FBS2xCLFlBQUwsQ0FBa0IsU0FBbEIsRUFBNkIsSUFBN0I7QUFGRztBQUdIQyxNQUFBQSxJQUFJLENBQUN1QixPQUFMLEdBQWUsSUFBZjtBQUhHO0FBSUg3QixNQUFBQSxZQUFZLENBQUNXLE9BQWIsQ0FBcUIsT0FBckIsRUFBOEJiLElBQUksQ0FBQ2MsU0FBTCxDQUFlZixLQUFmLENBQTlCO0FBQ0EsWUFBTXlDLFNBQVMsNkJBQUdwQixRQUFRLENBQUNHLGFBQVQsQ0FBdUIsV0FBdkIsQ0FBSCxDQUFmLENBTEcsQ0FNSDs7QUFORzs7QUFPSCxVQUFJaUIsU0FBUyxLQUFLLElBQWxCLEVBQXdCO0FBQUE7QUFBQTtBQUNwQnBCLFFBQUFBLFFBQVEsQ0FBQ1UsV0FBVCxDQUFxQixJQUFyQjtBQUNILE9BRkQsTUFFTztBQUFBO0FBQUE7QUFDSFYsUUFBQUEsUUFBUSxDQUFDRCxXQUFULENBQXFCcUIsU0FBckI7QUFERztBQUVIWCxRQUFBQSxFQUFFLENBQUNDLFdBQUgsQ0FBZVUsU0FBZjtBQUZHO0FBR0hBLFFBQUFBLFNBQVMsQ0FBQ2pDLFlBQVYsQ0FBdUIsU0FBdkIsRUFBa0MsS0FBbEM7QUFDQSxjQUFNa0MsT0FBTyw2QkFBRzFDLEtBQUssQ0FBQ1UsSUFBTixDQUFZQyxDQUFELElBQU87QUFBQTtBQUFBO0FBQUEsOENBQUFBLENBQUMsQ0FBQ0MsRUFBRixLQUFTNkIsU0FBUyxDQUFDbkMsWUFBVixDQUF1QixJQUF2QixDQUFULGtDQUF5Q0ssQ0FBQyxDQUFDRSxJQUFGLEtBQVc0QixTQUFTLENBQUNuQyxZQUFWLENBQXVCLE1BQXZCLENBQXBEO0FBQWtGLFNBQXBHLENBQUgsQ0FBYjtBQUpHO0FBS0hvQyxRQUFBQSxPQUFPLENBQUNWLE9BQVIsR0FBa0IsS0FBbEI7QUFMRztBQU1IN0IsUUFBQUEsWUFBWSxDQUFDVyxPQUFiLENBQXFCLE9BQXJCLEVBQThCYixJQUFJLENBQUNjLFNBQUwsQ0FBZWYsS0FBZixDQUE5QixFQU5HLENBT0g7O0FBUEc7QUFRSHFCLFFBQUFBLFFBQVEsQ0FBQ1UsV0FBVCxDQUFxQixJQUFyQjtBQUNILE9BbEJFLENBbUJIOzs7QUFuQkc7QUFvQkhOLE1BQUFBLEtBQUssQ0FBQ0MsU0FBTixHQUFrQixjQUFsQjtBQUNIO0FBQ0o7QUFFRDs7O0FBQ0FpQixFQUFBQSxXQUFXLEdBQUc7QUFBQTtBQUFBO0FBQ1Y7QUFDQSxVQUFNQyxNQUFNLDZCQUFHLEtBQUtDLFlBQUwsQ0FBa0I7QUFBRUMsTUFBQUEsSUFBSSxFQUFFO0FBQVIsS0FBbEIsQ0FBSCxDQUFaLENBRlUsQ0FHVjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFVBQU1DLEVBQUUsNkJBQUd6QixRQUFRLENBQUMwQixhQUFULENBQXVCLElBQXZCLENBQUgsQ0FBUjtBQVJVO0FBU1ZELElBQUFBLEVBQUUsQ0FBQ3ZDLFlBQUgsQ0FBZ0IsSUFBaEIsRUFBc0IsSUFBdEI7QUFDQSxVQUFNeUMsS0FBSyw2QkFBRzNCLFFBQVEsQ0FBQzBCLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBSCxDQUFYO0FBVlU7QUFXVkMsSUFBQUEsS0FBSyxDQUFDekMsWUFBTixDQUFtQixLQUFuQixFQUEwQixpQkFBMUI7QUFYVTtBQVlWeUMsSUFBQUEsS0FBSyxDQUFDekMsWUFBTixDQUFtQixPQUFuQixFQUE0QixZQUE1QjtBQVpVO0FBYVZ5QyxJQUFBQSxLQUFLLENBQUN6QyxZQUFOLENBQW1CLE1BQW5CLEVBQTJCLE1BQTNCO0FBYlU7QUFjVnVDLElBQUFBLEVBQUUsQ0FBQ2hCLFdBQUgsQ0FBZWtCLEtBQWYsRUFkVSxDQWVWOztBQWZVO0FBZ0JWLFNBQUtDLGdCQUFMLENBQXNCLE9BQXRCLEVBQStCLEtBQUtuRCxNQUFwQztBQUNBLFVBQU00QixLQUFLLDZCQUFHTCxRQUFRLENBQUMwQixhQUFULENBQXVCLEtBQXZCLENBQUgsQ0FBWDtBQWpCVTtBQWtCVnJCLElBQUFBLEtBQUssQ0FBQ25CLFlBQU4sQ0FBbUIsS0FBbkIsRUFBMEIsaUJBQTFCO0FBbEJVO0FBbUJWbUIsSUFBQUEsS0FBSyxDQUFDbkIsWUFBTixDQUFtQixPQUFuQixFQUE0QixZQUE1QjtBQW5CVTtBQW9CVnVDLElBQUFBLEVBQUUsQ0FBQ2hCLFdBQUgsQ0FBZUosS0FBZixFQXBCVSxDQXFCVjs7QUFyQlU7QUFzQlZBLElBQUFBLEtBQUssQ0FBQ3VCLGdCQUFOLENBQXVCLE9BQXZCLEVBQWdDLEtBQUt2QixLQUFMLENBQVd3QixJQUFYLENBQWdCLElBQWhCLENBQWhDLEVBdEJVLENBdUJWOztBQUNBLFVBQU1DLEtBQUssNkJBQUc5QixRQUFRLENBQUMwQixhQUFULENBQXVCLEtBQXZCLENBQUgsQ0FBWDtBQXhCVTtBQXlCVkksSUFBQUEsS0FBSyxDQUFDNUMsWUFBTixDQUFtQixLQUFuQixFQUEwQixrQkFBMUI7QUF6QlU7QUEwQlY0QyxJQUFBQSxLQUFLLENBQUM1QyxZQUFOLENBQW1CLE9BQW5CLEVBQTRCLGFBQTVCO0FBMUJVO0FBMkJWdUMsSUFBQUEsRUFBRSxDQUFDaEIsV0FBSCxDQUFlcUIsS0FBZixFQTNCVSxDQTRCVjs7QUE1QlU7QUE2QlZBLElBQUFBLEtBQUssQ0FBQ0YsZ0JBQU4sQ0FBdUIsT0FBdkIsRUFBZ0MsS0FBS2xDLFVBQUwsQ0FBZ0JtQyxJQUFoQixDQUFxQixJQUFyQixDQUFoQyxFQTdCVSxDQThCVjs7QUFDQSxVQUFNRSxLQUFLLDZCQUFHL0IsUUFBUSxDQUFDMEIsYUFBVCxDQUF1QixPQUF2QixDQUFILENBQVg7QUEvQlU7QUFnQ1ZLLElBQUFBLEtBQUssQ0FBQ0MsV0FBTixHQUFxQjtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0ExRlE7QUFoQ1U7QUEySFZWLElBQUFBLE1BQU0sQ0FBQ2IsV0FBUCxDQUFtQmdCLEVBQW5CO0FBM0hVO0FBNEhWSCxJQUFBQSxNQUFNLENBQUNiLFdBQVAsQ0FBbUJzQixLQUFuQjtBQUNIOztBQUU0QixhQUFsQkUsa0JBQWtCLEdBQUc7QUFBQTtBQUFBO0FBQzVCLFdBQU8sQ0FBQyxNQUFELENBQVA7QUFDSDs7QUFFREMsRUFBQUEsd0JBQXdCLENBQUNDLFFBQUQsRUFBV0MsTUFBWCxFQUFtQkMsTUFBbkIsRUFBMkI7QUFBQTtBQUMvQyxVQUFNZixNQUFNLDZCQUFHLEtBQUtnQixVQUFSLENBQVo7QUFDQSxVQUFNL0MsSUFBSSw2QkFBR1MsUUFBUSxDQUFDdUMsY0FBVCxDQUF3QkYsTUFBeEIsQ0FBSCxDQUFWO0FBRitDO0FBRy9DZixJQUFBQSxNQUFNLENBQUNyQixjQUFQLENBQXNCLElBQXRCLEVBQTRCdUMsTUFBNUIsQ0FBbUNqRCxJQUFuQztBQUNIOztBQTVPOEI7OztBQStPbkNrRCxjQUFjLENBQUNDLE1BQWYsQ0FBc0IsV0FBdEIsRUFBbUNuRSxRQUFuQyxFLENBRUEiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBjcmVhdGVzIGEgdGFzayBsaXN0IGl0ZW1cclxuY2xhc3MgVGFza0l0ZW0gZXh0ZW5kcyBIVE1MRWxlbWVudCB7XHJcbiAgICAvLyB0b2dnbGVzIGN1c3RvbSBhdHRyaWJ1dGUgJ2NoZWNrZWQnIGZvciB0aGlzIGVsZW1lbnRcclxuICAgIHRvZ2dsZSgpIHtcclxuICAgICAgICBjb25zdCB0YXNrcyA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3Rhc2tzJykpO1xyXG4gICAgICAgIC8vIHVwZGF0ZSBjaGVja2VkIGF0dHJpYnV0ZVxyXG4gICAgICAgIGNvbnN0IGNoZWNrZWQgPSB0aGlzLmdldEF0dHJpYnV0ZSgnY2hlY2tlZCcpLnRvTG93ZXJDYXNlKCkgPT09ICd0cnVlJztcclxuICAgICAgICB0aGlzLnNldEF0dHJpYnV0ZSgnY2hlY2tlZCcsICFjaGVja2VkKTtcclxuICAgICAgICAvLyB1cGRhdGUgdGFzayBpdGVtIGluIGxvY2FsU3RvcmFnZVxyXG4gICAgICAgIGNvbnN0IHRhc2sgPSB0YXNrcy5maW5kKCh0KSA9PiB0LmlkID09PSB0aGlzLmdldEF0dHJpYnV0ZSgnaWQnKSAmJiB0LnRleHQgPT09IHRoaXMuZ2V0QXR0cmlidXRlKCd0ZXh0JykpO1xyXG4gICAgICAgIGlmICh0eXBlb2YgdGFzayAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgdGFzay5jaGVja2VkID0gIXRhc2suY2hlY2tlZDtcclxuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3Rhc2tzJywgSlNPTi5zdHJpbmdpZnkodGFza3MpKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy8gcmVtb3ZlcyBjdXN0b20gZWxlbWVudCBmcm9tIERPTSBhbmQgZGVsZXRlcyB0YXNrIGZyb20gbG9jYWxTdG9yYWdlXHJcbiAgICByZW1vdmVUYXNrKCkge1xyXG4gICAgICAgIGNvbnN0IHRhc2tzID0gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndGFza3MnKSk7XHJcbiAgICAgICAgLy8gZmluZCBhbmQgcmVtb3ZlIHRhc2sgZnJvbSBsb2NhbFN0b3JhZ2VcclxuICAgICAgICB0YXNrcy5zcGxpY2UodGFza3MuZmluZEluZGV4KCh0YXNrKSA9PiB0YXNrLmlkID09PSB0aGlzLmdldEF0dHJpYnV0ZSgnaWQnKSAmJiB0YXNrLnRleHQgPT09IHRoaXMuZ2V0QXR0cmlidXRlKCd0ZXh0JykpLCAxKTtcclxuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgndGFza3MnLCBKU09OLnN0cmluZ2lmeSh0YXNrcykpO1xyXG4gICAgICAgIC8vIHJlbW92ZSB0aGlzIGVsZW1lbnQgZnJvbSBET01cclxuICAgICAgICB0aGlzLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQodGhpcyk7XHJcbiAgICAgICAgLy8gdXBkYXRlIGZvY3VzIHRhc2sgdGl0bGUgaWYgZm9jdXMgdGFzayBubyBsb25nZXIgZXhpc3RzXHJcbiAgICAgICAgY29uc3QgZm9jdXNEaXYgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZm9jdXMtdGFzaycpO1xyXG4gICAgICAgIGlmIChmb2N1c0Rpdi5xdWVyeVNlbGVjdG9yKCd0YXNrLWl0ZW0nKSA9PT0gbnVsbCkge1xyXG4gICAgICAgICAgICBjb25zdCB0aXRsZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzZWxlY3QtZm9jdXMnKTtcclxuICAgICAgICAgICAgdGl0bGUuaW5uZXJIVE1MID0gJyc7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIGFsbG93cyB1c2VyIHRvIGZvY3VzIG9uIGEgdGFzayBpdGVtXHJcbiAgICBmb2N1cyhldmVudCkge1xyXG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgICAgIC8vIHJlbW92ZSB0YXNrIGl0ZW0gZnJvbSBwYXJlbnRcclxuICAgICAgICB0aGlzLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQodGhpcyk7XHJcbiAgICAgICAgY29uc3QgdGFza3MgPSBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd0YXNrcycpKTtcclxuICAgICAgICBjb25zdCB0YXNrID0gdGFza3MuZmluZCgodCkgPT4gdC5pZCA9PT0gdGhpcy5nZXRBdHRyaWJ1dGUoJ2lkJykgJiYgdC50ZXh0ID09PSB0aGlzLmdldEF0dHJpYnV0ZSgndGV4dCcpKTtcclxuICAgICAgICBjb25zdCB1bCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0YXNrLWxpc3QtZWxlbWVudHMnKTtcclxuICAgICAgICBjb25zdCB0aXRsZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzZWxlY3QtZm9jdXMnKTtcclxuICAgICAgICBjb25zdCBmb2N1c0RpdiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdmb2N1cy10YXNrJyk7XHJcbiAgICAgIFxyXG4gICAgICAgIC8vIGNoZWNrIGlmIHRhc2sgaXMgYSBjdXJyZW50IGZvY3VzIHRhc2sgaXRlbVxyXG4gICAgICAgIGlmICh0aGlzLmdldEF0dHJpYnV0ZSgnZm9jdXNlZCcpLnRvTG93ZXJDYXNlKCkgPT09ICd0cnVlJykge1xyXG4gICAgICAgICAgICAvLyBhcHBlbmQgdG8gZW5kIG9mIGxpc3QgYW5kIHNldCAnZm9jdXNlZCcgdG8gZmFsc2VcclxuICAgICAgICAgICAgdWwuYXBwZW5kQ2hpbGQodGhpcyk7XHJcbiAgICAgICAgICAgIHRoaXMuc2V0QXR0cmlidXRlKCdmb2N1c2VkJywgZmFsc2UpO1xyXG4gICAgICAgICAgICAvLyB1cGRhdGUgbG9jYWwgc3RvcmFnZVxyXG4gICAgICAgICAgICB0YXNrLmZvY3VzZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3Rhc2tzJywgSlNPTi5zdHJpbmdpZnkodGFza3MpKTtcclxuICAgICAgICAgICAgLy8gcmVtb3ZlIHRpdGxlXHJcbiAgICAgICAgICAgIHRpdGxlLmlubmVySFRNTCA9ICcnO1xyXG4gICAgICAgICAgICAvLyBpZiBpbiBmb2N1cyBtb2RlLCBxdWV1ZSBpbiBuZXh0IHRhc2sgaXRlbVxyXG4gICAgICAgICAgICBpZiAobG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3N0YXRlJykgPT09ICdmb2N1cycpIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGxpc3QgPSBBcnJheS5mcm9tKHVsLmdldEVsZW1lbnRzQnlUYWdOYW1lKCd0YXNrLWl0ZW0nKSk7XHJcbiAgICAgICAgICAgICAgICBsZXQgYWxsRG9uZSA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxpc3QubGVuZ3RoOyBpICs9IDEpIHtcclxuICAgICAgICAgICAgICAgICAgICAvLyBpZiB0aGUgbmV4dCB0YXNrIGl0ZW0gaXMgdW5jaGVja2VkLCByZW1vdmUgZnJvbSB0YXNrIGxpc3QgYW5kIGFwcGVuZCB0byBmb2N1cyBkaXZcclxuICAgICAgICAgICAgICAgICAgICBpZiAobGlzdFtpXS5nZXRBdHRyaWJ1dGUoJ2NoZWNrZWQnKS50b0xvd2VyQ2FzZSgpID09PSAnZmFsc2UnKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVsLnJlbW92ZUNoaWxkKGxpc3RbaV0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb2N1c0Rpdi5hcHBlbmRDaGlsZChsaXN0W2ldKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGlzdFtpXS5zZXRBdHRyaWJ1dGUoJ2ZvY3VzZWQnLCB0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZm9jdXNOb3cgPSB0YXNrcy5maW5kKCh0KSA9PiB0LmlkID09PSBsaXN0W2ldLmdldEF0dHJpYnV0ZSgnaWQnKSAmJiB0LnRleHQgPT09IGxpc3RbaV0uZ2V0QXR0cmlidXRlKCd0ZXh0JykpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb2N1c05vdy5mb2N1c2VkID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3Rhc2tzJywgSlNPTi5zdHJpbmdpZnkodGFza3MpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWxsRG9uZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyBOb3RpZnkgdXNlciBpZiBhbGwgdGFzayBpdGVtcyBhcmUgY2hlY2tlZFxyXG4gICAgICAgICAgICAgICAgaWYgKGFsbERvbmUgPT09IHRydWUpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aXRsZS5pbm5lckhUTUwgPSAnQWxsIHRhc2tzIGNvbXBsZXRlISc7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlLmlubmVySFRNTCA9ICdGb2N1c2luZyBvbjonO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgLy8gdXBkYXRlIGZvY3VzZWQgYXR0cmlidXRlXHJcbiAgICAgICAgICAgIHRoaXMuc2V0QXR0cmlidXRlKCdmb2N1c2VkJywgdHJ1ZSk7XHJcbiAgICAgICAgICAgIHRhc2suZm9jdXNlZCA9IHRydWU7XHJcbiAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCd0YXNrcycsIEpTT04uc3RyaW5naWZ5KHRhc2tzKSk7XHJcbiAgICAgICAgICAgIGNvbnN0IGZvY3VzVGFzayA9IGZvY3VzRGl2LnF1ZXJ5U2VsZWN0b3IoJ3Rhc2staXRlbScpO1xyXG4gICAgICAgICAgICAvLyBpZiB0aGVyZSBkb2Vzbid0IGV4aXN0IGEgZm9jdXMgdGFzayB5ZXRcclxuICAgICAgICAgICAgaWYgKGZvY3VzVGFzayA9PT0gbnVsbCkge1xyXG4gICAgICAgICAgICAgICAgZm9jdXNEaXYuYXBwZW5kQ2hpbGQodGhpcyk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBmb2N1c0Rpdi5yZW1vdmVDaGlsZChmb2N1c1Rhc2spO1xyXG4gICAgICAgICAgICAgICAgdWwuYXBwZW5kQ2hpbGQoZm9jdXNUYXNrKTtcclxuICAgICAgICAgICAgICAgIGZvY3VzVGFzay5zZXRBdHRyaWJ1dGUoJ2ZvY3VzZWQnLCBmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICBjb25zdCB1bmZvY3VzID0gdGFza3MuZmluZCgodCkgPT4gdC5pZCA9PT0gZm9jdXNUYXNrLmdldEF0dHJpYnV0ZSgnaWQnKSAmJiB0LnRleHQgPT09IGZvY3VzVGFzay5nZXRBdHRyaWJ1dGUoJ3RleHQnKSk7XHJcbiAgICAgICAgICAgICAgICB1bmZvY3VzLmZvY3VzZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCd0YXNrcycsIEpTT04uc3RyaW5naWZ5KHRhc2tzKSk7XHJcbiAgICAgICAgICAgICAgICAvLyBhZGQgJ3RoaXMnIHRhc2sgaXRlbSB0byB1bmRlciBjbG9jayBkaXNwbGF5XHJcbiAgICAgICAgICAgICAgICBmb2N1c0Rpdi5hcHBlbmRDaGlsZCh0aGlzKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyB1cGRhdGUgdGl0bGVcclxuICAgICAgICAgICAgdGl0bGUuaW5uZXJIVE1MID0gJ0ZvY3VzaW5nIG9uOic7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qIGNyZWF0ZSB0YXNrIGxpc3QgaXRlbSBieSBidWlsZGluZyBjdXN0b20gY29tcG9uZW50ICovXHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgICBzdXBlcigpO1xyXG4gICAgICAgIGNvbnN0IHNoYWRvdyA9IHRoaXMuYXR0YWNoU2hhZG93KHsgbW9kZTogJ29wZW4nIH0pO1xyXG4gICAgICAgIC8vIHNldCBhdHRyaWJ1dGVzXHJcbiAgICAgICAgLy8gdGhpcy5zZXRBdHRyaWJ1dGUoJ2lkJywgdGFzay5pZCk7XHJcbiAgICAgICAgLy8gdGhpcy5zZXRBdHRyaWJ1dGUoJ2NoZWNrZWQnLCB0YXNrLmNoZWNrZWQpO1xyXG4gICAgICAgIC8vIHRoaXMuc2V0QXR0cmlidXRlKCd0ZXh0JywgdGFzay50ZXh0KTtcclxuICAgICAgICAvLyBjcmVhdGUgbGlzdCBub2RlXHJcbiAgICAgICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xyXG4gICAgICAgIGxpLnNldEF0dHJpYnV0ZSgnaWQnLCAnbGknKTtcclxuICAgICAgICBjb25zdCBjaGVjayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2ltZycpO1xyXG4gICAgICAgIGNoZWNrLnNldEF0dHJpYnV0ZSgnc3JjJywgJ2ljb25zL2NoZWNrLnN2ZycpO1xyXG4gICAgICAgIGNoZWNrLnNldEF0dHJpYnV0ZSgnY2xhc3MnLCAnY2hlY2staWNvbicpO1xyXG4gICAgICAgIGNoZWNrLnNldEF0dHJpYnV0ZSgncGFydCcsICd0ZXN0Jyk7XHJcbiAgICAgICAgbGkuYXBwZW5kQ2hpbGQoY2hlY2spO1xyXG4gICAgICAgIC8vIGFkZCBldmVudCBsaXN0ZW5lciBzdWNoIHRoYXQgY2xpY2tpbmcgb24gZWxlbWVudCBjcm9zc2VzIG91dCB0YXNrXHJcbiAgICAgICAgdGhpcy5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIHRoaXMudG9nZ2xlKTtcclxuICAgICAgICBjb25zdCBmb2N1cyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2ltZycpO1xyXG4gICAgICAgIGZvY3VzLnNldEF0dHJpYnV0ZSgnc3JjJywgJ2ljb25zL2ZvY3VzLnN2ZycpO1xyXG4gICAgICAgIGZvY3VzLnNldEF0dHJpYnV0ZSgnY2xhc3MnLCAnZm9jdXMtaWNvbicpO1xyXG4gICAgICAgIGxpLmFwcGVuZENoaWxkKGZvY3VzKTtcclxuICAgICAgICAvLyBhZGQgZXZlbnQgbGlzdGVuZXIgdG8gaW1hZ2UgdG8gZm9jdXMgYSB0YXNrXHJcbiAgICAgICAgZm9jdXMuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCB0aGlzLmZvY3VzLmJpbmQodGhpcykpO1xyXG4gICAgICAgIC8vIGNyZWF0ZSBkZWxldGUgaWNvblxyXG4gICAgICAgIGNvbnN0IHRyYXNoID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaW1nJyk7XHJcbiAgICAgICAgdHJhc2guc2V0QXR0cmlidXRlKCdzcmMnLCAnaWNvbnMvZGVsZXRlLnN2ZycpO1xyXG4gICAgICAgIHRyYXNoLnNldEF0dHJpYnV0ZSgnY2xhc3MnLCAnZGVsZXRlLWljb24nKTtcclxuICAgICAgICBsaS5hcHBlbmRDaGlsZCh0cmFzaCk7XHJcbiAgICAgICAgLy8gYWRkIGV2ZW50IGxpc3RlbmVyIHRvIGltYWdlIHRvIHJlbW92ZSB0YXNrXHJcbiAgICAgICAgdHJhc2guYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCB0aGlzLnJlbW92ZVRhc2suYmluZCh0aGlzKSk7XHJcbiAgICAgICAgLy8gQ1NTIHN0eWxpbmdcclxuICAgICAgICBjb25zdCBzdHlsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0eWxlJyk7XHJcbiAgICAgICAgc3R5bGUudGV4dENvbnRlbnQgPSBgXHJcbiAgICAgICAgOmhvc3Qge1xyXG4gICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgICAgIC8vaGVpZ2h0OiA1MHB4O1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDMuOTA2MjV2dztcclxuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgICAgICAvLyBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gICAgICAgICAgICAvLyBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDAuMzkwNjI1dnc7XHJcbiAgICAgICAgICAgIC8vIG1hcmdpbi1yaWdodDogMjAlO1xyXG4gICAgICAgICAgICBib3gtc2hhZG93OiAwIDRweCA4cHggMCByZ2IoMCAwIDAgLyAyMCUpO1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICAvLyBwYWRkaW5nLWxlZnQ6IDM3cHg7XHJcbiAgICAgICAgICAgIHBhZGRpbmctbGVmdDogMi44OTA2MjV2dztcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2YzNjA2MDtcclxuICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgICAgICAvLyBmb250LXNpemU6IG1lZGl1bTtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxLjM1dnc7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgICAgIGJvcmRlci1zdHlsZTpub25lO1xyXG4gICAgICAgICAgICB1c2VyLXNlbGVjdDogbm9uZTtcclxuICAgICAgICAgICAgbWFyZ2luOiAwIGF1dG87XHJcbiAgICAgICAgICAgIC8vIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDAuNzgxMjV2dztcclxuICAgICAgICB9XHJcbiAgICAgICAgOmhvc3QoOmhvdmVyKSB7XHJcbiAgICAgICAgICAgIGJveC1zaGFkb3c6IDAgOHB4IDE2cHggMCByZ2JhKDAsMCwwLDAuMik7XHJcbiAgICAgICAgICAgIHRyYW5zaXRpb246IDAuM3M7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIDpob3N0KFtjaGVja2VkID0gJ3RydWUnXSkge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZjM2MDYwNjA7XHJcbiAgICAgICAgICAgIHRleHQtZGVjb3JhdGlvbjogbGluZS10aHJvdWdoO1xyXG4gICAgICAgICAgICAtd2Via2l0LXRleHQtZGVjb3JhdGlvbjogbGluZS10aHJvdWdoO1xyXG4gICAgICAgIH1cclxuICAgICAgICA6aG9zdChbY2hlY2tlZCA9ICd0cnVlJ10pIC5jaGVjay1pY29uIHtcclxuICAgICAgICAgICAgdmlzaWJpbGl0eTogdmlzaWJsZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLmNoZWNrLWljb24ge1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgIC8vIGxlZnQ6IDEwcHg7XHJcbiAgICAgICAgICAgIGxlZnQ6IDAuNzgxMjV2dztcclxuICAgICAgICAgICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxuICAgICAgICAgICAgLy8gd2lkdGg6IDIwcHg7XHJcbiAgICAgICAgICAgIC8vIGhlaWdodDogMjBweDtcclxuICAgICAgICAgICAgd2lkdGg6IDEuNTYyNXZ3O1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDEuNTYyNXZ3O1xyXG4gICAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk6IGhpZGRlbjtcclxuICAgICAgICB9XHJcbiAgICAgICAgOmhvc3QoOmhvdmVyKSAuZGVsZXRlLWljb24ge1xyXG4gICAgICAgICAgICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xyXG4gICAgICAgIH1cclxuICAgICAgICAuZGVsZXRlLWljb24ge1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgICAgICAvLyByaWdodDogMTBweDtcclxuICAgICAgICAgICAgcmlnaHQ6IDAuNzgxMjV2dztcclxuICAgICAgICAgICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxuICAgICAgICAgICAgLy8gd2lkdGg6IDIwcHg7XHJcbiAgICAgICAgICAgIC8vIGhlaWdodDogMjBweDtcclxuICAgICAgICAgICAgd2lkdGg6IDEuNTYyNXZ3O1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDEuNTYyNXZ3O1xyXG4gICAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk6IGhpZGRlbjtcclxuICAgICAgICB9XHJcbiAgICAgICAgLmRlbGV0ZS1pY29uOmhvdmVyIHtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxLjMpO1xyXG4gICAgICAgICAgICBmaWx0ZXI6YnJpZ2h0bmVzcygxMDUlKVxyXG4gICAgICAgIH1cclxuICAgICAgICA6aG9zdCg6aG92ZXIpIC5mb2N1cy1pY29uIHtcclxuICAgICAgICAgICAgdmlzaWJpbGl0eTogdmlzaWJsZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLmZvY3VzLWljb24ge1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgICAgICAvLyByaWdodDogNDBweDtcclxuICAgICAgICAgICAgcmlnaHQ6IDMuMTI1dnc7XHJcbiAgICAgICAgICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbiAgICAgICAgICAgIC8vIHdpZHRoOiAyMHB4O1xyXG4gICAgICAgICAgICAvLyBoZWlnaHQ6IDIwcHg7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxLjU2MjV2dztcclxuICAgICAgICAgICAgaGVpZ2h0OiAxLjU2MjV2dztcclxuICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgICB2aXNpYmlsaXR5OiBoaWRkZW47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5mb2N1cy1pY29uOmhvdmVyIHtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxLjMpO1xyXG4gICAgICAgICAgICBmaWx0ZXI6YnJpZ2h0bmVzcygxMDUlKVxyXG4gICAgICAgIH1cclxuICAgICAgICBgO1xyXG4gICAgICAgIHNoYWRvdy5hcHBlbmRDaGlsZChsaSk7XHJcbiAgICAgICAgc2hhZG93LmFwcGVuZENoaWxkKHN0eWxlKTtcclxuICAgIH1cclxuXHJcbiAgICBzdGF0aWMgZ2V0IG9ic2VydmVkQXR0cmlidXRlcygpIHtcclxuICAgICAgICByZXR1cm4gWyd0ZXh0J107XHJcbiAgICB9XHJcblxyXG4gICAgYXR0cmlidXRlQ2hhbmdlZENhbGxiYWNrKGF0dHJOYW1lLCBvbGRWYWwsIG5ld1ZhbCkge1xyXG4gICAgICAgIGNvbnN0IHNoYWRvdyA9IHRoaXMuc2hhZG93Um9vdDtcclxuICAgICAgICBjb25zdCB0ZXh0ID0gZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUobmV3VmFsKTtcclxuICAgICAgICBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ2xpJykuYXBwZW5kKHRleHQpO1xyXG4gICAgfVxyXG59XHJcblxyXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ3Rhc2staXRlbScsIFRhc2tJdGVtKTtcclxuXHJcbi8vIG1vZHVsZS5leHBvcnRzID0gVGFza0l0ZW07XHJcbiJdfQ==
function cov_2f0kcm3qn9() {
  var path = "D:\\\u5B66\u4E60\\21WI\\CSE110\\cse110-w21-group13\\source\\src\\components\\ResetPopUp.js";
  var hash = "c1fd64e9d3226eb6d8796d59b8ceeb6ce247c02c";
  var global = new Function("return this")();
  var gcv = "__coverage__";
  var coverageData = {
    path: "D:\\\u5B66\u4E60\\21WI\\CSE110\\cse110-w21-group13\\source\\src\\components\\ResetPopUp.js",
    statementMap: {
      "0": {
        start: {
          line: 4,
          column: 8
        },
        end: {
          line: 4,
          column: 45
        }
      },
      "1": {
        start: {
          line: 5,
          column: 25
        },
        end: {
          line: 5,
          column: 116
        }
      },
      "2": {
        start: {
          line: 6,
          column: 8
        },
        end: {
          line: 8,
          column: 9
        }
      },
      "3": {
        start: {
          line: 6,
          column: 21
        },
        end: {
          line: 6,
          column: 22
        }
      },
      "4": {
        start: {
          line: 7,
          column: 12
        },
        end: {
          line: 7,
          column: 37
        }
      },
      "5": {
        start: {
          line: 10,
          column: 26
        },
        end: {
          line: 10,
          column: 90
        }
      },
      "6": {
        start: {
          line: 11,
          column: 8
        },
        end: {
          line: 13,
          column: 9
        }
      },
      "7": {
        start: {
          line: 12,
          column: 12
        },
        end: {
          line: 12,
          column: 35
        }
      },
      "8": {
        start: {
          line: 14,
          column: 8
        },
        end: {
          line: 14,
          column: 43
        }
      },
      "9": {
        start: {
          line: 15,
          column: 25
        },
        end: {
          line: 15,
          column: 58
        }
      },
      "10": {
        start: {
          line: 16,
          column: 8
        },
        end: {
          line: 16,
          column: 78
        }
      },
      "11": {
        start: {
          line: 17,
          column: 8
        },
        end: {
          line: 17,
          column: 24
        }
      },
      "12": {
        start: {
          line: 18,
          column: 8
        },
        end: {
          line: 18,
          column: 26
        }
      },
      "13": {
        start: {
          line: 22,
          column: 24
        },
        end: {
          line: 22,
          column: 77
        }
      },
      "14": {
        start: {
          line: 23,
          column: 8
        },
        end: {
          line: 23,
          column: 39
        }
      },
      "15": {
        start: {
          line: 27,
          column: 8
        },
        end: {
          line: 27,
          column: 16
        }
      },
      "16": {
        start: {
          line: 28,
          column: 23
        },
        end: {
          line: 28,
          column: 58
        }
      },
      "17": {
        start: {
          line: 30,
          column: 24
        },
        end: {
          line: 30,
          column: 53
        }
      },
      "18": {
        start: {
          line: 31,
          column: 8
        },
        end: {
          line: 31,
          column: 58
        }
      },
      "19": {
        start: {
          line: 33,
          column: 22
        },
        end: {
          line: 33,
          column: 72
        }
      },
      "20": {
        start: {
          line: 34,
          column: 8
        },
        end: {
          line: 34,
          column: 53
        }
      },
      "21": {
        start: {
          line: 35,
          column: 8
        },
        end: {
          line: 35,
          column: 47
        }
      },
      "22": {
        start: {
          line: 37,
          column: 22
        },
        end: {
          line: 37,
          column: 71
        }
      },
      "23": {
        start: {
          line: 38,
          column: 8
        },
        end: {
          line: 38,
          column: 42
        }
      },
      "24": {
        start: {
          line: 40,
          column: 24
        },
        end: {
          line: 40,
          column: 73
        }
      },
      "25": {
        start: {
          line: 41,
          column: 8
        },
        end: {
          line: 41,
          column: 52
        }
      },
      "26": {
        start: {
          line: 42,
          column: 8
        },
        end: {
          line: 42,
          column: 108
        }
      },
      "27": {
        start: {
          line: 44,
          column: 23
        },
        end: {
          line: 44,
          column: 73
        }
      },
      "28": {
        start: {
          line: 45,
          column: 8
        },
        end: {
          line: 45,
          column: 54
        }
      },
      "29": {
        start: {
          line: 46,
          column: 27
        },
        end: {
          line: 46,
          column: 79
        }
      },
      "30": {
        start: {
          line: 47,
          column: 8
        },
        end: {
          line: 47,
          column: 61
        }
      },
      "31": {
        start: {
          line: 48,
          column: 8
        },
        end: {
          line: 48,
          column: 59
        }
      },
      "32": {
        start: {
          line: 49,
          column: 8
        },
        end: {
          line: 49,
          column: 41
        }
      },
      "33": {
        start: {
          line: 51,
          column: 8
        },
        end: {
          line: 51,
          column: 68
        }
      },
      "34": {
        start: {
          line: 52,
          column: 8
        },
        end: {
          line: 52,
          column: 68
        }
      },
      "35": {
        start: {
          line: 54,
          column: 8
        },
        end: {
          line: 54,
          column: 54
        }
      },
      "36": {
        start: {
          line: 55,
          column: 8
        },
        end: {
          line: 55,
          column: 49
        }
      },
      "37": {
        start: {
          line: 56,
          column: 8
        },
        end: {
          line: 56,
          column: 55
        }
      },
      "38": {
        start: {
          line: 57,
          column: 8
        },
        end: {
          line: 57,
          column: 54
        }
      },
      "39": {
        start: {
          line: 58,
          column: 8
        },
        end: {
          line: 58,
          column: 50
        }
      },
      "40": {
        start: {
          line: 59,
          column: 8
        },
        end: {
          line: 59,
          column: 55
        }
      },
      "41": {
        start: {
          line: 61,
          column: 22
        },
        end: {
          line: 61,
          column: 53
        }
      },
      "42": {
        start: {
          line: 62,
          column: 8
        },
        end: {
          line: 169,
          column: 11
        }
      },
      "43": {
        start: {
          line: 170,
          column: 8
        },
        end: {
          line: 170,
          column: 36
        }
      },
      "44": {
        start: {
          line: 171,
          column: 8
        },
        end: {
          line: 171,
          column: 34
        }
      },
      "45": {
        start: {
          line: 174,
          column: 0
        },
        end: {
          line: 174,
          column: 49
        }
      },
      "46": {
        start: {
          line: 176,
          column: 0
        },
        end: {
          line: 192,
          column: 3
        }
      },
      "47": {
        start: {
          line: 177,
          column: 23
        },
        end: {
          line: 177,
          column: 60
        }
      },
      "48": {
        start: {
          line: 178,
          column: 4
        },
        end: {
          line: 178,
          column: 46
        }
      },
      "49": {
        start: {
          line: 179,
          column: 4
        },
        end: {
          line: 179,
          column: 42
        }
      },
      "50": {
        start: {
          line: 180,
          column: 21
        },
        end: {
          line: 180,
          column: 60
        }
      },
      "51": {
        start: {
          line: 181,
          column: 4
        },
        end: {
          line: 191,
          column: 7
        }
      },
      "52": {
        start: {
          line: 182,
          column: 25
        },
        end: {
          line: 182,
          column: 58
        }
      },
      "53": {
        start: {
          line: 183,
          column: 8
        },
        end: {
          line: 183,
          column: 78
        }
      },
      "54": {
        start: {
          line: 184,
          column: 8
        },
        end: {
          line: 184,
          column: 24
        }
      },
      "55": {
        start: {
          line: 186,
          column: 23
        },
        end: {
          line: 186,
          column: 75
        }
      },
      "56": {
        start: {
          line: 187,
          column: 8
        },
        end: {
          line: 189,
          column: 9
        }
      },
      "57": {
        start: {
          line: 187,
          column: 21
        },
        end: {
          line: 187,
          column: 22
        }
      },
      "58": {
        start: {
          line: 188,
          column: 12
        },
        end: {
          line: 188,
          column: 35
        }
      },
      "59": {
        start: {
          line: 190,
          column: 8
        },
        end: {
          line: 190,
          column: 107
        }
      }
    },
    fnMap: {
      "0": {
        name: "(anonymous_0)",
        decl: {
          start: {
            line: 2,
            column: 4
          },
          end: {
            line: 2,
            column: 5
          }
        },
        loc: {
          start: {
            line: 2,
            column: 12
          },
          end: {
            line: 19,
            column: 5
          }
        },
        line: 2
      },
      "1": {
        name: "(anonymous_1)",
        decl: {
          start: {
            line: 21,
            column: 4
          },
          end: {
            line: 21,
            column: 5
          }
        },
        loc: {
          start: {
            line: 21,
            column: 17
          },
          end: {
            line: 24,
            column: 5
          }
        },
        line: 21
      },
      "2": {
        name: "(anonymous_2)",
        decl: {
          start: {
            line: 26,
            column: 4
          },
          end: {
            line: 26,
            column: 5
          }
        },
        loc: {
          start: {
            line: 26,
            column: 18
          },
          end: {
            line: 172,
            column: 5
          }
        },
        line: 26
      },
      "3": {
        name: "(anonymous_3)",
        decl: {
          start: {
            line: 176,
            column: 32
          },
          end: {
            line: 176,
            column: 33
          }
        },
        loc: {
          start: {
            line: 176,
            column: 38
          },
          end: {
            line: 192,
            column: 1
          }
        },
        line: 176
      },
      "4": {
        name: "(anonymous_4)",
        decl: {
          start: {
            line: 181,
            column: 39
          },
          end: {
            line: 181,
            column: 40
          }
        },
        loc: {
          start: {
            line: 181,
            column: 45
          },
          end: {
            line: 191,
            column: 5
          }
        },
        line: 181
      }
    },
    branchMap: {
      "0": {
        loc: {
          start: {
            line: 11,
            column: 8
          },
          end: {
            line: 13,
            column: 9
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 11,
            column: 8
          },
          end: {
            line: 13,
            column: 9
          }
        }, {
          start: {
            line: 11,
            column: 8
          },
          end: {
            line: 13,
            column: 9
          }
        }],
        line: 11
      }
    },
    s: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0,
      "11": 0,
      "12": 0,
      "13": 0,
      "14": 0,
      "15": 0,
      "16": 0,
      "17": 0,
      "18": 0,
      "19": 0,
      "20": 0,
      "21": 0,
      "22": 0,
      "23": 0,
      "24": 0,
      "25": 0,
      "26": 0,
      "27": 0,
      "28": 0,
      "29": 0,
      "30": 0,
      "31": 0,
      "32": 0,
      "33": 0,
      "34": 0,
      "35": 0,
      "36": 0,
      "37": 0,
      "38": 0,
      "39": 0,
      "40": 0,
      "41": 0,
      "42": 0,
      "43": 0,
      "44": 0,
      "45": 0,
      "46": 0,
      "47": 0,
      "48": 0,
      "49": 0,
      "50": 0,
      "51": 0,
      "52": 0,
      "53": 0,
      "54": 0,
      "55": 0,
      "56": 0,
      "57": 0,
      "58": 0,
      "59": 0
    },
    f: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0
    },
    b: {
      "0": [0, 0]
    },
    _coverageSchema: "1a1c01bbd47fc00a2c39e90264f33305004495a9",
    hash: "c1fd64e9d3226eb6d8796d59b8ceeb6ce247c02c"
  };
  var coverage = global[gcv] || (global[gcv] = {});

  if (!coverage[path] || coverage[path].hash !== hash) {
    coverage[path] = coverageData;
  }

  var actualCoverage = coverage[path];
  {
    // @ts-ignore
    cov_2f0kcm3qn9 = function () {
      return actualCoverage;
    };
  }
  return actualCoverage;
}

cov_2f0kcm3qn9();

class ResetPopUp extends HTMLElement {
  reset() {
    cov_2f0kcm3qn9().f[0]++;
    cov_2f0kcm3qn9().s[0]++;
    // stop();
    localStorage.setItem('stop', 'true');
    const taskList = (cov_2f0kcm3qn9().s[1]++, Array.from(document.getElementById('task-list-elements').getElementsByTagName('task-item')));
    cov_2f0kcm3qn9().s[2]++;

    for (let i = (cov_2f0kcm3qn9().s[3]++, 0); i < taskList.length; i += 1) {
      cov_2f0kcm3qn9().s[4]++;
      taskList[i].removeTask();
    } // remove focus task


    const focusTask = (cov_2f0kcm3qn9().s[5]++, document.getElementById('focus-task').querySelector('task-item'));
    cov_2f0kcm3qn9().s[6]++;

    if (focusTask !== null) {
      cov_2f0kcm3qn9().b[0][0]++;
      cov_2f0kcm3qn9().s[7]++;
      focusTask.removeTask();
    } else {
      cov_2f0kcm3qn9().b[0][1]++;
    }

    cov_2f0kcm3qn9().s[8]++;
    localStorage.setItem('id', `${0}`);
    const btnSound = (cov_2f0kcm3qn9().s[9]++, new Audio('./icons/btnClick.mp3'));
    cov_2f0kcm3qn9().s[10]++;
    btnSound.volume = 0.01 * parseInt(localStorage.getItem('volume'), 10);
    cov_2f0kcm3qn9().s[11]++;
    btnSound.play();
    cov_2f0kcm3qn9().s[12]++;
    this.closePopUp();
  }

  closePopUp() {
    cov_2f0kcm3qn9().f[1]++;
    const wrapper = (cov_2f0kcm3qn9().s[13]++, this.shadowRoot.getElementById('reset-confirm-popup'));
    cov_2f0kcm3qn9().s[14]++;
    wrapper.style.display = 'none';
  }

  constructor() {
    cov_2f0kcm3qn9().f[2]++;
    cov_2f0kcm3qn9().s[15]++;
    super();
    const shadow = (cov_2f0kcm3qn9().s[16]++, this.attachShadow({
      mode: 'open'
    })); // use div as wrapper

    const wrapper = (cov_2f0kcm3qn9().s[17]++, document.createElement('div'));
    cov_2f0kcm3qn9().s[18]++;
    wrapper.setAttribute('id', 'reset-confirm-popup'); // close icon

    const close = (cov_2f0kcm3qn9().s[19]++, wrapper.appendChild(document.createElement('img')));
    cov_2f0kcm3qn9().s[20]++;
    close.setAttribute('src', 'icons/close.svg');
    cov_2f0kcm3qn9().s[21]++;
    close.setAttribute('id', 'close-icon'); // title

    const title = (cov_2f0kcm3qn9().s[22]++, wrapper.appendChild(document.createElement('h3')));
    cov_2f0kcm3qn9().s[23]++;
    title.innerHTML = 'Are you sure?'; // content

    const content = (cov_2f0kcm3qn9().s[24]++, wrapper.appendChild(document.createElement('h5')));
    cov_2f0kcm3qn9().s[25]++;
    content.setAttribute('id', 'reset-content');
    cov_2f0kcm3qn9().s[26]++;
    content.innerHTML = 'This will reset your current pomodoro session and wipe out your jotted tasks!'; // wrap confirm button in a footer

    const footer = (cov_2f0kcm3qn9().s[27]++, wrapper.appendChild(document.createElement('div')));
    cov_2f0kcm3qn9().s[28]++;
    footer.setAttribute('class', 'button-footer');
    const confirmBtn = (cov_2f0kcm3qn9().s[29]++, footer.appendChild(document.createElement('button')));
    cov_2f0kcm3qn9().s[30]++;
    confirmBtn.setAttribute('class', 'reset-popup-btns');
    cov_2f0kcm3qn9().s[31]++;
    confirmBtn.setAttribute('id', 'confirm-reset-btn');
    cov_2f0kcm3qn9().s[32]++;
    confirmBtn.innerHTML = 'Confirm'; // event listeners for confirm button and close icon

    cov_2f0kcm3qn9().s[33]++;
    confirmBtn.addEventListener('click', this.reset.bind(this));
    cov_2f0kcm3qn9().s[34]++;
    close.addEventListener('click', this.closePopUp.bind(this)); // use ::part pseudo-element to style element outside of shadow tree -- for dark mode

    cov_2f0kcm3qn9().s[35]++;
    wrapper.setAttribute('part', 'popup-wrapper');
    cov_2f0kcm3qn9().s[36]++;
    close.setAttribute('part', 'close-icon');
    cov_2f0kcm3qn9().s[37]++;
    title.setAttribute('part', 'reset-confirm-h3');
    cov_2f0kcm3qn9().s[38]++;
    content.setAttribute('part', 'reset-content');
    cov_2f0kcm3qn9().s[39]++;
    footer.setAttribute('part', 'btn-footer');
    cov_2f0kcm3qn9().s[40]++;
    confirmBtn.setAttribute('part', 'confirm-btn'); // CSS styling

    const style = (cov_2f0kcm3qn9().s[41]++, document.createElement('style'));
    cov_2f0kcm3qn9().s[42]++;
    style.textContent = `
        .button-footer {
            background-color: rgb(234 234 234);
            // padding: 14px 20px;
            padding: 1.09375vw 1.5625vw;
            text-align: right;
            position: absolute;
            bottom: 0;
            right: 0;
            left: 0;
            // border-bottom-left-radius: 4px;
            // border-bottom-right-radius: 4px;
            border-bottom-left-radius: 0.3125vw;
            border-bottom-right-radius: 0.3125vw;
        }
        #close-icon {
            // width: 15px;
            width: 1.171875vw;
            // margin-top: 10px;
            // margin-right: 10px;
            margin-top: 0.78125vw;
            margin-right: 0.78125vw;
            position:absolute;
            top:0;
            right:0;
            cursor: pointer;
            opacity: 0.33;
        }
        #close-icon:hover {
            opacity: 1;
            transform: scale(1.1);
        }
        #reset-content {
            color: rgb(85, 85, 85);
            width: 85%;
            font-weight: 500;
            font-size: 1.0375vw;
            // margin: 20px auto 0 auto;
            margin: 1.5625vw auto 0 auto;
        }
        #reset-confirm-popup {
            display: none;
            position: fixed;
            // width: 30%;
            width: 29.296875vw;
            // height: 30%;
            height: 15.625vw;
            // border-radius: 4px;
            border-radius: 0.3125vw;
            top:25%;
            left: 34%;
            z-index: 999;
            background-color: whitesmoke;
            box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
            -webkit-animation-name: animatetop; 
            -webkit-animation-duration: 0.3s;
            animation-name: animatetop;
            animation-duration: 0.3s
        }
        @-webkit-keyframes animatetop {
            from {top:-200px; opacity:0} 
            to {top:70; opacity:1}
        }
        @keyframes animatetop {
            from {top:-200px; opacity:0}
            to {top:70; opacity:1}
        }
        #reset-confirm-popup > h3{
            font-size: 1.6vw;
            color: #f36060;
            border-bottom: solid 1px #d2d2d2;
            // padding-bottom: 5px;
            padding-bottom: 0.390625vw;
            width: 85%;
            font-weight: 500;
            // margin: 20px auto 10px auto;
            margin: 1.5625vw auto 0.78125vw auto;
        }
        .reset-popup-btns {
            cursor: pointer;
            border-style: none;
            // border-radius: 4px;
            border-radius: 0.3125vw;
            text-align: center;
            background-color:#f36060;
            color:#fff;
            font-family: 'Quicksand', sans-serif;
            height: 17%;
            width: 27%;
            // font-size: 1em;
            font-size: 1.25vw;
            font-weight: 500;
            outline: none;
        }
        .reset-popup-btns:hover {
            filter: brightness(105%);
            transform: scale(1.1);
        }
        #confirm-reset-btn {
            // padding: 8px 12px;
            padding: 0.625vw 0.9375vw;
        }
        // #cancel-reset-btn {
        //     position: absolute;
        //     float:right;
        //     right: 5em;
        //     bottom: 2em;
        }`;
    cov_2f0kcm3qn9().s[43]++;
    shadow.appendChild(wrapper);
    cov_2f0kcm3qn9().s[44]++;
    shadow.appendChild(style);
  }

}

cov_2f0kcm3qn9().s[45]++;
customElements.define('reset-popup', ResetPopUp);
cov_2f0kcm3qn9().s[46]++;
window.addEventListener('load', () => {
  cov_2f0kcm3qn9().f[3]++;
  const resetPopUp = (cov_2f0kcm3qn9().s[47]++, document.createElement('reset-popup'));
  cov_2f0kcm3qn9().s[48]++;
  resetPopUp.setAttribute('class', 'popup');
  cov_2f0kcm3qn9().s[49]++;
  document.body.appendChild(resetPopUp);
  const resetBtn = (cov_2f0kcm3qn9().s[50]++, document.getElementById('reset-button'));
  cov_2f0kcm3qn9().s[51]++;
  resetBtn.addEventListener('click', () => {
    cov_2f0kcm3qn9().f[4]++;
    const btnSound = (cov_2f0kcm3qn9().s[52]++, new Audio('./icons/btnClick.mp3'));
    cov_2f0kcm3qn9().s[53]++;
    btnSound.volume = 0.01 * parseInt(localStorage.getItem('volume'), 10);
    cov_2f0kcm3qn9().s[54]++;
    btnSound.play(); // this makes sure any popup is closed before opening current popup

    const popups = (cov_2f0kcm3qn9().s[55]++, Array.from(document.getElementsByClassName('popup')));
    cov_2f0kcm3qn9().s[56]++;

    for (let i = (cov_2f0kcm3qn9().s[57]++, 0); i < popups.length; i += 1) {
      cov_2f0kcm3qn9().s[58]++;
      popups[i].closePopUp();
    }

    cov_2f0kcm3qn9().s[59]++;
    resetPopUp.shadowRoot.getElementById('reset-confirm-popup').setAttribute('style', 'display:block');
  });
}); // module.exports = ResetPopUp;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlJlc2V0UG9wVXAuanMiXSwibmFtZXMiOlsiUmVzZXRQb3BVcCIsIkhUTUxFbGVtZW50IiwicmVzZXQiLCJsb2NhbFN0b3JhZ2UiLCJzZXRJdGVtIiwidGFza0xpc3QiLCJBcnJheSIsImZyb20iLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwiZ2V0RWxlbWVudHNCeVRhZ05hbWUiLCJpIiwibGVuZ3RoIiwicmVtb3ZlVGFzayIsImZvY3VzVGFzayIsInF1ZXJ5U2VsZWN0b3IiLCJidG5Tb3VuZCIsIkF1ZGlvIiwidm9sdW1lIiwicGFyc2VJbnQiLCJnZXRJdGVtIiwicGxheSIsImNsb3NlUG9wVXAiLCJ3cmFwcGVyIiwic2hhZG93Um9vdCIsInN0eWxlIiwiZGlzcGxheSIsImNvbnN0cnVjdG9yIiwic2hhZG93IiwiYXR0YWNoU2hhZG93IiwibW9kZSIsImNyZWF0ZUVsZW1lbnQiLCJzZXRBdHRyaWJ1dGUiLCJjbG9zZSIsImFwcGVuZENoaWxkIiwidGl0bGUiLCJpbm5lckhUTUwiLCJjb250ZW50IiwiZm9vdGVyIiwiY29uZmlybUJ0biIsImFkZEV2ZW50TGlzdGVuZXIiLCJiaW5kIiwidGV4dENvbnRlbnQiLCJjdXN0b21FbGVtZW50cyIsImRlZmluZSIsIndpbmRvdyIsInJlc2V0UG9wVXAiLCJib2R5IiwicmVzZXRCdG4iLCJwb3B1cHMiLCJnZXRFbGVtZW50c0J5Q2xhc3NOYW1lIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFlWTs7Ozs7Ozs7OztBQWZaLE1BQU1BLFVBQU4sU0FBeUJDLFdBQXpCLENBQXFDO0FBQ2pDQyxFQUFBQSxLQUFLLEdBQUc7QUFBQTtBQUFBO0FBQ0o7QUFDQUMsSUFBQUEsWUFBWSxDQUFDQyxPQUFiLENBQXFCLE1BQXJCLEVBQTZCLE1BQTdCO0FBQ0EsVUFBTUMsUUFBUSw2QkFBR0MsS0FBSyxDQUFDQyxJQUFOLENBQVdDLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixvQkFBeEIsRUFBOENDLG9CQUE5QyxDQUFtRSxXQUFuRSxDQUFYLENBQUgsQ0FBZDtBQUhJOztBQUlKLFNBQUssSUFBSUMsQ0FBQyw2QkFBRyxDQUFILENBQVYsRUFBZ0JBLENBQUMsR0FBR04sUUFBUSxDQUFDTyxNQUE3QixFQUFxQ0QsQ0FBQyxJQUFJLENBQTFDLEVBQTZDO0FBQUE7QUFDekNOLE1BQUFBLFFBQVEsQ0FBQ00sQ0FBRCxDQUFSLENBQVlFLFVBQVo7QUFDSCxLQU5HLENBT0o7OztBQUNBLFVBQU1DLFNBQVMsNkJBQUdOLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixZQUF4QixFQUFzQ00sYUFBdEMsQ0FBb0QsV0FBcEQsQ0FBSCxDQUFmO0FBUkk7O0FBU0osUUFBSUQsU0FBUyxLQUFLLElBQWxCLEVBQXdCO0FBQUE7QUFBQTtBQUNwQkEsTUFBQUEsU0FBUyxDQUFDRCxVQUFWO0FBQ0gsS0FGRDtBQUFBO0FBQUE7O0FBVEk7QUFZSlYsSUFBQUEsWUFBWSxDQUFDQyxPQUFiLENBQXFCLElBQXJCLEVBQTRCLEdBQUUsQ0FBRSxFQUFoQztBQUNBLFVBQU1ZLFFBQVEsNkJBQUcsSUFBSUMsS0FBSixDQUFVLHNCQUFWLENBQUgsQ0FBZDtBQWJJO0FBY0pELElBQUFBLFFBQVEsQ0FBQ0UsTUFBVCxHQUFrQixPQUFPQyxRQUFRLENBQUNoQixZQUFZLENBQUNpQixPQUFiLENBQXFCLFFBQXJCLENBQUQsRUFBaUMsRUFBakMsQ0FBakM7QUFkSTtBQWVKSixJQUFBQSxRQUFRLENBQUNLLElBQVQ7QUFmSTtBQWdCSixTQUFLQyxVQUFMO0FBQ0g7O0FBRURBLEVBQUFBLFVBQVUsR0FBRztBQUFBO0FBQ1QsVUFBTUMsT0FBTyw4QkFBRyxLQUFLQyxVQUFMLENBQWdCZixjQUFoQixDQUErQixxQkFBL0IsQ0FBSCxDQUFiO0FBRFM7QUFFVGMsSUFBQUEsT0FBTyxDQUFDRSxLQUFSLENBQWNDLE9BQWQsR0FBd0IsTUFBeEI7QUFDSDs7QUFFREMsRUFBQUEsV0FBVyxHQUFHO0FBQUE7QUFBQTtBQUNWO0FBQ0EsVUFBTUMsTUFBTSw4QkFBRyxLQUFLQyxZQUFMLENBQWtCO0FBQUVDLE1BQUFBLElBQUksRUFBRTtBQUFSLEtBQWxCLENBQUgsQ0FBWixDQUZVLENBR1Y7O0FBQ0EsVUFBTVAsT0FBTyw4QkFBR2YsUUFBUSxDQUFDdUIsYUFBVCxDQUF1QixLQUF2QixDQUFILENBQWI7QUFKVTtBQUtWUixJQUFBQSxPQUFPLENBQUNTLFlBQVIsQ0FBcUIsSUFBckIsRUFBMkIscUJBQTNCLEVBTFUsQ0FNVjs7QUFDQSxVQUFNQyxLQUFLLDhCQUFHVixPQUFPLENBQUNXLFdBQVIsQ0FBb0IxQixRQUFRLENBQUN1QixhQUFULENBQXVCLEtBQXZCLENBQXBCLENBQUgsQ0FBWDtBQVBVO0FBUVZFLElBQUFBLEtBQUssQ0FBQ0QsWUFBTixDQUFtQixLQUFuQixFQUEwQixpQkFBMUI7QUFSVTtBQVNWQyxJQUFBQSxLQUFLLENBQUNELFlBQU4sQ0FBbUIsSUFBbkIsRUFBeUIsWUFBekIsRUFUVSxDQVVWOztBQUNBLFVBQU1HLEtBQUssOEJBQUdaLE9BQU8sQ0FBQ1csV0FBUixDQUFvQjFCLFFBQVEsQ0FBQ3VCLGFBQVQsQ0FBdUIsSUFBdkIsQ0FBcEIsQ0FBSCxDQUFYO0FBWFU7QUFZVkksSUFBQUEsS0FBSyxDQUFDQyxTQUFOLEdBQWtCLGVBQWxCLENBWlUsQ0FhVjs7QUFDQSxVQUFNQyxPQUFPLDhCQUFHZCxPQUFPLENBQUNXLFdBQVIsQ0FBb0IxQixRQUFRLENBQUN1QixhQUFULENBQXVCLElBQXZCLENBQXBCLENBQUgsQ0FBYjtBQWRVO0FBZVZNLElBQUFBLE9BQU8sQ0FBQ0wsWUFBUixDQUFxQixJQUFyQixFQUEyQixlQUEzQjtBQWZVO0FBZ0JWSyxJQUFBQSxPQUFPLENBQUNELFNBQVIsR0FBb0IsK0VBQXBCLENBaEJVLENBaUJWOztBQUNBLFVBQU1FLE1BQU0sOEJBQUdmLE9BQU8sQ0FBQ1csV0FBUixDQUFvQjFCLFFBQVEsQ0FBQ3VCLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBcEIsQ0FBSCxDQUFaO0FBbEJVO0FBbUJWTyxJQUFBQSxNQUFNLENBQUNOLFlBQVAsQ0FBb0IsT0FBcEIsRUFBNkIsZUFBN0I7QUFDQSxVQUFNTyxVQUFVLDhCQUFHRCxNQUFNLENBQUNKLFdBQVAsQ0FBbUIxQixRQUFRLENBQUN1QixhQUFULENBQXVCLFFBQXZCLENBQW5CLENBQUgsQ0FBaEI7QUFwQlU7QUFxQlZRLElBQUFBLFVBQVUsQ0FBQ1AsWUFBWCxDQUF3QixPQUF4QixFQUFpQyxrQkFBakM7QUFyQlU7QUFzQlZPLElBQUFBLFVBQVUsQ0FBQ1AsWUFBWCxDQUF3QixJQUF4QixFQUE4QixtQkFBOUI7QUF0QlU7QUF1QlZPLElBQUFBLFVBQVUsQ0FBQ0gsU0FBWCxHQUF1QixTQUF2QixDQXZCVSxDQXdCVjs7QUF4QlU7QUF5QlZHLElBQUFBLFVBQVUsQ0FBQ0MsZ0JBQVgsQ0FBNEIsT0FBNUIsRUFBcUMsS0FBS3RDLEtBQUwsQ0FBV3VDLElBQVgsQ0FBZ0IsSUFBaEIsQ0FBckM7QUF6QlU7QUEwQlZSLElBQUFBLEtBQUssQ0FBQ08sZ0JBQU4sQ0FBdUIsT0FBdkIsRUFBZ0MsS0FBS2xCLFVBQUwsQ0FBZ0JtQixJQUFoQixDQUFxQixJQUFyQixDQUFoQyxFQTFCVSxDQTJCVjs7QUEzQlU7QUE0QlZsQixJQUFBQSxPQUFPLENBQUNTLFlBQVIsQ0FBcUIsTUFBckIsRUFBNkIsZUFBN0I7QUE1QlU7QUE2QlZDLElBQUFBLEtBQUssQ0FBQ0QsWUFBTixDQUFtQixNQUFuQixFQUEyQixZQUEzQjtBQTdCVTtBQThCVkcsSUFBQUEsS0FBSyxDQUFDSCxZQUFOLENBQW1CLE1BQW5CLEVBQTJCLGtCQUEzQjtBQTlCVTtBQStCVkssSUFBQUEsT0FBTyxDQUFDTCxZQUFSLENBQXFCLE1BQXJCLEVBQTZCLGVBQTdCO0FBL0JVO0FBZ0NWTSxJQUFBQSxNQUFNLENBQUNOLFlBQVAsQ0FBb0IsTUFBcEIsRUFBNEIsWUFBNUI7QUFoQ1U7QUFpQ1ZPLElBQUFBLFVBQVUsQ0FBQ1AsWUFBWCxDQUF3QixNQUF4QixFQUFnQyxhQUFoQyxFQWpDVSxDQWtDVjs7QUFDQSxVQUFNUCxLQUFLLDhCQUFHakIsUUFBUSxDQUFDdUIsYUFBVCxDQUF1QixPQUF2QixDQUFILENBQVg7QUFuQ1U7QUFvQ1ZOLElBQUFBLEtBQUssQ0FBQ2lCLFdBQU4sR0FBcUI7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxVQTNHUTtBQXBDVTtBQWdKVmQsSUFBQUEsTUFBTSxDQUFDTSxXQUFQLENBQW1CWCxPQUFuQjtBQWhKVTtBQWlKVkssSUFBQUEsTUFBTSxDQUFDTSxXQUFQLENBQW1CVCxLQUFuQjtBQUNIOztBQTNLZ0M7OztBQTZLckNrQixjQUFjLENBQUNDLE1BQWYsQ0FBc0IsYUFBdEIsRUFBcUM1QyxVQUFyQzs7QUFFQTZDLE1BQU0sQ0FBQ0wsZ0JBQVAsQ0FBd0IsTUFBeEIsRUFBZ0MsTUFBTTtBQUFBO0FBQ2xDLFFBQU1NLFVBQVUsOEJBQUd0QyxRQUFRLENBQUN1QixhQUFULENBQXVCLGFBQXZCLENBQUgsQ0FBaEI7QUFEa0M7QUFFbENlLEVBQUFBLFVBQVUsQ0FBQ2QsWUFBWCxDQUF3QixPQUF4QixFQUFpQyxPQUFqQztBQUZrQztBQUdsQ3hCLEVBQUFBLFFBQVEsQ0FBQ3VDLElBQVQsQ0FBY2IsV0FBZCxDQUEwQlksVUFBMUI7QUFDQSxRQUFNRSxRQUFRLDhCQUFHeEMsUUFBUSxDQUFDQyxjQUFULENBQXdCLGNBQXhCLENBQUgsQ0FBZDtBQUprQztBQUtsQ3VDLEVBQUFBLFFBQVEsQ0FBQ1IsZ0JBQVQsQ0FBMEIsT0FBMUIsRUFBbUMsTUFBTTtBQUFBO0FBQ3JDLFVBQU14QixRQUFRLDhCQUFHLElBQUlDLEtBQUosQ0FBVSxzQkFBVixDQUFILENBQWQ7QUFEcUM7QUFFckNELElBQUFBLFFBQVEsQ0FBQ0UsTUFBVCxHQUFrQixPQUFPQyxRQUFRLENBQUNoQixZQUFZLENBQUNpQixPQUFiLENBQXFCLFFBQXJCLENBQUQsRUFBaUMsRUFBakMsQ0FBakM7QUFGcUM7QUFHckNKLElBQUFBLFFBQVEsQ0FBQ0ssSUFBVCxHQUhxQyxDQUlyQzs7QUFDQSxVQUFNNEIsTUFBTSw4QkFBRzNDLEtBQUssQ0FBQ0MsSUFBTixDQUFXQyxRQUFRLENBQUMwQyxzQkFBVCxDQUFnQyxPQUFoQyxDQUFYLENBQUgsQ0FBWjtBQUxxQzs7QUFNckMsU0FBSyxJQUFJdkMsQ0FBQyw4QkFBRyxDQUFILENBQVYsRUFBZ0JBLENBQUMsR0FBR3NDLE1BQU0sQ0FBQ3JDLE1BQTNCLEVBQW1DRCxDQUFDLElBQUksQ0FBeEMsRUFBMkM7QUFBQTtBQUN2Q3NDLE1BQUFBLE1BQU0sQ0FBQ3RDLENBQUQsQ0FBTixDQUFVVyxVQUFWO0FBQ0g7O0FBUm9DO0FBU3JDd0IsSUFBQUEsVUFBVSxDQUFDdEIsVUFBWCxDQUFzQmYsY0FBdEIsQ0FBcUMscUJBQXJDLEVBQTREdUIsWUFBNUQsQ0FBeUUsT0FBekUsRUFBa0YsZUFBbEY7QUFDSCxHQVZEO0FBV0gsQ0FoQkQsRSxDQWtCQSIsInNvdXJjZXNDb250ZW50IjpbImNsYXNzIFJlc2V0UG9wVXAgZXh0ZW5kcyBIVE1MRWxlbWVudCB7XHJcbiAgICByZXNldCgpIHtcclxuICAgICAgICAvLyBzdG9wKCk7XHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3N0b3AnLCAndHJ1ZScpO1xyXG4gICAgICAgIGNvbnN0IHRhc2tMaXN0ID0gQXJyYXkuZnJvbShkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndGFzay1saXN0LWVsZW1lbnRzJykuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ3Rhc2staXRlbScpKTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRhc2tMaXN0Lmxlbmd0aDsgaSArPSAxKSB7XHJcbiAgICAgICAgICAgIHRhc2tMaXN0W2ldLnJlbW92ZVRhc2soKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gcmVtb3ZlIGZvY3VzIHRhc2tcclxuICAgICAgICBjb25zdCBmb2N1c1Rhc2sgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZm9jdXMtdGFzaycpLnF1ZXJ5U2VsZWN0b3IoJ3Rhc2staXRlbScpO1xyXG4gICAgICAgIGlmIChmb2N1c1Rhc2sgIT09IG51bGwpIHtcclxuICAgICAgICAgICAgZm9jdXNUYXNrLnJlbW92ZVRhc2soKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2lkJywgYCR7MH1gKTtcclxuICAgICAgICBjb25zdCBidG5Tb3VuZCA9IG5ldyBBdWRpbygnLi9pY29ucy9idG5DbGljay5tcDMnKTtcclxuICAgICAgICBidG5Tb3VuZC52b2x1bWUgPSAwLjAxICogcGFyc2VJbnQobG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3ZvbHVtZScpLCAxMCk7XHJcbiAgICAgICAgYnRuU291bmQucGxheSgpO1xyXG4gICAgICAgIHRoaXMuY2xvc2VQb3BVcCgpO1xyXG4gICAgfVxyXG5cclxuICAgIGNsb3NlUG9wVXAoKSB7XHJcbiAgICAgICAgY29uc3Qgd3JhcHBlciA9IHRoaXMuc2hhZG93Um9vdC5nZXRFbGVtZW50QnlJZCgncmVzZXQtY29uZmlybS1wb3B1cCcpO1xyXG4gICAgICAgIHdyYXBwZXIuc3R5bGUuZGlzcGxheSA9ICdub25lJztcclxuICAgIH1cclxuXHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgICBzdXBlcigpO1xyXG4gICAgICAgIGNvbnN0IHNoYWRvdyA9IHRoaXMuYXR0YWNoU2hhZG93KHsgbW9kZTogJ29wZW4nIH0pO1xyXG4gICAgICAgIC8vIHVzZSBkaXYgYXMgd3JhcHBlclxyXG4gICAgICAgIGNvbnN0IHdyYXBwZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgICAgICB3cmFwcGVyLnNldEF0dHJpYnV0ZSgnaWQnLCAncmVzZXQtY29uZmlybS1wb3B1cCcpO1xyXG4gICAgICAgIC8vIGNsb3NlIGljb25cclxuICAgICAgICBjb25zdCBjbG9zZSA9IHdyYXBwZXIuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaW1nJykpO1xyXG4gICAgICAgIGNsb3NlLnNldEF0dHJpYnV0ZSgnc3JjJywgJ2ljb25zL2Nsb3NlLnN2ZycpO1xyXG4gICAgICAgIGNsb3NlLnNldEF0dHJpYnV0ZSgnaWQnLCAnY2xvc2UtaWNvbicpO1xyXG4gICAgICAgIC8vIHRpdGxlXHJcbiAgICAgICAgY29uc3QgdGl0bGUgPSB3cmFwcGVyLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2gzJykpO1xyXG4gICAgICAgIHRpdGxlLmlubmVySFRNTCA9ICdBcmUgeW91IHN1cmU/JztcclxuICAgICAgICAvLyBjb250ZW50XHJcbiAgICAgICAgY29uc3QgY29udGVudCA9IHdyYXBwZXIuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaDUnKSk7XHJcbiAgICAgICAgY29udGVudC5zZXRBdHRyaWJ1dGUoJ2lkJywgJ3Jlc2V0LWNvbnRlbnQnKTtcclxuICAgICAgICBjb250ZW50LmlubmVySFRNTCA9ICdUaGlzIHdpbGwgcmVzZXQgeW91ciBjdXJyZW50IHBvbW9kb3JvIHNlc3Npb24gYW5kIHdpcGUgb3V0IHlvdXIgam90dGVkIHRhc2tzISc7XHJcbiAgICAgICAgLy8gd3JhcCBjb25maXJtIGJ1dHRvbiBpbiBhIGZvb3RlclxyXG4gICAgICAgIGNvbnN0IGZvb3RlciA9IHdyYXBwZXIuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JykpO1xyXG4gICAgICAgIGZvb3Rlci5zZXRBdHRyaWJ1dGUoJ2NsYXNzJywgJ2J1dHRvbi1mb290ZXInKTtcclxuICAgICAgICBjb25zdCBjb25maXJtQnRuID0gZm9vdGVyLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpKTtcclxuICAgICAgICBjb25maXJtQnRuLnNldEF0dHJpYnV0ZSgnY2xhc3MnLCAncmVzZXQtcG9wdXAtYnRucycpO1xyXG4gICAgICAgIGNvbmZpcm1CdG4uc2V0QXR0cmlidXRlKCdpZCcsICdjb25maXJtLXJlc2V0LWJ0bicpO1xyXG4gICAgICAgIGNvbmZpcm1CdG4uaW5uZXJIVE1MID0gJ0NvbmZpcm0nO1xyXG4gICAgICAgIC8vIGV2ZW50IGxpc3RlbmVycyBmb3IgY29uZmlybSBidXR0b24gYW5kIGNsb3NlIGljb25cclxuICAgICAgICBjb25maXJtQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgdGhpcy5yZXNldC5iaW5kKHRoaXMpKTtcclxuICAgICAgICBjbG9zZS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIHRoaXMuY2xvc2VQb3BVcC5iaW5kKHRoaXMpKTtcclxuICAgICAgICAvLyB1c2UgOjpwYXJ0IHBzZXVkby1lbGVtZW50IHRvIHN0eWxlIGVsZW1lbnQgb3V0c2lkZSBvZiBzaGFkb3cgdHJlZSAtLSBmb3IgZGFyayBtb2RlXHJcbiAgICAgICAgd3JhcHBlci5zZXRBdHRyaWJ1dGUoJ3BhcnQnLCAncG9wdXAtd3JhcHBlcicpO1xyXG4gICAgICAgIGNsb3NlLnNldEF0dHJpYnV0ZSgncGFydCcsICdjbG9zZS1pY29uJyk7XHJcbiAgICAgICAgdGl0bGUuc2V0QXR0cmlidXRlKCdwYXJ0JywgJ3Jlc2V0LWNvbmZpcm0taDMnKTtcclxuICAgICAgICBjb250ZW50LnNldEF0dHJpYnV0ZSgncGFydCcsICdyZXNldC1jb250ZW50Jyk7XHJcbiAgICAgICAgZm9vdGVyLnNldEF0dHJpYnV0ZSgncGFydCcsICdidG4tZm9vdGVyJyk7XHJcbiAgICAgICAgY29uZmlybUJ0bi5zZXRBdHRyaWJ1dGUoJ3BhcnQnLCAnY29uZmlybS1idG4nKTtcclxuICAgICAgICAvLyBDU1Mgc3R5bGluZ1xyXG4gICAgICAgIGNvbnN0IHN0eWxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3R5bGUnKTtcclxuICAgICAgICBzdHlsZS50ZXh0Q29udGVudCA9IGBcclxuICAgICAgICAuYnV0dG9uLWZvb3RlciB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyMzQgMjM0IDIzNCk7XHJcbiAgICAgICAgICAgIC8vIHBhZGRpbmc6IDE0cHggMjBweDtcclxuICAgICAgICAgICAgcGFkZGluZzogMS4wOTM3NXZ3IDEuNTYyNXZ3O1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcclxuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgICAgICBib3R0b206IDA7XHJcbiAgICAgICAgICAgIHJpZ2h0OiAwO1xyXG4gICAgICAgICAgICBsZWZ0OiAwO1xyXG4gICAgICAgICAgICAvLyBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA0cHg7XHJcbiAgICAgICAgICAgIC8vIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA0cHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDAuMzEyNXZ3O1xyXG4gICAgICAgICAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMC4zMTI1dnc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICNjbG9zZS1pY29uIHtcclxuICAgICAgICAgICAgLy8gd2lkdGg6IDE1cHg7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxLjE3MTg3NXZ3O1xyXG4gICAgICAgICAgICAvLyBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgICAgICAgICAvLyBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDAuNzgxMjV2dztcclxuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAwLjc4MTI1dnc7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOmFic29sdXRlO1xyXG4gICAgICAgICAgICB0b3A6MDtcclxuICAgICAgICAgICAgcmlnaHQ6MDtcclxuICAgICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICAgICAgICBvcGFjaXR5OiAwLjMzO1xyXG4gICAgICAgIH1cclxuICAgICAgICAjY2xvc2UtaWNvbjpob3ZlciB7XHJcbiAgICAgICAgICAgIG9wYWNpdHk6IDE7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMS4xKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgI3Jlc2V0LWNvbnRlbnQge1xyXG4gICAgICAgICAgICBjb2xvcjogcmdiKDg1LCA4NSwgODUpO1xyXG4gICAgICAgICAgICB3aWR0aDogODUlO1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEuMDM3NXZ3O1xyXG4gICAgICAgICAgICAvLyBtYXJnaW46IDIwcHggYXV0byAwIGF1dG87XHJcbiAgICAgICAgICAgIG1hcmdpbjogMS41NjI1dncgYXV0byAwIGF1dG87XHJcbiAgICAgICAgfVxyXG4gICAgICAgICNyZXNldC1jb25maXJtLXBvcHVwIHtcclxuICAgICAgICAgICAgZGlzcGxheTogbm9uZTtcclxuICAgICAgICAgICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgICAgICAgICAvLyB3aWR0aDogMzAlO1xyXG4gICAgICAgICAgICB3aWR0aDogMjkuMjk2ODc1dnc7XHJcbiAgICAgICAgICAgIC8vIGhlaWdodDogMzAlO1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDE1LjYyNXZ3O1xyXG4gICAgICAgICAgICAvLyBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDAuMzEyNXZ3O1xyXG4gICAgICAgICAgICB0b3A6MjUlO1xyXG4gICAgICAgICAgICBsZWZ0OiAzNCU7XHJcbiAgICAgICAgICAgIHotaW5kZXg6IDk5OTtcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGVzbW9rZTtcclxuICAgICAgICAgICAgYm94LXNoYWRvdzogMCA0cHggOHB4IDAgcmdiYSgwLDAsMCwwLjIpLDAgNnB4IDIwcHggMCByZ2JhKDAsMCwwLDAuMTkpO1xyXG4gICAgICAgICAgICAtd2Via2l0LWFuaW1hdGlvbi1uYW1lOiBhbmltYXRldG9wOyBcclxuICAgICAgICAgICAgLXdlYmtpdC1hbmltYXRpb24tZHVyYXRpb246IDAuM3M7XHJcbiAgICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBhbmltYXRldG9wO1xyXG4gICAgICAgICAgICBhbmltYXRpb24tZHVyYXRpb246IDAuM3NcclxuICAgICAgICB9XHJcbiAgICAgICAgQC13ZWJraXQta2V5ZnJhbWVzIGFuaW1hdGV0b3Age1xyXG4gICAgICAgICAgICBmcm9tIHt0b3A6LTIwMHB4OyBvcGFjaXR5OjB9IFxyXG4gICAgICAgICAgICB0byB7dG9wOjcwOyBvcGFjaXR5OjF9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIEBrZXlmcmFtZXMgYW5pbWF0ZXRvcCB7XHJcbiAgICAgICAgICAgIGZyb20ge3RvcDotMjAwcHg7IG9wYWNpdHk6MH1cclxuICAgICAgICAgICAgdG8ge3RvcDo3MDsgb3BhY2l0eToxfVxyXG4gICAgICAgIH1cclxuICAgICAgICAjcmVzZXQtY29uZmlybS1wb3B1cCA+IGgze1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEuNnZ3O1xyXG4gICAgICAgICAgICBjb2xvcjogI2YzNjA2MDtcclxuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogc29saWQgMXB4ICNkMmQyZDI7XHJcbiAgICAgICAgICAgIC8vIHBhZGRpbmctYm90dG9tOiA1cHg7XHJcbiAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOiAwLjM5MDYyNXZ3O1xyXG4gICAgICAgICAgICB3aWR0aDogODUlO1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICAgICAgICAvLyBtYXJnaW46IDIwcHggYXV0byAxMHB4IGF1dG87XHJcbiAgICAgICAgICAgIG1hcmdpbjogMS41NjI1dncgYXV0byAwLjc4MTI1dncgYXV0bztcclxuICAgICAgICB9XHJcbiAgICAgICAgLnJlc2V0LXBvcHVwLWJ0bnMge1xyXG4gICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgICAgIGJvcmRlci1zdHlsZTogbm9uZTtcclxuICAgICAgICAgICAgLy8gYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAwLjMxMjV2dztcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiNmMzYwNjA7XHJcbiAgICAgICAgICAgIGNvbG9yOiNmZmY7XHJcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnUXVpY2tzYW5kJywgc2Fucy1zZXJpZjtcclxuICAgICAgICAgICAgaGVpZ2h0OiAxNyU7XHJcbiAgICAgICAgICAgIHdpZHRoOiAyNyU7XHJcbiAgICAgICAgICAgIC8vIGZvbnQtc2l6ZTogMWVtO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEuMjV2dztcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICAgICAgb3V0bGluZTogbm9uZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLnJlc2V0LXBvcHVwLWJ0bnM6aG92ZXIge1xyXG4gICAgICAgICAgICBmaWx0ZXI6IGJyaWdodG5lc3MoMTA1JSk7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMS4xKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgI2NvbmZpcm0tcmVzZXQtYnRuIHtcclxuICAgICAgICAgICAgLy8gcGFkZGluZzogOHB4IDEycHg7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDAuNjI1dncgMC45Mzc1dnc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vICNjYW5jZWwtcmVzZXQtYnRuIHtcclxuICAgICAgICAvLyAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIC8vICAgICBmbG9hdDpyaWdodDtcclxuICAgICAgICAvLyAgICAgcmlnaHQ6IDVlbTtcclxuICAgICAgICAvLyAgICAgYm90dG9tOiAyZW07XHJcbiAgICAgICAgfWA7XHJcbiAgICAgICAgc2hhZG93LmFwcGVuZENoaWxkKHdyYXBwZXIpO1xyXG4gICAgICAgIHNoYWRvdy5hcHBlbmRDaGlsZChzdHlsZSk7XHJcbiAgICB9XHJcbn1cclxuY3VzdG9tRWxlbWVudHMuZGVmaW5lKCdyZXNldC1wb3B1cCcsIFJlc2V0UG9wVXApO1xyXG5cclxud2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2xvYWQnLCAoKSA9PiB7XHJcbiAgICBjb25zdCByZXNldFBvcFVwID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgncmVzZXQtcG9wdXAnKTtcclxuICAgIHJlc2V0UG9wVXAuc2V0QXR0cmlidXRlKCdjbGFzcycsICdwb3B1cCcpO1xyXG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChyZXNldFBvcFVwKTtcclxuICAgIGNvbnN0IHJlc2V0QnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jlc2V0LWJ1dHRvbicpO1xyXG4gICAgcmVzZXRCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgYnRuU291bmQgPSBuZXcgQXVkaW8oJy4vaWNvbnMvYnRuQ2xpY2subXAzJyk7XHJcbiAgICAgICAgYnRuU291bmQudm9sdW1lID0gMC4wMSAqIHBhcnNlSW50KGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd2b2x1bWUnKSwgMTApO1xyXG4gICAgICAgIGJ0blNvdW5kLnBsYXkoKTtcclxuICAgICAgICAvLyB0aGlzIG1ha2VzIHN1cmUgYW55IHBvcHVwIGlzIGNsb3NlZCBiZWZvcmUgb3BlbmluZyBjdXJyZW50IHBvcHVwXHJcbiAgICAgICAgY29uc3QgcG9wdXBzID0gQXJyYXkuZnJvbShkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKCdwb3B1cCcpKTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHBvcHVwcy5sZW5ndGg7IGkgKz0gMSkge1xyXG4gICAgICAgICAgICBwb3B1cHNbaV0uY2xvc2VQb3BVcCgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXNldFBvcFVwLnNoYWRvd1Jvb3QuZ2V0RWxlbWVudEJ5SWQoJ3Jlc2V0LWNvbmZpcm0tcG9wdXAnKS5zZXRBdHRyaWJ1dGUoJ3N0eWxlJywgJ2Rpc3BsYXk6YmxvY2snKTtcclxuICAgIH0pO1xyXG59KTtcclxuXHJcbi8vIG1vZHVsZS5leHBvcnRzID0gUmVzZXRQb3BVcDtcclxuIl19
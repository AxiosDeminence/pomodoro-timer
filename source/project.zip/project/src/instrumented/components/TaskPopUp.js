function cov_2ixowtlqop() {
  var path = "D:\\\u5B66\u4E60\\21WI\\CSE110\\cse110-w21-group13\\source\\src\\components\\TaskPopUp.js";
  var hash = "e62d69254181ac2eda45844756b76bc74181789c";
  var global = new Function("return this")();
  var gcv = "__coverage__";
  var coverageData = {
    path: "D:\\\u5B66\u4E60\\21WI\\CSE110\\cse110-w21-group13\\source\\src\\components\\TaskPopUp.js",
    statementMap: {
      "0": {
        start: {
          line: 6,
          column: 22
        },
        end: {
          line: 6,
          column: 63
        }
      },
      "1": {
        start: {
          line: 7,
          column: 22
        },
        end: {
          line: 7,
          column: 72
        }
      },
      "2": {
        start: {
          line: 8,
          column: 8
        },
        end: {
          line: 32,
          column: 9
        }
      },
      "3": {
        start: {
          line: 10,
          column: 25
        },
        end: {
          line: 15,
          column: 13
        }
      },
      "4": {
        start: {
          line: 16,
          column: 29
        },
        end: {
          line: 16,
          column: 64
        }
      },
      "5": {
        start: {
          line: 17,
          column: 12
        },
        end: {
          line: 17,
          column: 49
        }
      },
      "6": {
        start: {
          line: 18,
          column: 12
        },
        end: {
          line: 18,
          column: 59
        }
      },
      "7": {
        start: {
          line: 19,
          column: 12
        },
        end: {
          line: 19,
          column: 53
        }
      },
      "8": {
        start: {
          line: 20,
          column: 12
        },
        end: {
          line: 20,
          column: 59
        }
      },
      "9": {
        start: {
          line: 21,
          column: 12
        },
        end: {
          line: 21,
          column: 80
        }
      },
      "10": {
        start: {
          line: 23,
          column: 12
        },
        end: {
          line: 23,
          column: 29
        }
      },
      "11": {
        start: {
          line: 24,
          column: 12
        },
        end: {
          line: 24,
          column: 65
        }
      },
      "12": {
        start: {
          line: 25,
          column: 23
        },
        end: {
          line: 25,
          column: 67
        }
      },
      "13": {
        start: {
          line: 26,
          column: 12
        },
        end: {
          line: 26,
          column: 48
        }
      },
      "14": {
        start: {
          line: 27,
          column: 29
        },
        end: {
          line: 27,
          column: 62
        }
      },
      "15": {
        start: {
          line: 28,
          column: 12
        },
        end: {
          line: 28,
          column: 82
        }
      },
      "16": {
        start: {
          line: 29,
          column: 12
        },
        end: {
          line: 29,
          column: 28
        }
      },
      "17": {
        start: {
          line: 31,
          column: 12
        },
        end: {
          line: 31,
          column: 30
        }
      },
      "18": {
        start: {
          line: 37,
          column: 24
        },
        end: {
          line: 37,
          column: 72
        }
      },
      "19": {
        start: {
          line: 38,
          column: 22
        },
        end: {
          line: 38,
          column: 66
        }
      },
      "20": {
        start: {
          line: 39,
          column: 8
        },
        end: {
          line: 39,
          column: 39
        }
      },
      "21": {
        start: {
          line: 40,
          column: 8
        },
        end: {
          line: 40,
          column: 25
        }
      },
      "22": {
        start: {
          line: 45,
          column: 8
        },
        end: {
          line: 45,
          column: 16
        }
      },
      "23": {
        start: {
          line: 46,
          column: 23
        },
        end: {
          line: 46,
          column: 58
        }
      },
      "24": {
        start: {
          line: 48,
          column: 24
        },
        end: {
          line: 48,
          column: 53
        }
      },
      "25": {
        start: {
          line: 49,
          column: 8
        },
        end: {
          line: 49,
          column: 53
        }
      },
      "26": {
        start: {
          line: 51,
          column: 22
        },
        end: {
          line: 51,
          column: 72
        }
      },
      "27": {
        start: {
          line: 52,
          column: 8
        },
        end: {
          line: 52,
          column: 53
        }
      },
      "28": {
        start: {
          line: 53,
          column: 8
        },
        end: {
          line: 53,
          column: 47
        }
      },
      "29": {
        start: {
          line: 54,
          column: 22
        },
        end: {
          line: 54,
          column: 71
        }
      },
      "30": {
        start: {
          line: 55,
          column: 8
        },
        end: {
          line: 55,
          column: 37
        }
      },
      "31": {
        start: {
          line: 57,
          column: 22
        },
        end: {
          line: 57,
          column: 74
        }
      },
      "32": {
        start: {
          line: 58,
          column: 8
        },
        end: {
          line: 58,
          column: 43
        }
      },
      "33": {
        start: {
          line: 59,
          column: 8
        },
        end: {
          line: 59,
          column: 47
        }
      },
      "34": {
        start: {
          line: 60,
          column: 8
        },
        end: {
          line: 60,
          column: 76
        }
      },
      "35": {
        start: {
          line: 61,
          column: 8
        },
        end: {
          line: 61,
          column: 46
        }
      },
      "36": {
        start: {
          line: 62,
          column: 8
        },
        end: {
          line: 62,
          column: 50
        }
      },
      "37": {
        start: {
          line: 64,
          column: 23
        },
        end: {
          line: 64,
          column: 73
        }
      },
      "38": {
        start: {
          line: 65,
          column: 8
        },
        end: {
          line: 65,
          column: 54
        }
      },
      "39": {
        start: {
          line: 66,
          column: 23
        },
        end: {
          line: 66,
          column: 75
        }
      },
      "40": {
        start: {
          line: 67,
          column: 8
        },
        end: {
          line: 67,
          column: 51
        }
      },
      "41": {
        start: {
          line: 68,
          column: 8
        },
        end: {
          line: 68,
          column: 50
        }
      },
      "42": {
        start: {
          line: 69,
          column: 8
        },
        end: {
          line: 69,
          column: 33
        }
      },
      "43": {
        start: {
          line: 71,
          column: 8
        },
        end: {
          line: 71,
          column: 68
        }
      },
      "44": {
        start: {
          line: 72,
          column: 8
        },
        end: {
          line: 72,
          column: 66
        }
      },
      "45": {
        start: {
          line: 74,
          column: 8
        },
        end: {
          line: 74,
          column: 54
        }
      },
      "46": {
        start: {
          line: 75,
          column: 8
        },
        end: {
          line: 75,
          column: 49
        }
      },
      "47": {
        start: {
          line: 76,
          column: 8
        },
        end: {
          line: 76,
          column: 50
        }
      },
      "48": {
        start: {
          line: 77,
          column: 8
        },
        end: {
          line: 77,
          column: 49
        }
      },
      "49": {
        start: {
          line: 78,
          column: 8
        },
        end: {
          line: 78,
          column: 50
        }
      },
      "50": {
        start: {
          line: 79,
          column: 8
        },
        end: {
          line: 79,
          column: 47
        }
      },
      "51": {
        start: {
          line: 81,
          column: 22
        },
        end: {
          line: 81,
          column: 53
        }
      },
      "52": {
        start: {
          line: 82,
          column: 8
        },
        end: {
          line: 203,
          column: 11
        }
      },
      "53": {
        start: {
          line: 204,
          column: 8
        },
        end: {
          line: 204,
          column: 36
        }
      },
      "54": {
        start: {
          line: 205,
          column: 8
        },
        end: {
          line: 205,
          column: 34
        }
      },
      "55": {
        start: {
          line: 208,
          column: 0
        },
        end: {
          line: 208,
          column: 47
        }
      },
      "56": {
        start: {
          line: 210,
          column: 0
        },
        end: {
          line: 227,
          column: 3
        }
      },
      "57": {
        start: {
          line: 211,
          column: 21
        },
        end: {
          line: 211,
          column: 62
        }
      },
      "58": {
        start: {
          line: 212,
          column: 18
        },
        end: {
          line: 212,
          column: 54
        }
      },
      "59": {
        start: {
          line: 213,
          column: 4
        },
        end: {
          line: 213,
          column: 41
        }
      },
      "60": {
        start: {
          line: 214,
          column: 4
        },
        end: {
          line: 214,
          column: 37
        }
      },
      "61": {
        start: {
          line: 215,
          column: 4
        },
        end: {
          line: 226,
          column: 7
        }
      },
      "62": {
        start: {
          line: 216,
          column: 25
        },
        end: {
          line: 216,
          column: 58
        }
      },
      "63": {
        start: {
          line: 217,
          column: 8
        },
        end: {
          line: 217,
          column: 78
        }
      },
      "64": {
        start: {
          line: 218,
          column: 8
        },
        end: {
          line: 218,
          column: 24
        }
      },
      "65": {
        start: {
          line: 220,
          column: 23
        },
        end: {
          line: 220,
          column: 75
        }
      },
      "66": {
        start: {
          line: 221,
          column: 8
        },
        end: {
          line: 223,
          column: 9
        }
      },
      "67": {
        start: {
          line: 221,
          column: 21
        },
        end: {
          line: 221,
          column: 22
        }
      },
      "68": {
        start: {
          line: 222,
          column: 12
        },
        end: {
          line: 222,
          column: 35
        }
      },
      "69": {
        start: {
          line: 224,
          column: 8
        },
        end: {
          line: 224,
          column: 97
        }
      },
      "70": {
        start: {
          line: 225,
          column: 8
        },
        end: {
          line: 225,
          column: 62
        }
      }
    },
    fnMap: {
      "0": {
        name: "(anonymous_0)",
        decl: {
          start: {
            line: 5,
            column: 4
          },
          end: {
            line: 5,
            column: 5
          }
        },
        loc: {
          start: {
            line: 5,
            column: 14
          },
          end: {
            line: 33,
            column: 5
          }
        },
        line: 5
      },
      "1": {
        name: "(anonymous_1)",
        decl: {
          start: {
            line: 36,
            column: 4
          },
          end: {
            line: 36,
            column: 5
          }
        },
        loc: {
          start: {
            line: 36,
            column: 17
          },
          end: {
            line: 41,
            column: 5
          }
        },
        line: 36
      },
      "2": {
        name: "(anonymous_2)",
        decl: {
          start: {
            line: 44,
            column: 4
          },
          end: {
            line: 44,
            column: 5
          }
        },
        loc: {
          start: {
            line: 44,
            column: 18
          },
          end: {
            line: 206,
            column: 5
          }
        },
        line: 44
      },
      "3": {
        name: "(anonymous_3)",
        decl: {
          start: {
            line: 210,
            column: 32
          },
          end: {
            line: 210,
            column: 33
          }
        },
        loc: {
          start: {
            line: 210,
            column: 38
          },
          end: {
            line: 227,
            column: 1
          }
        },
        line: 210
      },
      "4": {
        name: "(anonymous_4)",
        decl: {
          start: {
            line: 215,
            column: 39
          },
          end: {
            line: 215,
            column: 40
          }
        },
        loc: {
          start: {
            line: 215,
            column: 45
          },
          end: {
            line: 226,
            column: 5
          }
        },
        line: 215
      }
    },
    branchMap: {
      "0": {
        loc: {
          start: {
            line: 8,
            column: 8
          },
          end: {
            line: 32,
            column: 9
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 8,
            column: 8
          },
          end: {
            line: 32,
            column: 9
          }
        }, {
          start: {
            line: 8,
            column: 8
          },
          end: {
            line: 32,
            column: 9
          }
        }],
        line: 8
      }
    },
    s: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0,
      "11": 0,
      "12": 0,
      "13": 0,
      "14": 0,
      "15": 0,
      "16": 0,
      "17": 0,
      "18": 0,
      "19": 0,
      "20": 0,
      "21": 0,
      "22": 0,
      "23": 0,
      "24": 0,
      "25": 0,
      "26": 0,
      "27": 0,
      "28": 0,
      "29": 0,
      "30": 0,
      "31": 0,
      "32": 0,
      "33": 0,
      "34": 0,
      "35": 0,
      "36": 0,
      "37": 0,
      "38": 0,
      "39": 0,
      "40": 0,
      "41": 0,
      "42": 0,
      "43": 0,
      "44": 0,
      "45": 0,
      "46": 0,
      "47": 0,
      "48": 0,
      "49": 0,
      "50": 0,
      "51": 0,
      "52": 0,
      "53": 0,
      "54": 0,
      "55": 0,
      "56": 0,
      "57": 0,
      "58": 0,
      "59": 0,
      "60": 0,
      "61": 0,
      "62": 0,
      "63": 0,
      "64": 0,
      "65": 0,
      "66": 0,
      "67": 0,
      "68": 0,
      "69": 0,
      "70": 0
    },
    f: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0
    },
    b: {
      "0": [0, 0]
    },
    _coverageSchema: "1a1c01bbd47fc00a2c39e90264f33305004495a9",
    hash: "e62d69254181ac2eda45844756b76bc74181789c"
  };
  var coverage = global[gcv] || (global[gcv] = {});

  if (!coverage[path] || coverage[path].hash !== hash) {
    coverage[path] = coverageData;
  }

  var actualCoverage = coverage[path];
  {
    // @ts-ignore
    cov_2ixowtlqop = function () {
      return actualCoverage;
    };
  }
  return actualCoverage;
}

cov_2ixowtlqop();

// const TaskItem = require('./TaskItem');
// create class for popup to add task
class TaskPopUp extends HTMLElement {
  // add TaskItem element to DOM
  addTask() {
    cov_2ixowtlqop().f[0]++;
    const tasks = (cov_2ixowtlqop().s[0]++, JSON.parse(localStorage.getItem('tasks')));
    const input = (cov_2ixowtlqop().s[1]++, this.shadowRoot.getElementById('task-input').value);
    cov_2ixowtlqop().s[2]++;

    if (input !== '') {
      cov_2ixowtlqop().b[0][0]++;
      // create TaskItem and append to DOM
      const task = (cov_2ixowtlqop().s[3]++, {
        id: localStorage.getItem('id'),
        checked: false,
        text: input,
        focused: false
      });
      const taskItem = (cov_2ixowtlqop().s[4]++, document.createElement('task-item'));
      cov_2ixowtlqop().s[5]++;
      taskItem.setAttribute('id', task.id);
      cov_2ixowtlqop().s[6]++;
      taskItem.setAttribute('checked', task.checked);
      cov_2ixowtlqop().s[7]++;
      taskItem.setAttribute('text', task.text);
      cov_2ixowtlqop().s[8]++;
      taskItem.setAttribute('focused', task.focused);
      cov_2ixowtlqop().s[9]++;
      document.getElementById('task-list-elements').appendChild(taskItem); // update localStorage

      cov_2ixowtlqop().s[10]++;
      tasks.push(task);
      cov_2ixowtlqop().s[11]++;
      localStorage.setItem('tasks', JSON.stringify(tasks));
      const id = (cov_2ixowtlqop().s[12]++, parseInt(localStorage.getItem('id'), 10) + 1);
      cov_2ixowtlqop().s[13]++;
      localStorage.setItem('id', `${id}`);
      const btnSound = (cov_2ixowtlqop().s[14]++, new Audio('./icons/btnClick.mp3'));
      cov_2ixowtlqop().s[15]++;
      btnSound.volume = 0.01 * parseInt(localStorage.getItem('volume'), 10);
      cov_2ixowtlqop().s[16]++;
      btnSound.play(); // hide popup

      cov_2ixowtlqop().s[17]++;
      this.closePopUp();
    } else {
      cov_2ixowtlqop().b[0][1]++;
    }
  } // closes popup


  closePopUp() {
    cov_2ixowtlqop().f[1]++;
    const wrapper = (cov_2ixowtlqop().s[18]++, this.shadowRoot.getElementById('add-task-popup'));
    const input = (cov_2ixowtlqop().s[19]++, this.shadowRoot.getElementById('task-input'));
    cov_2ixowtlqop().s[20]++;
    wrapper.style.display = 'none';
    cov_2ixowtlqop().s[21]++;
    input.value = '';
  }
  /* create popup item to add tasks by building a custom component */


  constructor() {
    cov_2ixowtlqop().f[2]++;
    cov_2ixowtlqop().s[22]++;
    super();
    const shadow = (cov_2ixowtlqop().s[23]++, this.attachShadow({
      mode: 'open'
    })); // use div as wrapper

    const wrapper = (cov_2ixowtlqop().s[24]++, document.createElement('div'));
    cov_2ixowtlqop().s[25]++;
    wrapper.setAttribute('id', 'add-task-popup'); // close icon

    const close = (cov_2ixowtlqop().s[26]++, wrapper.appendChild(document.createElement('img')));
    cov_2ixowtlqop().s[27]++;
    close.setAttribute('src', 'icons/close.svg');
    cov_2ixowtlqop().s[28]++;
    close.setAttribute('id', 'close-icon');
    const title = (cov_2ixowtlqop().s[29]++, wrapper.appendChild(document.createElement('h3')));
    cov_2ixowtlqop().s[30]++;
    title.innerHTML = 'Add Task'; // append an input form

    const input = (cov_2ixowtlqop().s[31]++, wrapper.appendChild(document.createElement('input')));
    cov_2ixowtlqop().s[32]++;
    input.setAttribute('type', 'text');
    cov_2ixowtlqop().s[33]++;
    input.setAttribute('id', 'task-input');
    cov_2ixowtlqop().s[34]++;
    input.setAttribute('placeholder', 'What are you working on today?');
    cov_2ixowtlqop().s[35]++;
    input.setAttribute('maxlength', '48');
    cov_2ixowtlqop().s[36]++;
    input.setAttribute('spellcheck', 'false'); // wrap add button in a footer

    const footer = (cov_2ixowtlqop().s[37]++, wrapper.appendChild(document.createElement('div')));
    cov_2ixowtlqop().s[38]++;
    footer.setAttribute('class', 'button-footer');
    const addBtn = (cov_2ixowtlqop().s[39]++, footer.appendChild(document.createElement('button')));
    cov_2ixowtlqop().s[40]++;
    addBtn.setAttribute('class', 'popup-btns');
    cov_2ixowtlqop().s[41]++;
    addBtn.setAttribute('id', 'add-task-btn');
    cov_2ixowtlqop().s[42]++;
    addBtn.innerHTML = 'Add'; // event listeners for close icon and add button

    cov_2ixowtlqop().s[43]++;
    close.addEventListener('click', this.closePopUp.bind(this));
    cov_2ixowtlqop().s[44]++;
    addBtn.addEventListener('click', this.addTask.bind(this)); // use ::part pseudo-element to style element outside of shadow tree -- for dark mode

    cov_2ixowtlqop().s[45]++;
    wrapper.setAttribute('part', 'popup-wrapper');
    cov_2ixowtlqop().s[46]++;
    close.setAttribute('part', 'close-icon');
    cov_2ixowtlqop().s[47]++;
    title.setAttribute('part', 'add-task-h3');
    cov_2ixowtlqop().s[48]++;
    input.setAttribute('part', 'task-input');
    cov_2ixowtlqop().s[49]++;
    footer.setAttribute('part', 'btn-footer');
    cov_2ixowtlqop().s[50]++;
    addBtn.setAttribute('part', 'add-btn'); // CSS styling

    const style = (cov_2ixowtlqop().s[51]++, document.createElement('style'));
    cov_2ixowtlqop().s[52]++;
    style.textContent = `
        .button-footer {
            background-color: rgb(234 234 234);
            // padding: 14px 20px;
            padding: 1.09375vw 1.5625vw;
            text-align: right;
            position: absolute;
            bottom: 0;
            right: 0;
            left: 0;
            // border-bottom-left-radius: 4px;
            // border-bottom-right-radius: 4px;
            border-bottom-left-radius: 0.3125vw;
            border-bottom-right-radius: 0.3125vw;
        }
        #close-icon {
            // width: 15px;
            width: 1.171875vw;
            // margin-top: 10px;
            // margin-right: 10px;
            margin-top: 0.78125vw;
            margin-right: 0.78125vw;
            position:absolute;
            top:0;
            right:0;
            cursor: pointer;
            opacity: 0.33;
        }
        #close-icon:hover {
            opacity: 1;
            transform: scale(1.1);
        }
        #add-task-popup {
            display: none;
            position: fixed;
            // width: 30%;
            width: 29.296875vw;
            // height: 30%;
            height: 15.625vw;
            // border-radius: 4px;
            border-radius: 0.3125vw;
            top:25%;
            left: 34%;
            z-index: 999;
            background-color: whitesmoke;
            box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
            -webkit-animation-name: animatetop; 
            -webkit-animation-duration: 0.3s;
            animation-name: animatetop;
            animation-duration: 0.3s
        }
        @-webkit-keyframes animatetop {
            from {top:-200px; opacity:0} 
            to {top:70; opacity:1}
        }
        @keyframes animatetop {
            from {top:-200px; opacity:0}
            to {top:70; opacity:1}
        }
        #task-input {
            font-family: 'Quicksand', sans-serif;
            font-size: 1.5vw;
            font-weight: 600;
            width: 85%;
            height: 22%;
            background-color: whitesmoke;
            color: rgb(85, 85, 85); 
            border-style: hidden;
            // border-radius: 5px;
            border-radius: 0.390625vw;
            outline: none;
            display: block;
            // margin: 20px auto 0 auto;
            margin: 1.5625vw auto 0 auto;
            font-weight: 500;
        }
        input[type='text']::placeholder {
            // color: rgba(85, 85, 85, 0.2);
            // color: #A7A7A7;
            color: #c7c7c75e;
        }
        #add-task-popup > h3{
            font-size: 1.6vw;
            font-weight: 500;
            color: #f36060;
            border-bottom: solid 1px #d2d2d2;
            // padding-bottom: 5px;
            padding-bottom: 0.390625vw;
            width: 85%;
            // margin: 20px auto 10px auto;
            margin: 1.5625vw auto 0.78125vw auto;
        }
        .popup-btns {
            cursor: pointer;
            border-style: none;
            // border-radius: 4px;
            border-radius: 0.3125vw;
            text-align: center;
            background-color:#f36060;
            color:#fff;
            font-family: 'Quicksand', sans-serif;
            height: 17%;
            width: 20%;
            // font-size: 1em;
            font-size: 1.25vw;
            font-weight: 500;
            outline: none;
        }
        .popup-btns:hover {
            filter: brightness(105%);
            transform: scale(1.1);
        }
        #add-task-btn {
            // padding: 8px 12px;
            padding: 0.625vw 0.9375vw;
        }
        #cancel-task-btn {
            position: absolute;
            float:right;
            right: 5em;
            bottom: 2em;
        }`;
    cov_2ixowtlqop().s[53]++;
    shadow.appendChild(wrapper);
    cov_2ixowtlqop().s[54]++;
    shadow.appendChild(style);
  }

}

cov_2ixowtlqop().s[55]++;
customElements.define('task-popup', TaskPopUp);
cov_2ixowtlqop().s[56]++;
window.addEventListener('load', () => {
  cov_2ixowtlqop().f[3]++;
  const popupBtn = (cov_2ixowtlqop().s[57]++, document.getElementById('task-popup-btn'));
  const popUp = (cov_2ixowtlqop().s[58]++, document.createElement('task-popup'));
  cov_2ixowtlqop().s[59]++;
  popUp.setAttribute('class', 'popup');
  cov_2ixowtlqop().s[60]++;
  document.body.appendChild(popUp);
  cov_2ixowtlqop().s[61]++;
  popupBtn.addEventListener('click', () => {
    cov_2ixowtlqop().f[4]++;
    const btnSound = (cov_2ixowtlqop().s[62]++, new Audio('./icons/btnClick.mp3'));
    cov_2ixowtlqop().s[63]++;
    btnSound.volume = 0.01 * parseInt(localStorage.getItem('volume'), 10);
    cov_2ixowtlqop().s[64]++;
    btnSound.play(); // make sure any popup is closed before opening current popup

    const popups = (cov_2ixowtlqop().s[65]++, Array.from(document.getElementsByClassName('popup')));
    cov_2ixowtlqop().s[66]++;

    for (let i = (cov_2ixowtlqop().s[67]++, 0); i < popups.length; i += 1) {
      cov_2ixowtlqop().s[68]++;
      popups[i].closePopUp();
    }

    cov_2ixowtlqop().s[69]++;
    popUp.shadowRoot.getElementById('add-task-popup').setAttribute('style', 'display:block');
    cov_2ixowtlqop().s[70]++;
    popUp.shadowRoot.getElementById('task-input').focus();
  });
}); // module.exports = TaskPopUp;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlRhc2tQb3BVcC5qcyJdLCJuYW1lcyI6WyJUYXNrUG9wVXAiLCJIVE1MRWxlbWVudCIsImFkZFRhc2siLCJ0YXNrcyIsIkpTT04iLCJwYXJzZSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJpbnB1dCIsInNoYWRvd1Jvb3QiLCJnZXRFbGVtZW50QnlJZCIsInZhbHVlIiwidGFzayIsImlkIiwiY2hlY2tlZCIsInRleHQiLCJmb2N1c2VkIiwidGFza0l0ZW0iLCJkb2N1bWVudCIsImNyZWF0ZUVsZW1lbnQiLCJzZXRBdHRyaWJ1dGUiLCJhcHBlbmRDaGlsZCIsInB1c2giLCJzZXRJdGVtIiwic3RyaW5naWZ5IiwicGFyc2VJbnQiLCJidG5Tb3VuZCIsIkF1ZGlvIiwidm9sdW1lIiwicGxheSIsImNsb3NlUG9wVXAiLCJ3cmFwcGVyIiwic3R5bGUiLCJkaXNwbGF5IiwiY29uc3RydWN0b3IiLCJzaGFkb3ciLCJhdHRhY2hTaGFkb3ciLCJtb2RlIiwiY2xvc2UiLCJ0aXRsZSIsImlubmVySFRNTCIsImZvb3RlciIsImFkZEJ0biIsImFkZEV2ZW50TGlzdGVuZXIiLCJiaW5kIiwidGV4dENvbnRlbnQiLCJjdXN0b21FbGVtZW50cyIsImRlZmluZSIsIndpbmRvdyIsInBvcHVwQnRuIiwicG9wVXAiLCJib2R5IiwicG9wdXBzIiwiQXJyYXkiLCJmcm9tIiwiZ2V0RWxlbWVudHNCeUNsYXNzTmFtZSIsImkiLCJsZW5ndGgiLCJmb2N1cyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWVZOzs7Ozs7Ozs7O0FBZlo7QUFDQTtBQUNBLE1BQU1BLFNBQU4sU0FBd0JDLFdBQXhCLENBQW9DO0FBQ2hDO0FBQ0FDLEVBQUFBLE9BQU8sR0FBRztBQUFBO0FBQ04sVUFBTUMsS0FBSyw2QkFBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdDLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixPQUFyQixDQUFYLENBQUgsQ0FBWDtBQUNBLFVBQU1DLEtBQUssNkJBQUcsS0FBS0MsVUFBTCxDQUFnQkMsY0FBaEIsQ0FBK0IsWUFBL0IsRUFBNkNDLEtBQWhELENBQVg7QUFGTTs7QUFHTixRQUFJSCxLQUFLLEtBQUssRUFBZCxFQUFrQjtBQUFBO0FBQ2Q7QUFDQSxZQUFNSSxJQUFJLDZCQUFHO0FBQ1RDLFFBQUFBLEVBQUUsRUFBRVAsWUFBWSxDQUFDQyxPQUFiLENBQXFCLElBQXJCLENBREs7QUFFVE8sUUFBQUEsT0FBTyxFQUFFLEtBRkE7QUFHVEMsUUFBQUEsSUFBSSxFQUFFUCxLQUhHO0FBSVRRLFFBQUFBLE9BQU8sRUFBRTtBQUpBLE9BQUgsQ0FBVjtBQU1BLFlBQU1DLFFBQVEsNkJBQUdDLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixXQUF2QixDQUFILENBQWQ7QUFSYztBQVNkRixNQUFBQSxRQUFRLENBQUNHLFlBQVQsQ0FBc0IsSUFBdEIsRUFBNEJSLElBQUksQ0FBQ0MsRUFBakM7QUFUYztBQVVkSSxNQUFBQSxRQUFRLENBQUNHLFlBQVQsQ0FBc0IsU0FBdEIsRUFBaUNSLElBQUksQ0FBQ0UsT0FBdEM7QUFWYztBQVdkRyxNQUFBQSxRQUFRLENBQUNHLFlBQVQsQ0FBc0IsTUFBdEIsRUFBOEJSLElBQUksQ0FBQ0csSUFBbkM7QUFYYztBQVlkRSxNQUFBQSxRQUFRLENBQUNHLFlBQVQsQ0FBc0IsU0FBdEIsRUFBaUNSLElBQUksQ0FBQ0ksT0FBdEM7QUFaYztBQWFkRSxNQUFBQSxRQUFRLENBQUNSLGNBQVQsQ0FBd0Isb0JBQXhCLEVBQThDVyxXQUE5QyxDQUEwREosUUFBMUQsRUFiYyxDQWNkOztBQWRjO0FBZWRkLE1BQUFBLEtBQUssQ0FBQ21CLElBQU4sQ0FBV1YsSUFBWDtBQWZjO0FBZ0JkTixNQUFBQSxZQUFZLENBQUNpQixPQUFiLENBQXFCLE9BQXJCLEVBQThCbkIsSUFBSSxDQUFDb0IsU0FBTCxDQUFlckIsS0FBZixDQUE5QjtBQUNBLFlBQU1VLEVBQUUsOEJBQUdZLFFBQVEsQ0FBQ25CLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixJQUFyQixDQUFELEVBQTZCLEVBQTdCLENBQVIsR0FBMkMsQ0FBOUMsQ0FBUjtBQWpCYztBQWtCZEQsTUFBQUEsWUFBWSxDQUFDaUIsT0FBYixDQUFxQixJQUFyQixFQUE0QixHQUFFVixFQUFHLEVBQWpDO0FBQ0EsWUFBTWEsUUFBUSw4QkFBRyxJQUFJQyxLQUFKLENBQVUsc0JBQVYsQ0FBSCxDQUFkO0FBbkJjO0FBb0JkRCxNQUFBQSxRQUFRLENBQUNFLE1BQVQsR0FBa0IsT0FBT0gsUUFBUSxDQUFDbkIsWUFBWSxDQUFDQyxPQUFiLENBQXFCLFFBQXJCLENBQUQsRUFBaUMsRUFBakMsQ0FBakM7QUFwQmM7QUFxQmRtQixNQUFBQSxRQUFRLENBQUNHLElBQVQsR0FyQmMsQ0FzQmQ7O0FBdEJjO0FBdUJkLFdBQUtDLFVBQUw7QUFDSCxLQXhCRDtBQUFBO0FBQUE7QUF5QkgsR0E5QitCLENBZ0NoQzs7O0FBQ0FBLEVBQUFBLFVBQVUsR0FBRztBQUFBO0FBQ1QsVUFBTUMsT0FBTyw4QkFBRyxLQUFLdEIsVUFBTCxDQUFnQkMsY0FBaEIsQ0FBK0IsZ0JBQS9CLENBQUgsQ0FBYjtBQUNBLFVBQU1GLEtBQUssOEJBQUcsS0FBS0MsVUFBTCxDQUFnQkMsY0FBaEIsQ0FBK0IsWUFBL0IsQ0FBSCxDQUFYO0FBRlM7QUFHVHFCLElBQUFBLE9BQU8sQ0FBQ0MsS0FBUixDQUFjQyxPQUFkLEdBQXdCLE1BQXhCO0FBSFM7QUFJVHpCLElBQUFBLEtBQUssQ0FBQ0csS0FBTixHQUFjLEVBQWQ7QUFDSDtBQUVEOzs7QUFDQXVCLEVBQUFBLFdBQVcsR0FBRztBQUFBO0FBQUE7QUFDVjtBQUNBLFVBQU1DLE1BQU0sOEJBQUcsS0FBS0MsWUFBTCxDQUFrQjtBQUFFQyxNQUFBQSxJQUFJLEVBQUU7QUFBUixLQUFsQixDQUFILENBQVosQ0FGVSxDQUdWOztBQUNBLFVBQU1OLE9BQU8sOEJBQUdiLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixLQUF2QixDQUFILENBQWI7QUFKVTtBQUtWWSxJQUFBQSxPQUFPLENBQUNYLFlBQVIsQ0FBcUIsSUFBckIsRUFBMkIsZ0JBQTNCLEVBTFUsQ0FNVjs7QUFDQSxVQUFNa0IsS0FBSyw4QkFBR1AsT0FBTyxDQUFDVixXQUFSLENBQW9CSCxRQUFRLENBQUNDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBcEIsQ0FBSCxDQUFYO0FBUFU7QUFRVm1CLElBQUFBLEtBQUssQ0FBQ2xCLFlBQU4sQ0FBbUIsS0FBbkIsRUFBMEIsaUJBQTFCO0FBUlU7QUFTVmtCLElBQUFBLEtBQUssQ0FBQ2xCLFlBQU4sQ0FBbUIsSUFBbkIsRUFBeUIsWUFBekI7QUFDQSxVQUFNbUIsS0FBSyw4QkFBR1IsT0FBTyxDQUFDVixXQUFSLENBQW9CSCxRQUFRLENBQUNDLGFBQVQsQ0FBdUIsSUFBdkIsQ0FBcEIsQ0FBSCxDQUFYO0FBVlU7QUFXVm9CLElBQUFBLEtBQUssQ0FBQ0MsU0FBTixHQUFrQixVQUFsQixDQVhVLENBWVY7O0FBQ0EsVUFBTWhDLEtBQUssOEJBQUd1QixPQUFPLENBQUNWLFdBQVIsQ0FBb0JILFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixPQUF2QixDQUFwQixDQUFILENBQVg7QUFiVTtBQWNWWCxJQUFBQSxLQUFLLENBQUNZLFlBQU4sQ0FBbUIsTUFBbkIsRUFBMkIsTUFBM0I7QUFkVTtBQWVWWixJQUFBQSxLQUFLLENBQUNZLFlBQU4sQ0FBbUIsSUFBbkIsRUFBeUIsWUFBekI7QUFmVTtBQWdCVlosSUFBQUEsS0FBSyxDQUFDWSxZQUFOLENBQW1CLGFBQW5CLEVBQWtDLGdDQUFsQztBQWhCVTtBQWlCVlosSUFBQUEsS0FBSyxDQUFDWSxZQUFOLENBQW1CLFdBQW5CLEVBQWdDLElBQWhDO0FBakJVO0FBa0JWWixJQUFBQSxLQUFLLENBQUNZLFlBQU4sQ0FBbUIsWUFBbkIsRUFBaUMsT0FBakMsRUFsQlUsQ0FtQlY7O0FBQ0EsVUFBTXFCLE1BQU0sOEJBQUdWLE9BQU8sQ0FBQ1YsV0FBUixDQUFvQkgsUUFBUSxDQUFDQyxhQUFULENBQXVCLEtBQXZCLENBQXBCLENBQUgsQ0FBWjtBQXBCVTtBQXFCVnNCLElBQUFBLE1BQU0sQ0FBQ3JCLFlBQVAsQ0FBb0IsT0FBcEIsRUFBNkIsZUFBN0I7QUFDQSxVQUFNc0IsTUFBTSw4QkFBR0QsTUFBTSxDQUFDcEIsV0FBUCxDQUFtQkgsUUFBUSxDQUFDQyxhQUFULENBQXVCLFFBQXZCLENBQW5CLENBQUgsQ0FBWjtBQXRCVTtBQXVCVnVCLElBQUFBLE1BQU0sQ0FBQ3RCLFlBQVAsQ0FBb0IsT0FBcEIsRUFBNkIsWUFBN0I7QUF2QlU7QUF3QlZzQixJQUFBQSxNQUFNLENBQUN0QixZQUFQLENBQW9CLElBQXBCLEVBQTBCLGNBQTFCO0FBeEJVO0FBeUJWc0IsSUFBQUEsTUFBTSxDQUFDRixTQUFQLEdBQW1CLEtBQW5CLENBekJVLENBMEJWOztBQTFCVTtBQTJCVkYsSUFBQUEsS0FBSyxDQUFDSyxnQkFBTixDQUF1QixPQUF2QixFQUFnQyxLQUFLYixVQUFMLENBQWdCYyxJQUFoQixDQUFxQixJQUFyQixDQUFoQztBQTNCVTtBQTRCVkYsSUFBQUEsTUFBTSxDQUFDQyxnQkFBUCxDQUF3QixPQUF4QixFQUFpQyxLQUFLekMsT0FBTCxDQUFhMEMsSUFBYixDQUFrQixJQUFsQixDQUFqQyxFQTVCVSxDQTZCVjs7QUE3QlU7QUE4QlZiLElBQUFBLE9BQU8sQ0FBQ1gsWUFBUixDQUFxQixNQUFyQixFQUE2QixlQUE3QjtBQTlCVTtBQStCVmtCLElBQUFBLEtBQUssQ0FBQ2xCLFlBQU4sQ0FBbUIsTUFBbkIsRUFBMkIsWUFBM0I7QUEvQlU7QUFnQ1ZtQixJQUFBQSxLQUFLLENBQUNuQixZQUFOLENBQW1CLE1BQW5CLEVBQTJCLGFBQTNCO0FBaENVO0FBaUNWWixJQUFBQSxLQUFLLENBQUNZLFlBQU4sQ0FBbUIsTUFBbkIsRUFBMkIsWUFBM0I7QUFqQ1U7QUFrQ1ZxQixJQUFBQSxNQUFNLENBQUNyQixZQUFQLENBQW9CLE1BQXBCLEVBQTRCLFlBQTVCO0FBbENVO0FBbUNWc0IsSUFBQUEsTUFBTSxDQUFDdEIsWUFBUCxDQUFvQixNQUFwQixFQUE0QixTQUE1QixFQW5DVSxDQW9DVjs7QUFDQSxVQUFNWSxLQUFLLDhCQUFHZCxRQUFRLENBQUNDLGFBQVQsQ0FBdUIsT0FBdkIsQ0FBSCxDQUFYO0FBckNVO0FBc0NWYSxJQUFBQSxLQUFLLENBQUNhLFdBQU4sR0FBcUI7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUF6SFE7QUF0Q1U7QUFnS1ZWLElBQUFBLE1BQU0sQ0FBQ2QsV0FBUCxDQUFtQlUsT0FBbkI7QUFoS1U7QUFpS1ZJLElBQUFBLE1BQU0sQ0FBQ2QsV0FBUCxDQUFtQlcsS0FBbkI7QUFDSDs7QUEzTStCOzs7QUE2TXBDYyxjQUFjLENBQUNDLE1BQWYsQ0FBc0IsWUFBdEIsRUFBb0MvQyxTQUFwQzs7QUFFQWdELE1BQU0sQ0FBQ0wsZ0JBQVAsQ0FBd0IsTUFBeEIsRUFBZ0MsTUFBTTtBQUFBO0FBQ2xDLFFBQU1NLFFBQVEsOEJBQUcvQixRQUFRLENBQUNSLGNBQVQsQ0FBd0IsZ0JBQXhCLENBQUgsQ0FBZDtBQUNBLFFBQU13QyxLQUFLLDhCQUFHaEMsUUFBUSxDQUFDQyxhQUFULENBQXVCLFlBQXZCLENBQUgsQ0FBWDtBQUZrQztBQUdsQytCLEVBQUFBLEtBQUssQ0FBQzlCLFlBQU4sQ0FBbUIsT0FBbkIsRUFBNEIsT0FBNUI7QUFIa0M7QUFJbENGLEVBQUFBLFFBQVEsQ0FBQ2lDLElBQVQsQ0FBYzlCLFdBQWQsQ0FBMEI2QixLQUExQjtBQUprQztBQUtsQ0QsRUFBQUEsUUFBUSxDQUFDTixnQkFBVCxDQUEwQixPQUExQixFQUFtQyxNQUFNO0FBQUE7QUFDckMsVUFBTWpCLFFBQVEsOEJBQUcsSUFBSUMsS0FBSixDQUFVLHNCQUFWLENBQUgsQ0FBZDtBQURxQztBQUVyQ0QsSUFBQUEsUUFBUSxDQUFDRSxNQUFULEdBQWtCLE9BQU9ILFFBQVEsQ0FBQ25CLFlBQVksQ0FBQ0MsT0FBYixDQUFxQixRQUFyQixDQUFELEVBQWlDLEVBQWpDLENBQWpDO0FBRnFDO0FBR3JDbUIsSUFBQUEsUUFBUSxDQUFDRyxJQUFULEdBSHFDLENBSXJDOztBQUNBLFVBQU11QixNQUFNLDhCQUFHQyxLQUFLLENBQUNDLElBQU4sQ0FBV3BDLFFBQVEsQ0FBQ3FDLHNCQUFULENBQWdDLE9BQWhDLENBQVgsQ0FBSCxDQUFaO0FBTHFDOztBQU1yQyxTQUFLLElBQUlDLENBQUMsOEJBQUcsQ0FBSCxDQUFWLEVBQWdCQSxDQUFDLEdBQUdKLE1BQU0sQ0FBQ0ssTUFBM0IsRUFBbUNELENBQUMsSUFBSSxDQUF4QyxFQUEyQztBQUFBO0FBQ3ZDSixNQUFBQSxNQUFNLENBQUNJLENBQUQsQ0FBTixDQUFVMUIsVUFBVjtBQUNIOztBQVJvQztBQVNyQ29CLElBQUFBLEtBQUssQ0FBQ3pDLFVBQU4sQ0FBaUJDLGNBQWpCLENBQWdDLGdCQUFoQyxFQUFrRFUsWUFBbEQsQ0FBK0QsT0FBL0QsRUFBd0UsZUFBeEU7QUFUcUM7QUFVckM4QixJQUFBQSxLQUFLLENBQUN6QyxVQUFOLENBQWlCQyxjQUFqQixDQUFnQyxZQUFoQyxFQUE4Q2dELEtBQTlDO0FBQ0gsR0FYRDtBQVlILENBakJELEUsQ0FtQkEiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBjb25zdCBUYXNrSXRlbSA9IHJlcXVpcmUoJy4vVGFza0l0ZW0nKTtcclxuLy8gY3JlYXRlIGNsYXNzIGZvciBwb3B1cCB0byBhZGQgdGFza1xyXG5jbGFzcyBUYXNrUG9wVXAgZXh0ZW5kcyBIVE1MRWxlbWVudCB7XHJcbiAgICAvLyBhZGQgVGFza0l0ZW0gZWxlbWVudCB0byBET01cclxuICAgIGFkZFRhc2soKSB7XHJcbiAgICAgICAgY29uc3QgdGFza3MgPSBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd0YXNrcycpKTtcclxuICAgICAgICBjb25zdCBpbnB1dCA9IHRoaXMuc2hhZG93Um9vdC5nZXRFbGVtZW50QnlJZCgndGFzay1pbnB1dCcpLnZhbHVlO1xyXG4gICAgICAgIGlmIChpbnB1dCAhPT0gJycpIHtcclxuICAgICAgICAgICAgLy8gY3JlYXRlIFRhc2tJdGVtIGFuZCBhcHBlbmQgdG8gRE9NXHJcbiAgICAgICAgICAgIGNvbnN0IHRhc2sgPSB7XHJcbiAgICAgICAgICAgICAgICBpZDogbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2lkJyksXHJcbiAgICAgICAgICAgICAgICBjaGVja2VkOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIHRleHQ6IGlucHV0LFxyXG4gICAgICAgICAgICAgICAgZm9jdXNlZDogZmFsc2UsXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIGNvbnN0IHRhc2tJdGVtID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgndGFzay1pdGVtJyk7XHJcbiAgICAgICAgICAgIHRhc2tJdGVtLnNldEF0dHJpYnV0ZSgnaWQnLCB0YXNrLmlkKTtcclxuICAgICAgICAgICAgdGFza0l0ZW0uc2V0QXR0cmlidXRlKCdjaGVja2VkJywgdGFzay5jaGVja2VkKTtcclxuICAgICAgICAgICAgdGFza0l0ZW0uc2V0QXR0cmlidXRlKCd0ZXh0JywgdGFzay50ZXh0KTtcclxuICAgICAgICAgICAgdGFza0l0ZW0uc2V0QXR0cmlidXRlKCdmb2N1c2VkJywgdGFzay5mb2N1c2VkKTtcclxuICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Rhc2stbGlzdC1lbGVtZW50cycpLmFwcGVuZENoaWxkKHRhc2tJdGVtKTtcclxuICAgICAgICAgICAgLy8gdXBkYXRlIGxvY2FsU3RvcmFnZVxyXG4gICAgICAgICAgICB0YXNrcy5wdXNoKHRhc2spO1xyXG4gICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgndGFza3MnLCBKU09OLnN0cmluZ2lmeSh0YXNrcykpO1xyXG4gICAgICAgICAgICBjb25zdCBpZCA9IHBhcnNlSW50KGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdpZCcpLCAxMCkgKyAxO1xyXG4gICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnaWQnLCBgJHtpZH1gKTtcclxuICAgICAgICAgICAgY29uc3QgYnRuU291bmQgPSBuZXcgQXVkaW8oJy4vaWNvbnMvYnRuQ2xpY2subXAzJyk7XHJcbiAgICAgICAgICAgIGJ0blNvdW5kLnZvbHVtZSA9IDAuMDEgKiBwYXJzZUludChsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndm9sdW1lJyksIDEwKTtcclxuICAgICAgICAgICAgYnRuU291bmQucGxheSgpO1xyXG4gICAgICAgICAgICAvLyBoaWRlIHBvcHVwXHJcbiAgICAgICAgICAgIHRoaXMuY2xvc2VQb3BVcCgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyBjbG9zZXMgcG9wdXBcclxuICAgIGNsb3NlUG9wVXAoKSB7XHJcbiAgICAgICAgY29uc3Qgd3JhcHBlciA9IHRoaXMuc2hhZG93Um9vdC5nZXRFbGVtZW50QnlJZCgnYWRkLXRhc2stcG9wdXAnKTtcclxuICAgICAgICBjb25zdCBpbnB1dCA9IHRoaXMuc2hhZG93Um9vdC5nZXRFbGVtZW50QnlJZCgndGFzay1pbnB1dCcpO1xyXG4gICAgICAgIHdyYXBwZXIuc3R5bGUuZGlzcGxheSA9ICdub25lJztcclxuICAgICAgICBpbnB1dC52YWx1ZSA9ICcnO1xyXG4gICAgfVxyXG5cclxuICAgIC8qIGNyZWF0ZSBwb3B1cCBpdGVtIHRvIGFkZCB0YXNrcyBieSBidWlsZGluZyBhIGN1c3RvbSBjb21wb25lbnQgKi9cclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgICAgIHN1cGVyKCk7XHJcbiAgICAgICAgY29uc3Qgc2hhZG93ID0gdGhpcy5hdHRhY2hTaGFkb3coeyBtb2RlOiAnb3BlbicgfSk7XHJcbiAgICAgICAgLy8gdXNlIGRpdiBhcyB3cmFwcGVyXHJcbiAgICAgICAgY29uc3Qgd3JhcHBlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgICAgIHdyYXBwZXIuc2V0QXR0cmlidXRlKCdpZCcsICdhZGQtdGFzay1wb3B1cCcpO1xyXG4gICAgICAgIC8vIGNsb3NlIGljb25cclxuICAgICAgICBjb25zdCBjbG9zZSA9IHdyYXBwZXIuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaW1nJykpO1xyXG4gICAgICAgIGNsb3NlLnNldEF0dHJpYnV0ZSgnc3JjJywgJ2ljb25zL2Nsb3NlLnN2ZycpO1xyXG4gICAgICAgIGNsb3NlLnNldEF0dHJpYnV0ZSgnaWQnLCAnY2xvc2UtaWNvbicpO1xyXG4gICAgICAgIGNvbnN0IHRpdGxlID0gd3JhcHBlci5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdoMycpKTtcclxuICAgICAgICB0aXRsZS5pbm5lckhUTUwgPSAnQWRkIFRhc2snO1xyXG4gICAgICAgIC8vIGFwcGVuZCBhbiBpbnB1dCBmb3JtXHJcbiAgICAgICAgY29uc3QgaW5wdXQgPSB3cmFwcGVyLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2lucHV0JykpO1xyXG4gICAgICAgIGlucHV0LnNldEF0dHJpYnV0ZSgndHlwZScsICd0ZXh0Jyk7XHJcbiAgICAgICAgaW5wdXQuc2V0QXR0cmlidXRlKCdpZCcsICd0YXNrLWlucHV0Jyk7XHJcbiAgICAgICAgaW5wdXQuc2V0QXR0cmlidXRlKCdwbGFjZWhvbGRlcicsICdXaGF0IGFyZSB5b3Ugd29ya2luZyBvbiB0b2RheT8nKTtcclxuICAgICAgICBpbnB1dC5zZXRBdHRyaWJ1dGUoJ21heGxlbmd0aCcsICc0OCcpO1xyXG4gICAgICAgIGlucHV0LnNldEF0dHJpYnV0ZSgnc3BlbGxjaGVjaycsICdmYWxzZScpO1xyXG4gICAgICAgIC8vIHdyYXAgYWRkIGJ1dHRvbiBpbiBhIGZvb3RlclxyXG4gICAgICAgIGNvbnN0IGZvb3RlciA9IHdyYXBwZXIuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JykpO1xyXG4gICAgICAgIGZvb3Rlci5zZXRBdHRyaWJ1dGUoJ2NsYXNzJywgJ2J1dHRvbi1mb290ZXInKTtcclxuICAgICAgICBjb25zdCBhZGRCdG4gPSBmb290ZXIuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYnV0dG9uJykpO1xyXG4gICAgICAgIGFkZEJ0bi5zZXRBdHRyaWJ1dGUoJ2NsYXNzJywgJ3BvcHVwLWJ0bnMnKTtcclxuICAgICAgICBhZGRCdG4uc2V0QXR0cmlidXRlKCdpZCcsICdhZGQtdGFzay1idG4nKTtcclxuICAgICAgICBhZGRCdG4uaW5uZXJIVE1MID0gJ0FkZCc7XHJcbiAgICAgICAgLy8gZXZlbnQgbGlzdGVuZXJzIGZvciBjbG9zZSBpY29uIGFuZCBhZGQgYnV0dG9uXHJcbiAgICAgICAgY2xvc2UuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCB0aGlzLmNsb3NlUG9wVXAuYmluZCh0aGlzKSk7XHJcbiAgICAgICAgYWRkQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgdGhpcy5hZGRUYXNrLmJpbmQodGhpcykpO1xyXG4gICAgICAgIC8vIHVzZSA6OnBhcnQgcHNldWRvLWVsZW1lbnQgdG8gc3R5bGUgZWxlbWVudCBvdXRzaWRlIG9mIHNoYWRvdyB0cmVlIC0tIGZvciBkYXJrIG1vZGVcclxuICAgICAgICB3cmFwcGVyLnNldEF0dHJpYnV0ZSgncGFydCcsICdwb3B1cC13cmFwcGVyJyk7XHJcbiAgICAgICAgY2xvc2Uuc2V0QXR0cmlidXRlKCdwYXJ0JywgJ2Nsb3NlLWljb24nKTtcclxuICAgICAgICB0aXRsZS5zZXRBdHRyaWJ1dGUoJ3BhcnQnLCAnYWRkLXRhc2staDMnKTtcclxuICAgICAgICBpbnB1dC5zZXRBdHRyaWJ1dGUoJ3BhcnQnLCAndGFzay1pbnB1dCcpO1xyXG4gICAgICAgIGZvb3Rlci5zZXRBdHRyaWJ1dGUoJ3BhcnQnLCAnYnRuLWZvb3RlcicpO1xyXG4gICAgICAgIGFkZEJ0bi5zZXRBdHRyaWJ1dGUoJ3BhcnQnLCAnYWRkLWJ0bicpO1xyXG4gICAgICAgIC8vIENTUyBzdHlsaW5nXHJcbiAgICAgICAgY29uc3Qgc3R5bGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzdHlsZScpO1xyXG4gICAgICAgIHN0eWxlLnRleHRDb250ZW50ID0gYFxyXG4gICAgICAgIC5idXR0b24tZm9vdGVyIHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDIzNCAyMzQgMjM0KTtcclxuICAgICAgICAgICAgLy8gcGFkZGluZzogMTRweCAyMHB4O1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAxLjA5Mzc1dncgMS41NjI1dnc7XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgIGJvdHRvbTogMDtcclxuICAgICAgICAgICAgcmlnaHQ6IDA7XHJcbiAgICAgICAgICAgIGxlZnQ6IDA7XHJcbiAgICAgICAgICAgIC8vIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDRweDtcclxuICAgICAgICAgICAgLy8gYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDRweDtcclxuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMC4zMTI1dnc7XHJcbiAgICAgICAgICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAwLjMxMjV2dztcclxuICAgICAgICB9XHJcbiAgICAgICAgI2Nsb3NlLWljb24ge1xyXG4gICAgICAgICAgICAvLyB3aWR0aDogMTVweDtcclxuICAgICAgICAgICAgd2lkdGg6IDEuMTcxODc1dnc7XHJcbiAgICAgICAgICAgIC8vIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAgICAgICAgIC8vIG1hcmdpbi1yaWdodDogMTBweDtcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDogMC43ODEyNXZ3O1xyXG4gICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDAuNzgxMjV2dztcclxuICAgICAgICAgICAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgICAgICAgICAgIHRvcDowO1xyXG4gICAgICAgICAgICByaWdodDowO1xyXG4gICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgICAgIG9wYWNpdHk6IDAuMzM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICNjbG9zZS1pY29uOmhvdmVyIHtcclxuICAgICAgICAgICAgb3BhY2l0eTogMTtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxLjEpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAjYWRkLXRhc2stcG9wdXAge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBub25lO1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICAgICAgICAgIC8vIHdpZHRoOiAzMCU7XHJcbiAgICAgICAgICAgIHdpZHRoOiAyOS4yOTY4NzV2dztcclxuICAgICAgICAgICAgLy8gaGVpZ2h0OiAzMCU7XHJcbiAgICAgICAgICAgIGhlaWdodDogMTUuNjI1dnc7XHJcbiAgICAgICAgICAgIC8vIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMC4zMTI1dnc7XHJcbiAgICAgICAgICAgIHRvcDoyNSU7XHJcbiAgICAgICAgICAgIGxlZnQ6IDM0JTtcclxuICAgICAgICAgICAgei1pbmRleDogOTk5O1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZXNtb2tlO1xyXG4gICAgICAgICAgICBib3gtc2hhZG93OiAwIDRweCA4cHggMCByZ2JhKDAsMCwwLDAuMiksMCA2cHggMjBweCAwIHJnYmEoMCwwLDAsMC4xOSk7XHJcbiAgICAgICAgICAgIC13ZWJraXQtYW5pbWF0aW9uLW5hbWU6IGFuaW1hdGV0b3A7IFxyXG4gICAgICAgICAgICAtd2Via2l0LWFuaW1hdGlvbi1kdXJhdGlvbjogMC4zcztcclxuICAgICAgICAgICAgYW5pbWF0aW9uLW5hbWU6IGFuaW1hdGV0b3A7XHJcbiAgICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogMC4zc1xyXG4gICAgICAgIH1cclxuICAgICAgICBALXdlYmtpdC1rZXlmcmFtZXMgYW5pbWF0ZXRvcCB7XHJcbiAgICAgICAgICAgIGZyb20ge3RvcDotMjAwcHg7IG9wYWNpdHk6MH0gXHJcbiAgICAgICAgICAgIHRvIHt0b3A6NzA7IG9wYWNpdHk6MX1cclxuICAgICAgICB9XHJcbiAgICAgICAgQGtleWZyYW1lcyBhbmltYXRldG9wIHtcclxuICAgICAgICAgICAgZnJvbSB7dG9wOi0yMDBweDsgb3BhY2l0eTowfVxyXG4gICAgICAgICAgICB0byB7dG9wOjcwOyBvcGFjaXR5OjF9XHJcbiAgICAgICAgfVxyXG4gICAgICAgICN0YXNrLWlucHV0IHtcclxuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdRdWlja3NhbmQnLCBzYW5zLXNlcmlmO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEuNXZ3O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICB3aWR0aDogODUlO1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDIyJTtcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGVzbW9rZTtcclxuICAgICAgICAgICAgY29sb3I6IHJnYig4NSwgODUsIDg1KTsgXHJcbiAgICAgICAgICAgIGJvcmRlci1zdHlsZTogaGlkZGVuO1xyXG4gICAgICAgICAgICAvLyBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDAuMzkwNjI1dnc7XHJcbiAgICAgICAgICAgIG91dGxpbmU6IG5vbmU7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgICAgICAvLyBtYXJnaW46IDIwcHggYXV0byAwIGF1dG87XHJcbiAgICAgICAgICAgIG1hcmdpbjogMS41NjI1dncgYXV0byAwIGF1dG87XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlucHV0W3R5cGU9J3RleHQnXTo6cGxhY2Vob2xkZXIge1xyXG4gICAgICAgICAgICAvLyBjb2xvcjogcmdiYSg4NSwgODUsIDg1LCAwLjIpO1xyXG4gICAgICAgICAgICAvLyBjb2xvcjogI0E3QTdBNztcclxuICAgICAgICAgICAgY29sb3I6ICNjN2M3Yzc1ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgI2FkZC10YXNrLXBvcHVwID4gaDN7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMS42dnc7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjZjM2MDYwO1xyXG4gICAgICAgICAgICBib3JkZXItYm90dG9tOiBzb2xpZCAxcHggI2QyZDJkMjtcclxuICAgICAgICAgICAgLy8gcGFkZGluZy1ib3R0b206IDVweDtcclxuICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDAuMzkwNjI1dnc7XHJcbiAgICAgICAgICAgIHdpZHRoOiA4NSU7XHJcbiAgICAgICAgICAgIC8vIG1hcmdpbjogMjBweCBhdXRvIDEwcHggYXV0bztcclxuICAgICAgICAgICAgbWFyZ2luOiAxLjU2MjV2dyBhdXRvIDAuNzgxMjV2dyBhdXRvO1xyXG4gICAgICAgIH1cclxuICAgICAgICAucG9wdXAtYnRucyB7XHJcbiAgICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgICAgICAgYm9yZGVyLXN0eWxlOiBub25lO1xyXG4gICAgICAgICAgICAvLyBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDAuMzEyNXZ3O1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6I2YzNjA2MDtcclxuICAgICAgICAgICAgY29sb3I6I2ZmZjtcclxuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdRdWlja3NhbmQnLCBzYW5zLXNlcmlmO1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDE3JTtcclxuICAgICAgICAgICAgd2lkdGg6IDIwJTtcclxuICAgICAgICAgICAgLy8gZm9udC1zaXplOiAxZW07XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMS4yNXZ3O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICAgICAgICBvdXRsaW5lOiBub25lO1xyXG4gICAgICAgIH1cclxuICAgICAgICAucG9wdXAtYnRuczpob3ZlciB7XHJcbiAgICAgICAgICAgIGZpbHRlcjogYnJpZ2h0bmVzcygxMDUlKTtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxLjEpO1xyXG4gICAgICAgIH1cclxuICAgICAgICAjYWRkLXRhc2stYnRuIHtcclxuICAgICAgICAgICAgLy8gcGFkZGluZzogOHB4IDEycHg7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDAuNjI1dncgMC45Mzc1dnc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICNjYW5jZWwtdGFzay1idG4ge1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICAgIGZsb2F0OnJpZ2h0O1xyXG4gICAgICAgICAgICByaWdodDogNWVtO1xyXG4gICAgICAgICAgICBib3R0b206IDJlbTtcclxuICAgICAgICB9YDtcclxuICAgICAgICBzaGFkb3cuYXBwZW5kQ2hpbGQod3JhcHBlcik7XHJcbiAgICAgICAgc2hhZG93LmFwcGVuZENoaWxkKHN0eWxlKTtcclxuICAgIH1cclxufVxyXG5jdXN0b21FbGVtZW50cy5kZWZpbmUoJ3Rhc2stcG9wdXAnLCBUYXNrUG9wVXApO1xyXG5cclxud2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2xvYWQnLCAoKSA9PiB7XHJcbiAgICBjb25zdCBwb3B1cEJ0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd0YXNrLXBvcHVwLWJ0bicpO1xyXG4gICAgY29uc3QgcG9wVXAgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCd0YXNrLXBvcHVwJyk7XHJcbiAgICBwb3BVcC5zZXRBdHRyaWJ1dGUoJ2NsYXNzJywgJ3BvcHVwJyk7XHJcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHBvcFVwKTtcclxuICAgIHBvcHVwQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGJ0blNvdW5kID0gbmV3IEF1ZGlvKCcuL2ljb25zL2J0bkNsaWNrLm1wMycpO1xyXG4gICAgICAgIGJ0blNvdW5kLnZvbHVtZSA9IDAuMDEgKiBwYXJzZUludChsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndm9sdW1lJyksIDEwKTtcclxuICAgICAgICBidG5Tb3VuZC5wbGF5KCk7XHJcbiAgICAgICAgLy8gbWFrZSBzdXJlIGFueSBwb3B1cCBpcyBjbG9zZWQgYmVmb3JlIG9wZW5pbmcgY3VycmVudCBwb3B1cFxyXG4gICAgICAgIGNvbnN0IHBvcHVwcyA9IEFycmF5LmZyb20oZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZSgncG9wdXAnKSk7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwb3B1cHMubGVuZ3RoOyBpICs9IDEpIHtcclxuICAgICAgICAgICAgcG9wdXBzW2ldLmNsb3NlUG9wVXAoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcG9wVXAuc2hhZG93Um9vdC5nZXRFbGVtZW50QnlJZCgnYWRkLXRhc2stcG9wdXAnKS5zZXRBdHRyaWJ1dGUoJ3N0eWxlJywgJ2Rpc3BsYXk6YmxvY2snKTtcclxuICAgICAgICBwb3BVcC5zaGFkb3dSb290LmdldEVsZW1lbnRCeUlkKCd0YXNrLWlucHV0JykuZm9jdXMoKTtcclxuICAgIH0pO1xyXG59KTtcclxuXHJcbi8vIG1vZHVsZS5leHBvcnRzID0gVGFza1BvcFVwO1xyXG4iXX0=
# Pomodoro Timer Manual Test Report
Template created by Jackie Li 03/17/2021
- Tester: 
- Date:
- System: 
- Browser:

## Help Popup

- [] Help button works as intended
- [] Press 'h' to open reset window
- [] Press 'esc' to close window

**Comment:**

## Timer Function

- [] Timer start and stop as intend 
- [] Timer switch mode between pomo section and break section
- [] For every three pomo section, there is a long break section
- [] Press 's' to start and stop the timer
- [] Timer work as intended in focus mode

**Comment:**

## Focus Mode

- [] Press 'f' to switch to the focus mode
- [] Press 'f' again to switch back
- [] Click focus button to switch mode

**Comment:**

## Reset

- [] Reset button works as intended
- [] Comfirm and clear all tasks
- [] Press 'r' to open reset window
- [] Press 'esc' to close window
- [] Press 'enter' to confirm

**Comment:**

## Setting

- [] setting button works as intended
- [] set pomo section length
- [] set short break section length
- [] set long break section length
- [] set dark mode
- [] set volume
- [] Press ';' to open reset window
- [] Press 'esc' to close window
- [] Press 'enter' to confirm

**Comment:**

## Task List

- [] add task button works as intended
- [] Press 'a' to open reset window
- [] Press 'esc' to close window
- [] Press 'enter' to confirm

**In normal Mode:**

- [] toggle the task
- [] focus the task
- [] unfocus the task
- [] delete the task

**In Focus Mode:**

- [] toggle the task
- [] focus the task
- [] unfocus the task
- [] delete the task
- [] next task queue in
- [] All task complete
- [] Add task disabled
  
**Comment:**





      {
         "browser": "Chrome",
         "platform": "OS X Big-Sur",
         "versions": [
            "86.0","85", "84"
         ]
      },
      {
         "browser": "Firefox",
         "platform": "OS X Big-Sur",
         "versions": [
            "82.0", "81", "80"
         ]
      },
      {
         "browser": "edge",
         "platform": "OS X Big-Sur",
         "versions": [
            "86.0","85", "84"
         ]
      }